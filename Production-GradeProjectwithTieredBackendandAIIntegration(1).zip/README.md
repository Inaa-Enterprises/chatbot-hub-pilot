
# Synapse-OD: Bot Creation Hub

This contains everything you need to run your AI Studio app locally. This application allows users to chat with various AI personas, create new child bot configurations, and upload learning materials. The frontend is prepared for integration with a backend server.

## Run Locally (Frontend Development Server)

**Prerequisites:** Node.js (which includes npm)

1.  **Install dependencies:**
    Open your terminal in the project's root directory and run:
    ```bash
    npm install
    ```

2.  **Set up Backend API URL (Optional for Dev):**
    The frontend is configured to make API calls to a backend server. By default, it will try to connect to relative paths like `/api/chat`.
    If your backend is running on a different URL during development, create a file named `.env.local` in the root of your project and set the `VITE_API_BASE_URL` variable:
    ```env
    VITE_API_BASE_URL=http://localhost:3001 # Or your backend server's URL
    ```
    If this variable is not set, the frontend will use relative paths for API calls (e.g., `/api/...`).

3.  **Set up Gemini API Key (For Backend):**
    The Gemini API Key (`GEMINI_API_KEY`) is **NOT** used directly by the frontend anymore. It should be securely configured on your backend server. The `vite.config.ts` still has a placeholder for it, but it's not actively used by the refactored client-side code for API calls. For any local frontend testing that might still temporarily use it (not recommended for production-like flows), you could place it in `.env.local`:
    ```env
    # GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE # Primarily for backend use
    ```

4.  **Run the development server:**
    ```bash
    npm run dev
    ```
    This will start the Vite development server, typically on `http://localhost:5173`. Open this URL in your browser to use the app.

## Backend Requirement

This frontend application is designed to work with a backend server that will handle:
*   Secure communication with the Gemini API.
*   Processing of file uploads and URL submissions.
*   Saving and managing child bot configurations.
*   (Potentially) User authentication and data persistence.

You will need to build or provide this backend server separately. The frontend makes requests to endpoints like:
*   `POST /api/chat`
*   `POST /api/uploadFile`
*   `POST /api/uploadUrl`
*   `POST /api/saveChildBot`

## Project Structure

*   `index.html`: The main HTML entry point.
*   `index.tsx`: The core React application logic.
*   `index.css`: Styles for the application.
*   `vite.config.ts`: Vite configuration.
*   `tsconfig.json`: TypeScript configuration.
*   `package.json`: Project dependencies and scripts.
*   `public/`: Static assets (if any).

## Features

*   **Persona-Based Chat**: Interact with a variety of pre-defined AI assistants.
*   **Nexus Core Selector**: Easily switch between AI Personas.
*   **Speech-to-Text (STT)**: Use your microphone for input.
*   **Text-to-Speech (TTS)**: AI responses can be read aloud.
*   **Child Bot Creator**:
    *   Design custom "child bots" from templates or from scratch.
    *   Define name, icon, focus keywords, and system instructions.
    *   Download the configuration locally and (attempt to) save to the backend.
*   **Upload Learning Materials**: UI for uploading files and YouTube URLs, which are sent to the backend.
*   **Template Bot Personas**:
    *   Comprehensive bot personas for various roles (Content Creator, Cook, Financial Consultant, etc.).
    *   Each persona includes detailed system instructions defining attitude, nature, and communication style.
    *   Designed to be integrated with the HTML templates in the `template_bot_project/bot-roles-interactive` directory.
*   **Cyberpunk "Glossy Obsidian" Theme**.
*   **Responsive Design**.
*   **Accessibility**: ARIA attributes and respects `prefers-reduced-motion`.
