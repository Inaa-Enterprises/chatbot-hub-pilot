"""
Services package for the child bot system.
"""

