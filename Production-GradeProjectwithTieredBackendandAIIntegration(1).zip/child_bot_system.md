# Child Bot System Documentation

**Author:** Manus AI  
**Date:** June 7, 2025

## Table of Contents

1. [Introduction](#introduction)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [API Reference](#api-reference)
6. [Knowledge Base Integration](#knowledge-base-integration)
7. [Bot Management](#bot-management)
8. [Conversation Management](#conversation-management)
9. [Performance Optimization](#performance-optimization)
10. [Troubleshooting](#troubleshooting)
11. [References](#references)

## Introduction

The Child Bot System is a component of the Synapse-OD Hub that manages child bots that interact with smaller models for knowledge base access. Each child bot has its own knowledge base and can be configured to use different models for different tasks. The system provides APIs for creating bots, managing conversations, and sending messages.

This document provides detailed information about the Child Bot System component, including its architecture, installation, configuration, and API reference.

## Architecture

The Child Bot System is built on a Flask web framework and provides a RESTful API for interacting with child bots. It consists of the following main components:

1. **API Server**: A Flask application that handles HTTP requests and responses.
2. **Bot Service**: A service that manages bot creation, configuration, and deletion.
3. **Conversation Service**: A service that manages conversations between users and bots.
4. **Knowledge Base Service**: A service that manages knowledge bases for bots.
5. **LLM Client**: A client that communicates with the LLM Server to access language models.

The system is designed to be scalable, maintainable, and easy to deploy. It uses a simple file-based storage system for development and testing, with the option to use Firebase for production deployments.

## Installation

### Prerequisites

- Python 3.9+
- LLM Server
- Docker (optional, for containerized deployment)

### Installation Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/synapse-od-hub.git
   cd synapse-od-hub/child-bot-system
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

4. Start the server:
   ```bash
   python src/main.py
   ```

### Docker Installation

1. Build the Docker image:
   ```bash
   docker build -t child-bot-system .
   ```

2. Run the Docker container:
   ```bash
   docker run -p 3002:3002 -e LLM_API_URL=http://host.docker.internal:3001/api -e LLM_API_KEY=test-api-key child-bot-system
   ```

## Configuration

The Child Bot System can be configured using environment variables or a configuration file. Here are the available configuration options:

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port to run the server on | `3002` |
| `LLM_API_URL` | URL of the LLM Server API | `http://localhost:3001/api` |
| `LLM_API_KEY` | API key for the LLM Server | `test-api-key` |
| `STORAGE_TYPE` | Type of storage to use (`file` or `firebase`) | `file` |
| `FIREBASE_CONFIG` | Path to Firebase configuration file | `""` |
| `DATA_DIR` | Directory for file-based storage | `data` |

You can set these variables in a `.env` file or directly in the environment.

## API Reference

### Endpoints

#### Health Check

```
GET /health
```

Check the health of the Child Bot System.

**Response Example:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

#### Create Bot

```
POST /bots
```

Create a new bot.

**Request Body:**
```json
{
  "name": "Customer Support Bot",
  "description": "A bot for customer support",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123",
  "parameters": {
    "temperature": 0.7,
    "max_tokens": 1024
  }
}
```

**Response Example:**
```json
{
  "id": "bot-123",
  "name": "Customer Support Bot",
  "description": "A bot for customer support",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123",
  "parameters": {
    "temperature": 0.7,
    "max_tokens": 1024
  },
  "created_at": 1623456789
}
```

#### List Bots

```
GET /bots
```

Get a list of all bots.

**Response Example:**
```json
[
  {
    "id": "bot-123",
    "name": "Customer Support Bot",
    "description": "A bot for customer support",
    "model_id": "vicuna-13b",
    "knowledge_base_id": "kb-123",
    "created_at": 1623456789
  },
  {
    "id": "bot-456",
    "name": "Sales Bot",
    "description": "A bot for sales inquiries",
    "model_id": "vicuna-13b",
    "knowledge_base_id": "kb-456",
    "created_at": 1623456790
  }
]
```

#### Get Bot

```
GET /bots/{bot_id}
```

Get a bot by ID.

**Response Example:**
```json
{
  "id": "bot-123",
  "name": "Customer Support Bot",
  "description": "A bot for customer support",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123",
  "parameters": {
    "temperature": 0.7,
    "max_tokens": 1024
  },
  "created_at": 1623456789
}
```

#### Update Bot

```
PUT /bots/{bot_id}
```

Update a bot.

**Request Body:**
```json
{
  "name": "Updated Customer Support Bot",
  "description": "An updated bot for customer support",
  "parameters": {
    "temperature": 0.8,
    "max_tokens": 2048
  }
}
```

**Response Example:**
```json
{
  "id": "bot-123",
  "name": "Updated Customer Support Bot",
  "description": "An updated bot for customer support",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123",
  "parameters": {
    "temperature": 0.8,
    "max_tokens": 2048
  },
  "created_at": 1623456789,
  "updated_at": 1623456800
}
```

#### Delete Bot

```
DELETE /bots/{bot_id}
```

Delete a bot.

**Response Example:**
```json
{
  "status": "ok",
  "message": "Bot deleted successfully"
}
```

#### Create Conversation

```
POST /bots/{bot_id}/conversations
```

Create a new conversation with a bot.

**Request Body:**
```json
{
  "user_id": "user-123",
  "metadata": {
    "source": "website",
    "page": "contact"
  }
}
```

**Response Example:**
```json
{
  "id": "conv-123",
  "bot_id": "bot-123",
  "user_id": "user-123",
  "metadata": {
    "source": "website",
    "page": "contact"
  },
  "created_at": 1623456789
}
```

#### List Conversations

```
GET /bots/{bot_id}/conversations
```

Get a list of all conversations for a bot.

**Query Parameters:**
- `user_id` (optional): Filter conversations by user ID.

**Response Example:**
```json
[
  {
    "id": "conv-123",
    "bot_id": "bot-123",
    "user_id": "user-123",
    "created_at": 1623456789
  },
  {
    "id": "conv-456",
    "bot_id": "bot-123",
    "user_id": "user-456",
    "created_at": 1623456790
  }
]
```

#### Get Conversation

```
GET /bots/{bot_id}/conversations/{conversation_id}
```

Get a conversation by ID.

**Response Example:**
```json
{
  "id": "conv-123",
  "bot_id": "bot-123",
  "user_id": "user-123",
  "metadata": {
    "source": "website",
    "page": "contact"
  },
  "created_at": 1623456789,
  "messages": [
    {
      "id": "msg-123",
      "role": "user",
      "content": "Hello, how can I get help with my order?",
      "timestamp": 1623456789
    },
    {
      "id": "msg-124",
      "role": "assistant",
      "content": "I'd be happy to help you with your order. Could you please provide your order number?",
      "timestamp": 1623456790
    }
  ]
}
```

#### Send Message

```
POST /bots/{bot_id}/conversations/{conversation_id}/messages
```

Send a message to a conversation.

**Request Body:**
```json
{
  "message": "Hello, how can I get help with my order?",
  "user_id": "user-123"
}
```

**Response Example:**
```json
{
  "id": "msg-123",
  "role": "user",
  "content": "Hello, how can I get help with my order?",
  "timestamp": 1623456789,
  "response": {
    "id": "msg-124",
    "role": "assistant",
    "content": "I'd be happy to help you with your order. Could you please provide your order number?",
    "timestamp": 1623456790
  }
}
```

#### List Messages

```
GET /bots/{bot_id}/conversations/{conversation_id}/messages
```

Get a list of all messages in a conversation.

**Response Example:**
```json
[
  {
    "id": "msg-123",
    "role": "user",
    "content": "Hello, how can I get help with my order?",
    "timestamp": 1623456789
  },
  {
    "id": "msg-124",
    "role": "assistant",
    "content": "I'd be happy to help you with your order. Could you please provide your order number?",
    "timestamp": 1623456790
  }
]
```

## Knowledge Base Integration

The Child Bot System integrates with knowledge bases to provide bots with access to domain-specific information. Each bot can be associated with a knowledge base, which is used to enhance the bot's responses.

### Knowledge Base Types

The system supports two types of knowledge bases:

1. **File-based**: Knowledge bases stored as text files or documents.
2. **Vector-based**: Knowledge bases stored as vector embeddings for efficient semantic search.

### Creating a Knowledge Base

To create a knowledge base, you need to:

1. Prepare the knowledge base content (text files, documents, etc.).
2. Use the Knowledge Base API to create a new knowledge base.
3. Associate the knowledge base with a bot.

### Using Knowledge Bases in Conversations

When a user sends a message to a bot, the system:

1. Retrieves the bot's associated knowledge base.
2. Searches the knowledge base for relevant information.
3. Includes the relevant information in the prompt sent to the language model.
4. Returns the language model's response to the user.

## Bot Management

The Child Bot System provides comprehensive bot management capabilities, including:

### Bot Creation

Bots can be created with various parameters, including:

- Name and description
- Associated language model
- Knowledge base
- Generation parameters (temperature, max tokens, etc.)

### Bot Configuration

Bots can be configured to use different:

- Language models
- Knowledge bases
- Generation parameters
- Response templates

### Bot Versioning

The system supports versioning of bots, allowing you to:

- Track changes to bot configurations
- Roll back to previous versions
- Compare performance between versions

## Conversation Management

The Child Bot System provides comprehensive conversation management capabilities, including:

### Conversation Creation

Conversations can be created with various parameters, including:

- User ID
- Metadata (source, context, etc.)

### Message History

The system maintains a complete history of messages in each conversation, allowing for:

- Context-aware responses
- Analysis of conversation patterns
- Training data generation

### Conversation Analytics

The system provides analytics for conversations, including:

- Message counts
- Response times
- User satisfaction metrics

## Performance Optimization

The Child Bot System includes several optimizations to improve performance:

### Caching

The system implements caching for:

- Bot configurations
- Knowledge base queries
- Common responses

### Batching

For high-throughput scenarios, the system supports batching of:

- Message processing
- Knowledge base queries
- Language model requests

### Streaming

The system supports streaming responses for chat messages, improving the perceived responsiveness of the system.

## Troubleshooting

### Common Issues

#### LLM Server Not Responding

If the Child Bot System cannot connect to the LLM Server, check that:

1. The LLM Server is running.
2. The `LLM_API_URL` environment variable is set correctly.
3. The `LLM_API_KEY` environment variable is set correctly.
4. There are no firewall or network issues blocking the connection.

#### Knowledge Base Not Found

If a bot's knowledge base cannot be found, check that:

1. The knowledge base ID is correct.
2. The knowledge base exists in the storage system.
3. The bot has permission to access the knowledge base.

#### High Memory Usage

If the system is using too much memory, consider:

1. Reducing the size of knowledge bases.
2. Limiting the number of concurrent conversations.
3. Implementing more aggressive caching strategies.

### Logs

The Child Bot System logs information about requests, responses, and errors to help with troubleshooting. By default, logs are written to the console and to a log file (`child_bot_api.log`).

To increase the log level for more detailed information, set the `LOG_LEVEL` environment variable:

```
LOG_LEVEL=DEBUG
```

## References

1. [Flask Documentation](https://flask.palletsprojects.com/)
2. [Firebase Documentation](https://firebase.google.com/docs)
3. [Vector Embeddings for NLP](https://www.tensorflow.org/text/guide/word_embeddings)
4. [Semantic Search](https://www.pinecone.io/learn/semantic-search/)
5. [Docker Documentation](https://docs.docker.com/)

