"""
Conversation model for the child bot system.
"""

import os
import json
import time
import uuid
from typing import Dict, List, Optional, Any

class Conversation:
    """
    Represents a conversation with a child bot.
    """
    
    def __init__(
        self,
        bot_id: str,
        user_id: str = "anonymous",
        id: str = None,
        created_at: float = None,
        updated_at: float = None,
        messages: List[Dict[str, Any]] = None,
        metadata: Dict[str, Any] = None
    ):
        """
        Initialize a new Conversation instance.
        
        Args:
            bot_id: ID of the bot involved in the conversation
            user_id: ID of the user involved in the conversation
            id: Unique identifier for the conversation (generated if not provided)
            created_at: Timestamp when the conversation was created
            updated_at: Timestamp when the conversation was last updated
            messages: List of messages in the conversation
            metadata: Additional metadata about the conversation
        """
        self.bot_id = bot_id
        self.user_id = user_id
        self.id = id or str(uuid.uuid4())
        self.created_at = created_at or time.time()
        self.updated_at = updated_at or time.time()
        self.messages = messages or []
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the conversation to a dictionary.
        
        Returns:
            Dict representation of the conversation
        """
        return {
            "id": self.id,
            "bot_id": self.bot_id,
            "user_id": self.user_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "messages": self.messages,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Conversation':
        """
        Create a Conversation instance from a dictionary.
        
        Args:
            data: Dictionary containing conversation data
            
        Returns:
            Conversation instance
        """
        return cls(
            bot_id=data.get("bot_id"),
            user_id=data.get("user_id"),
            id=data.get("id"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            messages=data.get("messages"),
            metadata=data.get("metadata")
        )
    
    def save(self, directory: str) -> str:
        """
        Save the conversation to a JSON file.
        
        Args:
            directory: Directory to save the conversation in
            
        Returns:
            Path to the saved file
        """
        os.makedirs(directory, exist_ok=True)
        file_path = os.path.join(directory, f"{self.id}.json")
        
        with open(file_path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
        
        return file_path
    
    @classmethod
    def load(cls, file_path: str) -> 'Conversation':
        """
        Load a conversation from a JSON file.
        
        Args:
            file_path: Path to the JSON file
            
        Returns:
            Conversation instance
        """
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        return cls.from_dict(data)
    
    @classmethod
    def list_conversations(cls, directory: str, bot_id: str = None, user_id: str = None) -> List['Conversation']:
        """
        List all conversations in a directory, optionally filtered by bot_id or user_id.
        
        Args:
            directory: Directory containing conversation JSON files
            bot_id: Optional bot ID to filter by
            user_id: Optional user ID to filter by
            
        Returns:
            List of Conversation instances
        """
        conversations = []
        
        if not os.path.exists(directory):
            return conversations
        
        for filename in os.listdir(directory):
            if filename.endswith('.json'):
                file_path = os.path.join(directory, filename)
                try:
                    conversation = cls.load(file_path)
                    
                    # Apply filters if provided
                    if bot_id and conversation.bot_id != bot_id:
                        continue
                    if user_id and conversation.user_id != user_id:
                        continue
                    
                    conversations.append(conversation)
                except Exception as e:
                    print(f"Error loading conversation from {file_path}: {e}")
        
        return conversations
    
    def add_message(self, role: str, content: str, metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Add a message to the conversation.
        
        Args:
            role: Role of the message sender (user, assistant, system)
            content: Content of the message
            metadata: Additional metadata about the message
            
        Returns:
            The added message
        """
        message = {
            "id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "timestamp": time.time(),
            "metadata": metadata or {}
        }
        
        self.messages.append(message)
        self.updated_at = time.time()
        
        return message
    
    def get_context_for_llm(self, max_messages: int = None, include_system_prompt: bool = True) -> List[Dict[str, str]]:
        """
        Get the conversation context formatted for an LLM.
        
        Args:
            max_messages: Maximum number of messages to include (from the end)
            include_system_prompt: Whether to include the system prompt
            
        Returns:
            List of messages formatted for an LLM
        """
        messages = []
        
        # Add system prompt if requested and available
        if include_system_prompt and self.metadata.get("system_prompt"):
            messages.append({
                "role": "system",
                "content": self.metadata["system_prompt"]
            })
        
        # Get the conversation messages
        conversation_messages = self.messages
        if max_messages:
            conversation_messages = conversation_messages[-max_messages:]
        
        # Add conversation messages
        for message in conversation_messages:
            messages.append({
                "role": message["role"],
                "content": message["content"]
            })
        
        return messages

