# Firebase and Google Cloud Implementation Plan

## Firebase Project Setup

### 1. Project Creation and Configuration

```bash
# Install Firebase CLI if not already installed
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize a new Firebase project
firebase init

# Select the following services:
# - Authentication
# - Firestore
# - Storage
# - Functions
# - Hosting
```

### 2. Firebase Authentication Setup

Configure Firebase Authentication with the following providers:
- Email/Password
- Google (OAuth)
- Anonymous (for guest access)

```javascript
// Example configuration in Firebase console
// Authentication > Sign-in method > Add provider

// Implementation in frontend code
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Email/Password Authentication
const signInWithEmail = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error('Error signing in with email and password', error);
    throw error;
  }
};

// Google Authentication
const signInWithGoogle = async () => {
  try {
    const provider = new GoogleAuthProvider();
    const userCredential = await signInWithPopup(auth, provider);
    return userCredential.user;
  } catch (error) {
    console.error('Error signing in with Google', error);
    throw error;
  }
};
```

### 3. Firestore Database Schema

Design the Firestore database schema to efficiently store and retrieve data while minimizing read/write operations:

```
firestore/
├── users/
│   └── {userId}/
│       ├── profile: { name, email, preferences }
│       ├── usage: { apiCalls, storageUsed, lastActive }
│       └── settings: { theme, notifications, accessibility }
├── bots/
│   └── {botId}/
│       ├── config: { name, description, icon, systemPrompt }
│       ├── knowledge: { sources: [], lastUpdated }
│       └── stats: { interactions, successRate, popularity }
├── conversations/
│   └── {conversationId}/
│       ├── metadata: { title, participants, createdAt, updatedAt }
│       ├── messages: [ { role, content, timestamp } ]
│       └── settings: { model, temperature, contextWindow }
└── learningMaterials/
    └── {materialId}/
        ├── metadata: { title, type, source, uploadedBy, uploadedAt }
        ├── status: { processed, vectorized, indexed }
        └── stats: { usageCount, relevanceScore }
```

### 4. Firebase Storage Structure

Organize Firebase Storage to efficiently store and retrieve files:

```
storage/
├── users/
│   └── {userId}/
│       ├── profile/
│       │   └── avatar.jpg
│       └── uploads/
│           └── {fileId}.{extension}
├── bots/
│   └── {botId}/
│       ├── icon.png
│       └── voice/
│           └── samples/
├── learning-materials/
│   └── {materialId}/
│       ├── original.{extension}
│       └── processed/
│           ├── chunks/
│           └── embeddings/
└── system/
    ├── models/
    │   └── {modelId}/
    │       └── weights.bin
    └── templates/
        └── {templateId}.json
```

### 5. Firebase Cloud Functions

Implement Cloud Functions for key backend operations:

```javascript
// Example Cloud Function for chat API
const functions = require('firebase-functions');
const cors = require('cors')({ origin: true });
const admin = require('firebase-admin');
const axios = require('axios');

admin.initializeApp();

exports.chat = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      // Verify authentication
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      
      const idToken = authHeader.split('Bearer ')[1];
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      const uid = decodedToken.uid;
      
      // Get user data
      const userDoc = await admin.firestore().collection('users').doc(uid).get();
      if (!userDoc.exists) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      const userData = userDoc.data();
      
      // Check usage limits
      if (userData.usage.apiCalls >= userData.limits.apiCalls) {
        return res.status(429).json({ error: 'API call limit reached' });
      }
      
      // Process chat request
      const { messages, botId, options } = req.body;
      
      // Determine which model to use (local or cloud)
      let modelEndpoint;
      if (options.useLocalModel) {
        modelEndpoint = 'http://localhost:8000/v1/chat/completions'; // Local LLM Studio endpoint
      } else {
        modelEndpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
      }
      
      // Forward request to appropriate model
      const modelResponse = await axios.post(modelEndpoint, {
        messages,
        temperature: options.temperature || 0.7,
        max_tokens: options.maxTokens || 1024
      }, {
        headers: options.useLocalModel ? {} : {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.GEMINI_API_KEY}`
        }
      });
      
      // Update user usage stats
      await admin.firestore().collection('users').doc(uid).update({
        'usage.apiCalls': admin.firestore.FieldValue.increment(1),
        'usage.lastActive': admin.firestore.FieldValue.serverTimestamp()
      });
      
      // Save conversation if enabled
      if (options.saveConversation) {
        const conversationRef = admin.firestore().collection('conversations').doc();
        await conversationRef.set({
          userId: uid,
          botId: botId,
          messages: [...messages, modelResponse.data],
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });
      }
      
      // Return response
      return res.status(200).json(modelResponse.data);
    } catch (error) {
      console.error('Error processing chat request:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  });
});

// Cloud Function for file upload
exports.uploadFile = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      // Authentication and validation logic
      // ...
      
      // Process file upload
      // ...
      
      // Store file metadata in Firestore
      // ...
      
      return res.status(200).json({ success: true, fileId: fileId });
    } catch (error) {
      console.error('Error processing file upload:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  });
});

// Cloud Function for saving child bot configuration
exports.saveChildBot = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      // Authentication and validation logic
      // ...
      
      // Save bot configuration
      // ...
      
      return res.status(200).json({ success: true, botId: botId });
    } catch (error) {
      console.error('Error saving child bot:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  });
});
```

## Google Cloud Services Setup

### 1. Google Cloud Project Configuration

```bash
# Install Google Cloud SDK if not already installed
# Follow instructions at https://cloud.google.com/sdk/docs/install

# Initialize Google Cloud SDK
gcloud init

# Set project
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable speech.googleapis.com
gcloud services enable texttospeech.googleapis.com
gcloud services enable translate.googleapis.com
gcloud services enable aiplatform.googleapis.com
```

### 2. Speech-to-Text Implementation

```javascript
// Example implementation using Google Cloud Speech-to-Text API
const speech = require('@google-cloud/speech');
const fs = require('fs');

// Creates a client
const client = new speech.SpeechClient();

async function transcribeAudio(audioBuffer, encoding, sampleRateHertz, languageCode) {
  const audio = {
    content: audioBuffer.toString('base64'),
  };
  
  const config = {
    encoding: encoding,
    sampleRateHertz: sampleRateHertz,
    languageCode: languageCode,
    model: 'latest_short', // Use short model for real-time transcription
    useEnhanced: true,     // Use enhanced model for better accuracy
  };
  
  const request = {
    audio: audio,
    config: config,
  };

  // Detects speech in the audio file
  const [response] = await client.recognize(request);
  const transcription = response.results
    .map(result => result.alternatives[0].transcript)
    .join('\n');
    
  return transcription;
}

// Usage tracking to stay within free limits
async function trackSpeechToTextUsage(userId, durationSeconds) {
  const db = admin.firestore();
  const userRef = db.collection('users').doc(userId);
  
  await userRef.update({
    'usage.speechToTextMinutes': admin.firestore.FieldValue.increment(durationSeconds / 60),
    'usage.lastActive': admin.firestore.FieldValue.serverTimestamp()
  });
  
  // Get updated usage
  const userDoc = await userRef.get();
  const userData = userDoc.data();
  
  // Check if approaching free tier limit (60 minutes/month)
  if (userData.usage.speechToTextMinutes > 50) {
    // Send notification to user
    // ...
  }
}
```

### 3. Text-to-Speech Implementation

```javascript
// Example implementation using Google Cloud Text-to-Speech API
const textToSpeech = require('@google-cloud/text-to-speech');

// Creates a client
const client = new textToSpeech.TextToSpeechClient();

async function synthesizeSpeech(text, languageCode, voiceName, audioEncoding) {
  const request = {
    input: { text: text },
    voice: {
      languageCode: languageCode,
      name: voiceName,
    },
    audioConfig: { audioEncoding: audioEncoding },
  };

  // Performs the text-to-speech request
  const [response] = await client.synthesizeSpeech(request);
  return response.audioContent;
}

// Usage tracking to stay within free limits
async function trackTextToSpeechUsage(userId, characterCount) {
  const db = admin.firestore();
  const userRef = db.collection('users').doc(userId);
  
  await userRef.update({
    'usage.textToSpeechCharacters': admin.firestore.FieldValue.increment(characterCount),
    'usage.lastActive': admin.firestore.FieldValue.serverTimestamp()
  });
  
  // Get updated usage
  const userDoc = await userRef.get();
  const userData = userDoc.data();
  
  // Check if approaching free tier limit (4 million characters/month)
  if (userData.usage.textToSpeechCharacters > 3500000) {
    // Send notification to user
    // ...
  }
}
```

### 4. Translation Service Implementation

```javascript
// Example implementation using Google Cloud Translation API
const { TranslationServiceClient } = require('@google-cloud/translate');

// Creates a client
const translationClient = new TranslationServiceClient();

async function translateText(text, targetLanguage, sourceLanguage = null) {
  const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
  const location = 'global';
  
  const request = {
    parent: `projects/${projectId}/locations/${location}`,
    contents: [text],
    mimeType: 'text/plain',
    targetLanguageCode: targetLanguage,
  };
  
  if (sourceLanguage) {
    request.sourceLanguageCode = sourceLanguage;
  }

  // Call the Translation API
  const [response] = await translationClient.translateText(request);
  return response.translations[0].translatedText;
}

// Usage tracking to stay within free limits
async function trackTranslationUsage(userId, characterCount) {
  const db = admin.firestore();
  const userRef = db.collection('users').doc(userId);
  
  await userRef.update({
    'usage.translationCharacters': admin.firestore.FieldValue.increment(characterCount),
    'usage.lastActive': admin.firestore.FieldValue.serverTimestamp()
  });
  
  // Get updated usage
  const userDoc = await userRef.get();
  const userData = userDoc.data();
  
  // Check if approaching free tier limit (500K characters/month)
  if (userData.usage.translationCharacters > 450000) {
    // Send notification to user
    // ...
  }
}
```

## Free Tier Optimization Strategies

### 1. Caching Implementation

```javascript
// Example Redis-like caching implementation using Firebase Realtime Database
const admin = require('firebase-admin');

class CacheService {
  constructor() {
    this.db = admin.database();
    this.cacheRef = this.db.ref('cache');
  }
  
  async get(key) {
    const snapshot = await this.cacheRef.child(key).once('value');
    const data = snapshot.val();
    
    if (!data) return null;
    
    // Check if cache is expired
    if (data.expiresAt && data.expiresAt < Date.now()) {
      await this.delete(key);
      return null;
    }
    
    return data.value;
  }
  
  async set(key, value, ttlSeconds = 3600) {
    const expiresAt = Date.now() + (ttlSeconds * 1000);
    
    await this.cacheRef.child(key).set({
      value,
      expiresAt,
      createdAt: Date.now()
    });
  }
  
  async delete(key) {
    await this.cacheRef.child(key).remove();
  }
  
  async clear() {
    await this.cacheRef.remove();
  }
}

// Usage example
const cacheService = new CacheService();

// In API handler
async function handleRequest(req, res) {
  const cacheKey = `chat_${JSON.stringify(req.body)}`;
  
  // Try to get from cache first
  const cachedResponse = await cacheService.get(cacheKey);
  if (cachedResponse) {
    return res.status(200).json(cachedResponse);
  }
  
  // Process request normally
  const response = await processRequest(req.body);
  
  // Cache the response
  await cacheService.set(cacheKey, response, 1800); // 30 minutes TTL
  
  return res.status(200).json(response);
}
```

### 2. Batching Implementation

```javascript
// Example batching implementation for Firestore writes
class BatchService {
  constructor() {
    this.db = admin.firestore();
    this.batches = {};
    this.batchSizes = {};
    this.MAX_BATCH_SIZE = 500; // Firestore limit
  }
  
  getBatch(batchId) {
    if (!this.batches[batchId]) {
      this.batches[batchId] = this.db.batch();
      this.batchSizes[batchId] = 0;
    }
    return this.batches[batchId];
  }
  
  addToBatch(batchId, operation, ref, data) {
    const batch = this.getBatch(batchId);
    
    switch (operation) {
      case 'set':
        batch.set(ref, data);
        break;
      case 'update':
        batch.update(ref, data);
        break;
      case 'delete':
        batch.delete(ref);
        break;
      default:
        throw new Error(`Unknown batch operation: ${operation}`);
    }
    
    this.batchSizes[batchId]++;
    
    // If batch is full, commit it and create a new one
    if (this.batchSizes[batchId] >= this.MAX_BATCH_SIZE) {
      this.commitBatch(batchId);
    }
  }
  
  async commitBatch(batchId) {
    if (this.batches[batchId] && this.batchSizes[batchId] > 0) {
      await this.batches[batchId].commit();
      delete this.batches[batchId];
      delete this.batchSizes[batchId];
    }
  }
  
  async commitAllBatches() {
    const promises = Object.keys(this.batches).map(batchId => this.commitBatch(batchId));
    await Promise.all(promises);
  }
}

// Usage example
const batchService = new BatchService();

// Add operations to batch
batchService.addToBatch('userUpdates', 'update', userRef, { lastActive: new Date() });
batchService.addToBatch('userUpdates', 'set', userStatsRef, { apiCalls: 42 });

// Commit batch when ready
await batchService.commitBatch('userUpdates');
```

### 3. Compression Implementation

```javascript
// Example compression implementation for data storage
const zlib = require('zlib');
const util = require('util');

const gzipPromise = util.promisify(zlib.gzip);
const gunzipPromise = util.promisify(zlib.gunzip);

// Compress data before storing
async function compressAndStore(data, ref) {
  // Convert data to string if it's an object
  const dataString = typeof data === 'object' ? JSON.stringify(data) : data;
  
  // Compress the data
  const compressedData = await gzipPromise(dataString);
  
  // Store compressed data
  await ref.set({
    data: compressedData.toString('base64'),
    compressed: true,
    originalSize: dataString.length,
    compressedSize: compressedData.length,
    timestamp: admin.firestore.FieldValue.serverTimestamp()
  });
  
  // Return compression stats
  return {
    originalSize: dataString.length,
    compressedSize: compressedData.length,
    compressionRatio: dataString.length / compressedData.length
  };
}

// Retrieve and decompress data
async function retrieveAndDecompress(ref) {
  const doc = await ref.get();
  
  if (!doc.exists) {
    return null;
  }
  
  const data = doc.data();
  
  // If data is not compressed, return as is
  if (!data.compressed) {
    return data;
  }
  
  // Decompress the data
  const compressedBuffer = Buffer.from(data.data, 'base64');
  const decompressedBuffer = await gunzipPromise(compressedBuffer);
  const decompressedString = decompressedBuffer.toString();
  
  // Parse JSON if the original data was an object
  try {
    return JSON.parse(decompressedString);
  } catch (e) {
    // If not valid JSON, return as string
    return decompressedString;
  }
}
```

### 4. Local Processing Implementation

```javascript
// Example implementation for routing between local and cloud processing
class ModelRouter {
  constructor(localEndpoint, cloudEndpoint, cloudApiKey) {
    this.localEndpoint = localEndpoint;
    this.cloudEndpoint = cloudEndpoint;
    this.cloudApiKey = cloudApiKey;
    this.localAvailable = false;
    
    // Check if local endpoint is available
    this.checkLocalAvailability();
    
    // Set up periodic checks
    setInterval(() => this.checkLocalAvailability(), 60000); // Check every minute
  }
  
  async checkLocalAvailability() {
    try {
      const response = await axios.get(`${this.localEndpoint}/health`, { timeout: 2000 });
      this.localAvailable = response.status === 200;
    } catch (error) {
      this.localAvailable = false;
    }
  }
  
  async processRequest(request) {
    // Determine where to send the request
    const useLocal = this.shouldUseLocalProcessing(request);
    
    if (useLocal && this.localAvailable) {
      try {
        // Send to local endpoint
        const response = await axios.post(`${this.localEndpoint}/v1/chat/completions`, request, {
          timeout: 30000 // 30 seconds timeout
        });
        return response.data;
      } catch (error) {
        console.error('Error with local processing, falling back to cloud:', error);
        // Fall back to cloud if local fails
        return this.processWithCloud(request);
      }
    } else {
      // Use cloud processing
      return this.processWithCloud(request);
    }
  }
  
  async processWithCloud(request) {
    // Adapt request format for cloud API if needed
    const cloudRequest = this.adaptRequestForCloud(request);
    
    // Send to cloud endpoint
    const response = await axios.post(this.cloudEndpoint, cloudRequest, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.cloudApiKey}`
      }
    });
    
    // Adapt response format to match local API
    return this.adaptResponseFromCloud(response.data);
  }
  
  shouldUseLocalProcessing(request) {
    // Logic to determine if request should use local processing
    // Based on complexity, priority, etc.
    
    // Example: Use local for shorter contexts
    if (request.messages && request.messages.length < 5) {
      return true;
    }
    
    // Example: Use local for non-streaming requests
    if (!request.stream) {
      return true;
    }
    
    // Default to cloud
    return false;
  }
  
  adaptRequestForCloud(request) {
    // Adapt request format for cloud API
    // This depends on the specific cloud API being used
    
    // Example for Gemini API
    return {
      contents: request.messages.map(msg => ({
        role: msg.role === 'user' ? 'USER' : 'MODEL',
        parts: [{ text: msg.content }]
      })),
      generationConfig: {
        temperature: request.temperature || 0.7,
        maxOutputTokens: request.max_tokens || 1024,
        topP: request.top_p || 0.95,
        topK: request.top_k || 40
      }
    };
  }
  
  adaptResponseFromCloud(cloudResponse) {
    // Adapt cloud response to match local API format
    // This depends on the specific cloud API being used
    
    // Example for Gemini API
    return {
      id: `gemini-${Date.now()}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      model: 'gemini-pro',
      choices: [{
        index: 0,
        message: {
          role: 'assistant',
          content: cloudResponse.candidates[0].content.parts[0].text
        },
        finish_reason: 'stop'
      }],
      usage: {
        prompt_tokens: -1, // Not provided by Gemini
        completion_tokens: -1, // Not provided by Gemini
        total_tokens: -1 // Not provided by Gemini
      }
    };
  }
}

// Usage
const modelRouter = new ModelRouter(
  'http://localhost:8000', // Local LMStudio endpoint
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent', // Cloud endpoint
  process.env.GEMINI_API_KEY
);

// Process request
const response = await modelRouter.processRequest({
  messages: [
    { role: 'user', content: 'Hello, how are you?' }
  ],
  temperature: 0.7,
  max_tokens: 1024
});
```

### 5. Tiered Access Implementation

```javascript
// Example implementation for tiered access control
class TieredAccessManager {
  constructor() {
    this.db = admin.firestore();
  }
  
  async getUserTier(userId) {
    const userDoc = await this.db.collection('users').doc(userId).get();
    
    if (!userDoc.exists) {
      throw new Error('User not found');
    }
    
    const userData = userDoc.data();
    return userData.tier || 'free'; // Default to free tier
  }
  
  async checkAccess(userId, feature) {
    const userTier = await this.getUserTier(userId);
    const tierLimits = await this.getTierLimits(userTier);
    
    // Check if feature is available in user's tier
    if (!tierLimits.features[feature]) {
      return {
        allowed: false,
        reason: `Feature '${feature}' is not available in your current tier.`,
        upgrade: true
      };
    }
    
    // Check usage limits
    const userUsage = await this.getUserUsage(userId);
    const featureLimit = tierLimits.limits[feature];
    const featureUsage = userUsage[feature] || 0;
    
    if (featureUsage >= featureLimit) {
      return {
        allowed: false,
        reason: `You have reached the ${feature} limit for your current tier.`,
        upgrade: true,
        limit: featureLimit,
        usage: featureUsage
      };
    }
    
    return {
      allowed: true,
      limit: featureLimit,
      usage: featureUsage,
      remaining: featureLimit - featureUsage
    };
  }
  
  async incrementUsage(userId, feature, amount = 1) {
    const userRef = this.db.collection('users').doc(userId);
    
    await userRef.update({
      [`usage.${feature}`]: admin.firestore.FieldValue.increment(amount),
      'usage.lastUpdated': admin.firestore.FieldValue.serverTimestamp()
    });
  }
  
  async getUserUsage(userId) {
    const userDoc = await this.db.collection('users').doc(userId).get();
    
    if (!userDoc.exists) {
      throw new Error('User not found');
    }
    
    const userData = userDoc.data();
    return userData.usage || {};
  }
  
  async getTierLimits(tier) {
    const tierDoc = await this.db.collection('tiers').doc(tier).get();
    
    if (!tierDoc.exists) {
      throw new Error(`Tier '${tier}' not found`);
    }
    
    return tierDoc.data();
  }
}

// Example tier configuration in Firestore
/*
tiers/free: {
  name: 'Free',
  features: {
    textChat: true,
    imageGeneration: false,
    speechToText: true,
    textToSpeech: true,
    advancedModels: false,
    customBots: true
  },
  limits: {
    apiCalls: 100,
    storageGB: 1,
    speechToTextMinutes: 10,
    textToSpeechCharacters: 100000,
    customBots: 2
  }
}

tiers/premium: {
  name: 'Premium',
  features: {
    textChat: true,
    imageGeneration: true,
    speechToText: true,
    textToSpeech: true,
    advancedModels: true,
    customBots: true
  },
  limits: {
    apiCalls: 1000,
    storageGB: 10,
    speechToTextMinutes: 60,
    textToSpeechCharacters: 1000000,
    customBots: 10
  }
}
*/

// Usage example
const tieredAccess = new TieredAccessManager();

// In API handler
async function handleFeatureRequest(req, res) {
  const userId = req.user.uid;
  const feature = 'textToSpeech';
  
  // Check if user has access to the feature
  const accessCheck = await tieredAccess.checkAccess(userId, feature);
  
  if (!accessCheck.allowed) {
    return res.status(403).json({
      error: accessCheck.reason,
      upgrade: accessCheck.upgrade
    });
  }
  
  // Process the request
  const result = await processFeatureRequest(req.body);
  
  // Increment usage
  await tieredAccess.incrementUsage(userId, feature, calculateUsageAmount(req.body));
  
  return res.status(200).json(result);
}
```

## Environment Variables Configuration

Create a `.env` file for local development and configure Firebase Functions environment variables for production:

```
# Firebase Configuration
FIREBASE_API_KEY=your-firebase-api-key
FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
FIREBASE_MESSAGING_SENDER_ID=your-messaging-sender-id
FIREBASE_APP_ID=your-app-id

# Google Cloud Configuration
GOOGLE_CLOUD_PROJECT_ID=your-project-id
GOOGLE_APPLICATION_CREDENTIALS=path/to/service-account-key.json

# API Keys
GEMINI_API_KEY=your-gemini-api-key

# LLM Configuration
LOCAL_LLM_ENDPOINT=http://localhost:8000
USE_LOCAL_LLM_BY_DEFAULT=true

# Service Configuration
ENABLE_SPEECH_TO_TEXT=true
ENABLE_TEXT_TO_SPEECH=true
ENABLE_TRANSLATION=true
ENABLE_LEARNING=true

# Limits
MAX_AUDIO_DURATION_SECONDS=60
MAX_TEXT_LENGTH=4000
MAX_STORAGE_PER_USER_MB=100
```

## Deployment Instructions

```bash
# Deploy Firebase Functions
firebase deploy --only functions

# Deploy Firebase Hosting
firebase deploy --only hosting

# Deploy Firebase Storage Rules
firebase deploy --only storage

# Deploy Firebase Firestore Rules
firebase deploy --only firestore:rules

# Deploy everything
firebase deploy
```

## Monitoring and Maintenance

Set up monitoring to ensure the system stays within free tier limits:

```javascript
// Example Cloud Function for daily usage monitoring
exports.monitorUsage = functions.pubsub.schedule('every 24 hours').onRun(async (context) => {
  const db = admin.firestore();
  
  // Get all users
  const usersSnapshot = await db.collection('users').get();
  
  // Aggregate usage
  let totalApiCalls = 0;
  let totalStorage = 0;
  let totalSpeechToTextMinutes = 0;
  let totalTextToSpeechCharacters = 0;
  
  usersSnapshot.forEach(doc => {
    const userData = doc.data();
    const usage = userData.usage || {};
    
    totalApiCalls += usage.apiCalls || 0;
    totalStorage += usage.storageUsed || 0;
    totalSpeechToTextMinutes += usage.speechToTextMinutes || 0;
    totalTextToSpeechCharacters += usage.textToSpeechCharacters || 0;
  });
  
  // Check against free tier limits
  const freeTierLimits = {
    firebaseFunctions: 2000000, // 2M invocations/month
    firebaseStorage: 5 * 1024, // 5GB
    speechToText: 60, // 60 minutes/month
    textToSpeech: 4000000 // 4M characters/month
  };
  
  // Calculate percentage of limits used
  const usagePercentages = {
    apiCalls: (totalApiCalls / freeTierLimits.firebaseFunctions) * 100,
    storage: (totalStorage / freeTierLimits.firebaseStorage) * 100,
    speechToText: (totalSpeechToTextMinutes / freeTierLimits.speechToText) * 100,
    textToSpeech: (totalTextToSpeechCharacters / freeTierLimits.textToSpeech) * 100
  };
  
  // Log usage statistics
  console.log('Usage statistics:', {
    totalApiCalls,
    totalStorage,
    totalSpeechToTextMinutes,
    totalTextToSpeechCharacters,
    usagePercentages
  });
  
  // Store usage statistics
  await db.collection('system').doc('usage').set({
    timestamp: admin.firestore.FieldValue.serverTimestamp(),
    totalApiCalls,
    totalStorage,
    totalSpeechToTextMinutes,
    totalTextToSpeechCharacters,
    usagePercentages
  });
  
  // Send alerts if approaching limits
  for (const [service, percentage] of Object.entries(usagePercentages)) {
    if (percentage > 80) {
      // Send alert
      console.warn(`Warning: ${service} usage at ${percentage.toFixed(2)}% of free tier limit`);
      
      // Send email notification
      // ...
    }
  }
  
  return null;
});
```

This implementation plan provides a comprehensive approach to setting up the Firebase and Google Cloud components of the Synapse-OD Hub system while ensuring it stays within the free tier limits. The plan includes detailed code examples for key functionality, optimization strategies, and monitoring mechanisms.

