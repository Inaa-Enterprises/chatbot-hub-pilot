"""
Integration routes for the Integration API.
"""

from flask import Blueprint, request, jsonify
import logging
from src.services.llm_service import LLMService
from src.services.bot_service import BotService
from src.services.speech_service import SpeechService
from src.services.learning_service import LearningService

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create blueprint
integration_bp = Blueprint('integration', __name__)

# Create services
llm_service = LLMService()
bot_service = BotService()
speech_service = SpeechService()
learning_service = LearningService()

@integration_bp.route('/health', methods=['GET'])
def health():
    """
    Check the health of all services.
    """
    llm_health = llm_service.health_check()
    bot_health = bot_service.health_check()
    speech_health = speech_service.health_check()
    learning_health = learning_service.health_check()
    
    return jsonify({
        "status": "ok",
        "services": {
            "llm": llm_health,
            "bot": bot_health,
            "speech": speech_health,
            "learning": learning_health
        }
    })

@integration_bp.route('/chat', methods=['POST'])
def chat():
    """
    Send a message to a bot and get a response.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    required_fields = ["bot_id", "conversation_id", "message"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400
    
    bot_id = data["bot_id"]
    conversation_id = data["conversation_id"]
    message = data["message"]
    user_id = data.get("user_id", "anonymous")
    
    # Send message to bot
    response = bot_service.send_message(
        bot_id=bot_id,
        conversation_id=conversation_id,
        message=message,
        user_id=user_id
    )
    
    return jsonify(response)

@integration_bp.route('/speech-to-text', methods=['POST'])
def speech_to_text():
    """
    Convert speech to text.
    """
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400
    
    audio_file = request.files['audio']
    language_code = request.form.get('language_code', 'en-US')
    
    # Save the audio file temporarily
    temp_path = f"/tmp/{audio_file.filename}"
    audio_file.save(temp_path)
    
    # Convert speech to text
    result = speech_service.speech_to_text(
        audio_file_path=temp_path,
        language_code=language_code
    )
    
    return jsonify(result)

@integration_bp.route('/text-to-speech', methods=['POST'])
def text_to_speech():
    """
    Convert text to speech.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    if "text" not in data:
        return jsonify({"error": "Missing required field: text"}), 400
    
    text = data["text"]
    language_code = data.get("language_code", "en-US")
    voice_name = data.get("voice_name", "en-US-Neural2-F")
    
    # Convert text to speech
    result = speech_service.text_to_speech(
        text=text,
        language_code=language_code,
        voice_name=voice_name
    )
    
    if result["status"] == "ok":
        # Return the audio file
        with open(result["file_path"], "rb") as f:
            audio_data = f.read()
        
        response = jsonify({"status": "ok"})
        response.data = audio_data
        response.headers["Content-Type"] = "audio/mp3"
        response.headers["Content-Disposition"] = f"attachment; filename=speech.mp3"
        
        return response
    else:
        return jsonify(result), 500

@integration_bp.route('/voice-chat', methods=['POST'])
def voice_chat():
    """
    Send a voice message to a bot and get a voice response.
    """
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400
    
    audio_file = request.files['audio']
    bot_id = request.form.get('bot_id')
    conversation_id = request.form.get('conversation_id')
    user_id = request.form.get('user_id', 'anonymous')
    language_code = request.form.get('language_code', 'en-US')
    voice_name = request.form.get('voice_name', 'en-US-Neural2-F')
    
    if not bot_id or not conversation_id:
        return jsonify({"error": "Missing required fields: bot_id, conversation_id"}), 400
    
    # Save the audio file temporarily
    temp_path = f"/tmp/{audio_file.filename}"
    audio_file.save(temp_path)
    
    # Convert speech to text
    stt_result = speech_service.speech_to_text(
        audio_file_path=temp_path,
        language_code=language_code
    )
    
    if stt_result["status"] != "ok":
        return jsonify(stt_result), 500
    
    # Extract the transcription
    transcription = stt_result["result"]["results"][0]["transcript"]
    
    # Send message to bot
    bot_response = bot_service.send_message(
        bot_id=bot_id,
        conversation_id=conversation_id,
        message=transcription,
        user_id=user_id
    )
    
    if bot_response["status"] != "ok":
        return jsonify(bot_response), 500
    
    # Extract the bot's response text
    response_text = bot_response["response"]["text"]
    
    # Convert text to speech
    tts_result = speech_service.text_to_speech(
        text=response_text,
        language_code=language_code,
        voice_name=voice_name
    )
    
    if tts_result["status"] != "ok":
        return jsonify(tts_result), 500
    
    # Return the audio file
    with open(tts_result["file_path"], "rb") as f:
        audio_data = f.read()
    
    response = jsonify({
        "status": "ok",
        "transcription": transcription,
        "response_text": response_text
    })
    response.data = audio_data
    response.headers["Content-Type"] = "audio/mp3"
    response.headers["Content-Disposition"] = f"attachment; filename=response.mp3"
    
    return response

@integration_bp.route('/feedback', methods=['POST'])
def create_feedback():
    """
    Create feedback for a bot response.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    required_fields = ["user_id", "bot_id", "conversation_id", "rating"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400
    
    # Create feedback
    result = learning_service.create_feedback(
        user_id=data["user_id"],
        bot_id=data["bot_id"],
        conversation_id=data["conversation_id"],
        rating=data["rating"],
        feedback_text=data.get("feedback_text"),
        tags=data.get("tags")
    )
    
    if result["status"] == "ok":
        return jsonify(result["feedback"]), 201
    else:
        return jsonify(result), 500

@integration_bp.route('/bots', methods=['POST'])
def create_bot():
    """
    Create a new bot.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    # Create bot
    result = bot_service.create_bot(data)
    
    if result["status"] == "ok":
        return jsonify(result["bot"]), 201
    else:
        return jsonify(result), 500

@integration_bp.route('/bots', methods=['GET'])
def list_bots():
    """
    List all bots.
    """
    result = bot_service.list_bots()
    
    if result["status"] == "ok":
        return jsonify(result["bots"])
    else:
        return jsonify(result), 500

@integration_bp.route('/bots/<bot_id>', methods=['GET'])
def get_bot(bot_id):
    """
    Get a bot by ID.
    """
    result = bot_service.get_bot(bot_id)
    
    if result["status"] == "ok":
        return jsonify(result["bot"])
    else:
        return jsonify(result), 500

@integration_bp.route('/bots/<bot_id>/conversations', methods=['POST'])
def create_conversation(bot_id):
    """
    Create a new conversation with a bot.
    """
    data = request.json or {}
    user_id = data.get("user_id", "anonymous")
    
    # Create conversation
    result = bot_service.create_conversation(bot_id, user_id)
    
    if result["status"] == "ok":
        return jsonify(result["conversation"]), 201
    else:
        return jsonify(result), 500

@integration_bp.route('/models', methods=['GET'])
def list_models():
    """
    List available LLM models.
    """
    result = llm_service.get_models()
    
    if result["status"] == "ok":
        return jsonify(result["models"])
    else:
        return jsonify(result), 500

@integration_bp.route('/voices', methods=['GET'])
def list_voices():
    """
    List available voices for text-to-speech.
    """
    language_code = request.args.get('language_code')
    
    result = speech_service.list_voices(language_code)
    
    if result["status"] == "ok":
        return jsonify(result["voices"])
    else:
        return jsonify(result), 500

