# Integration API Documentation

**Author:** Manus AI  
**Date:** June 7, 2025

## Table of Contents

1. [Introduction](#introduction)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [API Reference](#api-reference)
6. [Component Integration](#component-integration)
7. [Authentication and Security](#authentication-and-security)
8. [Error Handling](#error-handling)
9. [Performance Optimization](#performance-optimization)
10. [Deployment](#deployment)
11. [Troubleshooting](#troubleshooting)
12. [References](#references)

## Introduction

The Integration API is a component of the Synapse-OD Hub that integrates all components and provides a unified interface for clients. It handles requests for chat, speech-to-text, text-to-speech, and other functionalities, routing them to the appropriate services and returning the results.

This document provides detailed information about the Integration API component, including its architecture, installation, configuration, and API reference.

## Architecture

The Integration API is built on a Flask web framework and provides a RESTful API for interacting with all components of the Synapse-OD Hub system. It consists of the following main components:

1. **API Server**: A Flask application that handles HTTP requests and responses.
2. **Service Clients**: Clients that communicate with the various services (LLM Server, Child Bot System, Speech Service, Learning Module).
3. **Request Router**: A component that routes requests to the appropriate service.
4. **Response Processor**: A component that processes responses from services before returning them to clients.
5. **Health Monitor**: A component that monitors the health of all services.

The API is designed to be scalable, maintainable, and easy to deploy. It provides a unified interface for clients, abstracting away the complexity of the underlying services.

## Installation

### Prerequisites

- Python 3.9+
- LLM Server
- Child Bot System
- Speech Service
- Learning Module
- Docker (optional, for containerized deployment)

### Installation Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/synapse-od-hub.git
   cd synapse-od-hub/integration
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

4. Start the server:
   ```bash
   python src/main.py
   ```

### Docker Installation

1. Build the Docker image:
   ```bash
   docker build -t integration-api .
   ```

2. Run the Docker container:
   ```bash
   docker run -p 3005:3005 -e LLM_API_URL=http://host.docker.internal:3001/api -e BOT_API_URL=http://host.docker.internal:3002/api -e SPEECH_API_URL=http://host.docker.internal:3003/api -e LEARNING_API_URL=http://host.docker.internal:3004 integration-api
   ```

## Configuration

The Integration API can be configured using environment variables or a configuration file. Here are the available configuration options:

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port to run the server on | `3005` |
| `LLM_API_URL` | URL of the LLM Server API | `http://localhost:3001/api` |
| `BOT_API_URL` | URL of the Child Bot System API | `http://localhost:3002/api` |
| `SPEECH_API_URL` | URL of the Speech Service API | `http://localhost:3003/api` |
| `LEARNING_API_URL` | URL of the Learning Module API | `http://localhost:3004` |
| `LLM_API_KEY` | API key for the LLM Server | `test-api-key` |
| `ENABLE_CORS` | Whether to enable CORS | `true` |
| `LOG_LEVEL` | Logging level | `INFO` |

You can set these variables in a `.env` file or directly in the environment.

## API Reference

### Endpoints

#### Health Check

```
GET /health
```

Check the health of the Integration API.

**Response Example:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

#### API Health Check

```
GET /api/health
```

Check the health of all services.

**Response Example:**
```json
{
  "status": "ok",
  "services": {
    "llm": {
      "status": "ok",
      "details": {
        "version": "1.0.0",
        "models": ["vicuna-13b", "gpt-4"]
      }
    },
    "bot": {
      "status": "ok",
      "details": {
        "version": "1.0.0",
        "bots": 5
      }
    },
    "speech": {
      "status": "ok",
      "details": {
        "version": "1.0.0",
        "stt": "ok",
        "tts": "ok"
      }
    },
    "learning": {
      "status": "ok",
      "details": {
        "version": "1.0.0",
        "examples": 1000,
        "jobs": 10
      }
    }
  }
}
```

#### Chat

```
POST /api/chat
```

Send a message to a bot and get a response.

**Request Body:**
```json
{
  "bot_id": "bot-123",
  "conversation_id": "conv-456",
  "message": "Hello, how are you?",
  "user_id": "user-789"
}
```

**Response Example:**
```json
{
  "status": "ok",
  "response": {
    "text": "I'm doing well, thank you for asking!",
    "message_id": "msg-123",
    "timestamp": 1623456789
  }
}
```

#### Speech to Text

```
POST /api/speech-to-text
```

Convert speech to text.

**Request:**
Form data with the following fields:
- `audio`: Audio file (WAV, MP3, FLAC, etc.)
- `language_code` (optional): Language code (e.g., `en-US`, `fr-FR`)
- `model` (optional): Speech recognition model to use
- `enhanced` (optional): Whether to use enhanced speech recognition

**Response Example:**
```json
{
  "status": "ok",
  "result": {
    "results": [
      {
        "transcript": "Hello, this is a test of the speech-to-text API.",
        "confidence": 0.98
      }
    ],
    "language_code": "en-US",
    "success": true
  }
}
```

#### Text to Speech

```
POST /api/text-to-speech
```

Convert text to speech.

**Request Body:**
```json
{
  "text": "Hello, this is a test of the text-to-speech API.",
  "language_code": "en-US",
  "voice_name": "en-US-Neural2-F"
}
```

**Response:**
Audio file (MP3, WAV, etc.) with the following headers:
- `Content-Type`: Audio MIME type (e.g., `audio/mp3`)
- `Content-Disposition`: Attachment with filename

#### Voice Chat

```
POST /api/voice-chat
```

Send a voice message to a bot and get a voice response.

**Request:**
Form data with the following fields:
- `audio`: Audio file (WAV, MP3, FLAC, etc.)
- `bot_id`: ID of the bot
- `conversation_id`: ID of the conversation
- `user_id` (optional): ID of the user
- `language_code` (optional): Language code (e.g., `en-US`, `fr-FR`)
- `voice_name` (optional): Voice name for the response

**Response:**
Audio file (MP3, WAV, etc.) with the following headers:
- `Content-Type`: Audio MIME type (e.g., `audio/mp3`)
- `Content-Disposition`: Attachment with filename

**Response JSON:**
```json
{
  "status": "ok",
  "transcription": "Hello, how are you?",
  "response_text": "I'm doing well, thank you for asking!"
}
```

#### Feedback

```
POST /api/feedback
```

Create feedback for a bot response.

**Request Body:**
```json
{
  "user_id": "user-123",
  "bot_id": "bot-456",
  "conversation_id": "conv-789",
  "rating": 5,
  "feedback_text": "Great response!",
  "tags": ["helpful", "accurate"]
}
```

**Response Example:**
```json
{
  "id": "feedback-123",
  "user_id": "user-123",
  "bot_id": "bot-456",
  "conversation_id": "conv-789",
  "rating": 5,
  "feedback_text": "Great response!",
  "tags": ["helpful", "accurate"],
  "created_at": 1623456789
}
```

#### List Bots

```
GET /api/bots
```

Get a list of all bots.

**Response Example:**
```json
[
  {
    "id": "bot-123",
    "name": "Customer Support Bot",
    "description": "A bot for customer support",
    "created_at": 1623456789
  },
  {
    "id": "bot-456",
    "name": "Sales Bot",
    "description": "A bot for sales inquiries",
    "created_at": 1623456790
  }
]
```

#### Create Bot

```
POST /api/bots
```

Create a new bot.

**Request Body:**
```json
{
  "name": "New Bot",
  "description": "A new bot for testing",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123"
}
```

**Response Example:**
```json
{
  "id": "bot-789",
  "name": "New Bot",
  "description": "A new bot for testing",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123",
  "created_at": 1623456791
}
```

#### Get Bot

```
GET /api/bots/{bot_id}
```

Get a bot by ID.

**Response Example:**
```json
{
  "id": "bot-123",
  "name": "Customer Support Bot",
  "description": "A bot for customer support",
  "model_id": "vicuna-13b",
  "knowledge_base_id": "kb-123",
  "created_at": 1623456789
}
```

#### Create Conversation

```
POST /api/bots/{bot_id}/conversations
```

Create a new conversation with a bot.

**Request Body:**
```json
{
  "user_id": "user-123"
}
```

**Response Example:**
```json
{
  "id": "conv-456",
  "bot_id": "bot-123",
  "user_id": "user-123",
  "created_at": 1623456792
}
```

#### List Models

```
GET /api/models
```

Get a list of available LLM models.

**Response Example:**
```json
[
  {
    "id": "vicuna-13b",
    "name": "Vicuna 13B",
    "description": "A 13B parameter language model",
    "type": "local"
  },
  {
    "id": "gpt-4",
    "name": "GPT-4",
    "description": "OpenAI's GPT-4 model",
    "type": "cloud"
  }
]
```

#### List Voices

```
GET /api/voices
```

Get a list of available voices for text-to-speech.

**Query Parameters:**
- `language_code` (optional): Filter voices by language code.

**Response Example:**
```json
[
  {
    "name": "en-US-Neural2-F",
    "language_codes": ["en-US"],
    "ssml_gender": "FEMALE",
    "natural_sample_rate_hertz": 24000
  },
  {
    "name": "en-US-Neural2-M",
    "language_codes": ["en-US"],
    "ssml_gender": "MALE",
    "natural_sample_rate_hertz": 24000
  }
]
```

## Component Integration

The Integration API integrates with all components of the Synapse-OD Hub system. This section provides information about how the API integrates with each component.

### LLM Server Integration

The Integration API integrates with the LLM Server to provide access to large language models. It communicates with the LLM Server using HTTP requests to the following endpoints:

- `/health`: Check the health of the LLM Server.
- `/models`: Get a list of available models.
- `/chat`: Generate a chat completion.
- `/completions`: Generate a text completion.

The API handles authentication with the LLM Server using an API key.

### Child Bot System Integration

The Integration API integrates with the Child Bot System to provide access to child bots. It communicates with the Child Bot System using HTTP requests to the following endpoints:

- `/health`: Check the health of the Child Bot System.
- `/bots`: Create, list, and get bots.
- `/bots/{bot_id}/conversations`: Create and manage conversations.
- `/bots/{bot_id}/conversations/{conversation_id}/messages`: Send and receive messages.

The API handles routing of requests to the appropriate bot and conversation.

### Speech Service Integration

The Integration API integrates with the Speech Service to provide speech-to-text and text-to-speech capabilities. It communicates with the Speech Service using HTTP requests to the following endpoints:

- `/health`: Check the health of the Speech Service.
- `/speech/stt`: Convert speech to text.
- `/speech/tts`: Convert text to speech.
- `/speech/tts/voices`: Get a list of available voices.

The API handles file uploads and downloads for audio files.

### Learning Module Integration

The Integration API integrates with the Learning Module to provide learning capabilities. It communicates with the Learning Module using HTTP requests to the following endpoints:

- `/health`: Check the health of the Learning Module.
- `/feedback`: Create and manage feedback.
- `/examples`: Create and manage training examples.
- `/jobs`: Create and manage training jobs.

The API handles the collection and routing of feedback to the Learning Module.

## Authentication and Security

The Integration API implements several security measures to protect the system and its data.

### API Key Authentication

The API uses API key authentication for the LLM Server. The API key is configured using the `LLM_API_KEY` environment variable and is included in the `X-API-Key` header for requests to the LLM Server.

### CORS

The API supports Cross-Origin Resource Sharing (CORS) to allow web applications to access the API from different domains. CORS can be enabled or disabled using the `ENABLE_CORS` environment variable.

### Input Validation

The API validates all input data to prevent injection attacks and other security vulnerabilities. It checks that:

- Required fields are present
- Field values are of the correct type
- Field values are within acceptable ranges
- File uploads are of the correct type and size

### Error Handling

The API implements comprehensive error handling to prevent information leakage and ensure a consistent user experience. It returns appropriate HTTP status codes and error messages for different types of errors.

### Logging

The API logs all requests and responses for security monitoring and auditing purposes. It logs:

- Request method and URL
- Request headers and body
- Response status code and body
- Error messages and stack traces (in development mode only)

## Error Handling

The Integration API implements comprehensive error handling to ensure a consistent user experience and facilitate troubleshooting.

### Error Response Format

All error responses follow a consistent format:

```json
{
  "error": {
    "code": "error_code",
    "message": "Human-readable error message",
    "details": {
      "field": "Additional information about the error"
    }
  }
}
```

### HTTP Status Codes

The API uses appropriate HTTP status codes for different types of errors:

- `400 Bad Request`: Invalid input data
- `401 Unauthorized`: Missing or invalid authentication
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `409 Conflict`: Resource already exists
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server error
- `503 Service Unavailable`: Service unavailable

### Error Logging

The API logs all errors for troubleshooting purposes. It logs:

- Error code and message
- Request method and URL
- Request headers and body
- Stack trace (in development mode only)

### Error Handling Strategies

The API implements several strategies for handling errors:

1. **Validation errors**: Return a `400 Bad Request` with details about the validation errors.
2. **Authentication errors**: Return a `401 Unauthorized` with a message about the authentication error.
3. **Resource not found errors**: Return a `404 Not Found` with a message about the missing resource.
4. **Service unavailable errors**: Return a `503 Service Unavailable` with a message about the unavailable service.
5. **Internal errors**: Return a `500 Internal Server Error` with a generic message to avoid information leakage.

## Performance Optimization

The Integration API includes several optimizations to improve performance:

### Caching

The API implements caching for:

- Service health checks
- Model lists
- Voice lists
- Bot lists

This reduces the number of requests to the underlying services and improves response times.

### Connection Pooling

The API uses connection pooling for HTTP requests to the underlying services. This reduces the overhead of establishing new connections for each request.

### Request Batching

For high-throughput scenarios, the API supports batching of requests to the underlying services. This can significantly improve performance when processing multiple requests simultaneously.

### Response Streaming

The API supports streaming responses for chat and text-to-speech endpoints. This allows the client to start receiving the response before the entire generation is complete, improving the perceived responsiveness of the system.

## Deployment

The Integration API can be deployed in various environments. This section provides information about deploying the API in different environments.

### Local Deployment

For local development and testing, you can run the API directly on your machine:

```bash
python src/main.py
```

### Docker Deployment

For containerized deployment, you can use Docker:

```bash
docker build -t integration-api .
docker run -p 3005:3005 -e LLM_API_URL=http://host.docker.internal:3001/api -e BOT_API_URL=http://host.docker.internal:3002/api -e SPEECH_API_URL=http://host.docker.internal:3003/api -e LEARNING_API_URL=http://host.docker.internal:3004 integration-api
```

### Docker Compose Deployment

For deploying the entire Synapse-OD Hub system, you can use Docker Compose:

```bash
docker-compose up -d
```

### Cloud Deployment

For cloud deployment, you can use various cloud platforms:

#### Google Cloud Run

```bash
gcloud builds submit --tag gcr.io/your-project/integration-api
gcloud run deploy integration-api --image gcr.io/your-project/integration-api --platform managed
```

#### AWS Elastic Beanstalk

```bash
eb init -p docker integration-api
eb create integration-api-env
```

#### Azure Container Instances

```bash
az container create --resource-group your-resource-group --name integration-api --image your-registry/integration-api --dns-name-label integration-api --ports 3005
```

## Troubleshooting

### Common Issues

#### Service Connection Errors

If the API cannot connect to a service, check that:

1. The service is running.
2. The service URL is correctly configured.
3. There are no firewall or network issues blocking the connection.
4. The service is not overloaded or rate-limiting requests.

#### Authentication Errors

If the API encounters authentication errors with the LLM Server, check that:

1. The `LLM_API_KEY` environment variable is set correctly.
2. The LLM Server is configured to accept the API key.
3. The API key has not expired or been revoked.

#### File Upload Errors

If the API encounters errors with file uploads, check that:

1. The file is of a supported type.
2. The file is not too large.
3. The file is not corrupted.
4. There is sufficient disk space for storing the file.

#### High Response Times

If the API has high response times, check that:

1. The underlying services are responsive.
2. The API is not overloaded with requests.
3. The caching mechanisms are working correctly.
4. The connection pooling is configured correctly.

### Logs

The Integration API logs information about requests, responses, and errors to help with troubleshooting. By default, logs are written to the console and to a log file (`integration_api.log`).

To increase the log level for more detailed information, set the `LOG_LEVEL` environment variable:

```
LOG_LEVEL=DEBUG
```

## References

1. [Flask Documentation](https://flask.palletsprojects.com/)
2. [Docker Documentation](https://docs.docker.com/)
3. [Google Cloud Run Documentation](https://cloud.google.com/run/docs)
4. [AWS Elastic Beanstalk Documentation](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/Welcome.html)
5. [Azure Container Instances Documentation](https://docs.microsoft.com/en-us/azure/container-instances/)
6. [RESTful API Design](https://restfulapi.net/)
7. [HTTP Status Codes](https://httpstatuses.com/)

