"""
API for the learning service.

This module provides a Flask API for interacting with the learning service.
"""

import os
import json
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS
from learning_service import (
    LearningService,
    FeedbackEntry,
    TrainingExample,
    ModelTrainingJob
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Create learning service
learning_service = LearningService()

@app.route('/health', methods=['GET'])
def health():
    """
    Check the health of the learning service.
    """
    return jsonify({
        "status": "ok",
        "service": "learning_api"
    })

@app.route('/feedback', methods=['POST'])
def create_feedback():
    """
    Create a new feedback entry.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    required_fields = ["user_id", "bot_id", "conversation_id", "rating"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400
    
    try:
        feedback = FeedbackEntry(
            user_id=data["user_id"],
            bot_id=data["bot_id"],
            conversation_id=data["conversation_id"],
            message_id=data.get("message_id", ""),
            rating=data["rating"],
            feedback_text=data.get("feedback_text"),
            tags=data.get("tags")
        )
        
        learning_service.save_feedback(feedback)
        
        return jsonify(feedback.to_dict()), 201
    
    except Exception as e:
        logger.exception("Error creating feedback")
        return jsonify({"error": str(e)}), 500

@app.route('/feedback/<feedback_id>', methods=['GET'])
def get_feedback(feedback_id):
    """
    Get a feedback entry by ID.
    """
    feedback = learning_service.get_feedback(feedback_id)
    
    if not feedback:
        return jsonify({"error": "Feedback not found"}), 404
    
    return jsonify(feedback.to_dict())

@app.route('/feedback', methods=['GET'])
def list_feedback():
    """
    List feedback entries with optional filtering.
    """
    bot_id = request.args.get('bot_id')
    user_id = request.args.get('user_id')
    min_rating = request.args.get('min_rating')
    max_rating = request.args.get('max_rating')
    
    # Convert rating parameters to integers if provided
    if min_rating:
        try:
            min_rating = int(min_rating)
        except ValueError:
            return jsonify({"error": "min_rating must be an integer"}), 400
    
    if max_rating:
        try:
            max_rating = int(max_rating)
        except ValueError:
            return jsonify({"error": "max_rating must be an integer"}), 400
    
    feedback_entries = learning_service.list_feedback(
        bot_id=bot_id,
        user_id=user_id,
        min_rating=min_rating,
        max_rating=max_rating
    )
    
    return jsonify([feedback.to_dict() for feedback in feedback_entries])

@app.route('/examples', methods=['POST'])
def create_training_example():
    """
    Create a new training example.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    required_fields = ["input_text", "output_text", "source"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400
    
    try:
        example = TrainingExample(
            input_text=data["input_text"],
            output_text=data["output_text"],
            source=data["source"],
            quality_score=data.get("quality_score", 1.0),
            metadata=data.get("metadata")
        )
        
        learning_service.save_training_example(example)
        
        return jsonify(example.to_dict()), 201
    
    except Exception as e:
        logger.exception("Error creating training example")
        return jsonify({"error": str(e)}), 500

@app.route('/examples/<example_id>', methods=['GET'])
def get_training_example(example_id):
    """
    Get a training example by ID.
    """
    example = learning_service.get_training_example(example_id)
    
    if not example:
        return jsonify({"error": "Training example not found"}), 404
    
    return jsonify(example.to_dict())

@app.route('/examples', methods=['GET'])
def list_training_examples():
    """
    List training examples with optional filtering.
    """
    source = request.args.get('source')
    min_quality = request.args.get('min_quality')
    
    # Convert min_quality to float if provided
    if min_quality:
        try:
            min_quality = float(min_quality)
        except ValueError:
            return jsonify({"error": "min_quality must be a number"}), 400
    
    examples = learning_service.list_training_examples(
        source=source,
        min_quality=min_quality
    )
    
    return jsonify([example.to_dict() for example in examples])

@app.route('/examples/generate', methods=['POST'])
def generate_training_examples():
    """
    Generate training examples from feedback.
    """
    data = request.json or {}
    
    min_rating = data.get("min_rating", 4)
    max_examples = data.get("max_examples", 100)
    
    try:
        examples = learning_service.generate_training_examples_from_feedback(
            min_rating=min_rating,
            max_examples=max_examples
        )
        
        return jsonify({
            "examples_generated": len(examples),
            "examples": [example.to_dict() for example in examples]
        })
    
    except Exception as e:
        logger.exception("Error generating training examples")
        return jsonify({"error": str(e)}), 500

@app.route('/jobs', methods=['POST'])
def create_training_job():
    """
    Create a new model training job.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    required_fields = ["model_id", "training_examples"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400
    
    try:
        job = learning_service.create_training_job(
            model_id=data["model_id"],
            training_examples=data["training_examples"],
            hyperparameters=data.get("hyperparameters")
        )
        
        return jsonify(job.to_dict()), 201
    
    except Exception as e:
        logger.exception("Error creating training job")
        return jsonify({"error": str(e)}), 500

@app.route('/jobs/<job_id>', methods=['GET'])
def get_training_job(job_id):
    """
    Get a training job by ID.
    """
    job = learning_service.get_training_job(job_id)
    
    if not job:
        return jsonify({"error": "Training job not found"}), 404
    
    return jsonify(job.to_dict())

@app.route('/jobs/<job_id>/execute', methods=['POST'])
def execute_training_job(job_id):
    """
    Execute a training job.
    """
    job = learning_service.get_training_job(job_id)
    
    if not job:
        return jsonify({"error": "Training job not found"}), 404
    
    try:
        success = learning_service.execute_training_job(job_id)
        
        if success:
            return jsonify({"status": "success", "job_id": job_id})
        else:
            return jsonify({"status": "error", "job_id": job_id}), 500
    
    except Exception as e:
        logger.exception(f"Error executing training job: {job_id}")
        return jsonify({"error": str(e)}), 500

@app.route('/models/<model_id>/metrics', methods=['GET'])
def get_model_metrics(model_id):
    """
    Get performance metrics for a model.
    """
    try:
        metrics = learning_service.get_model_performance_metrics(model_id)
        return jsonify(metrics)
    
    except Exception as e:
        logger.exception(f"Error getting model metrics: {model_id}")
        return jsonify({"error": str(e)}), 500

@app.route('/knowledge-bases/<knowledge_base_id>/update', methods=['POST'])
def update_knowledge_base(knowledge_base_id):
    """
    Update a knowledge base from feedback.
    """
    data = request.json or {}
    
    min_rating = data.get("min_rating", 4)
    max_entries = data.get("max_entries", 50)
    
    try:
        result = learning_service.update_knowledge_base_from_feedback(
            knowledge_base_id=knowledge_base_id,
            min_rating=min_rating,
            max_entries=max_entries
        )
        
        return jsonify(result)
    
    except Exception as e:
        logger.exception(f"Error updating knowledge base: {knowledge_base_id}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Get port from environment variable or use default
    port = int(os.environ.get("PORT", 3004))
    
    # Create data directory if it doesn't exist
    os.makedirs(os.environ.get("LEARNING_DATA_DIR", "learning_data"), exist_ok=True)
    
    print(f"Starting learning API server on port {port}")
    app.run(host='0.0.0.0', port=port, debug=True)

