# Learning Module Documentation

**Author:** Manus AI  
**Date:** June 7, 2025

## Table of Contents

1. [Introduction](#introduction)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [API Reference](#api-reference)
6. [Feedback Collection](#feedback-collection)
7. [Training Example Generation](#training-example-generation)
8. [Model Fine-Tuning](#model-fine-tuning)
9. [Learning Strategies](#learning-strategies)
10. [Performance Monitoring](#performance-monitoring)
11. [Troubleshooting](#troubleshooting)
12. [References](#references)

## Introduction

The Learning Module is a component of the Synapse-OD Hub that implements learning capabilities for all models in the system. It collects feedback from users, generates training examples, and fine-tunes models to improve their performance over time.

This document provides detailed information about the Learning Module component, including its architecture, installation, configuration, and API reference.

## Architecture

The Learning Module is built on a Flask web framework and provides a RESTful API for managing feedback, training examples, and model fine-tuning. It consists of the following main components:

1. **API Server**: A Flask application that handles HTTP requests and responses.
2. **Feedback Service**: A service that collects and manages user feedback.
3. **Example Generator**: A component that generates training examples from feedback and conversations.
4. **Training Manager**: A component that manages model fine-tuning jobs.
5. **Model Evaluator**: A component that evaluates model performance before and after fine-tuning.

The module is designed to be scalable, maintainable, and easy to deploy. It uses a file-based storage system for development and testing, with the option to use cloud storage for production deployments.

## Installation

### Prerequisites

- Python 3.9+
- Docker (optional, for containerized deployment)

### Installation Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/synapse-od-hub.git
   cd synapse-od-hub/learning-module
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

4. Start the server:
   ```bash
   python learning_api.py
   ```

### Docker Installation

1. Build the Docker image:
   ```bash
   docker build -t learning-module .
   ```

2. Run the Docker container:
   ```bash
   docker run -p 3004:3004 -v /path/to/data:/app/data learning-module
   ```

## Configuration

The Learning Module can be configured using environment variables or a configuration file. Here are the available configuration options:

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port to run the server on | `3004` |
| `LEARNING_DATA_DIR` | Directory for storing learning data | `data` |
| `STORAGE_TYPE` | Type of storage to use (`file` or `cloud`) | `file` |
| `CLOUD_STORAGE_BUCKET` | Cloud storage bucket name | `""` |
| `MAX_TRAINING_EXAMPLES` | Maximum number of training examples to store | `10000` |
| `MIN_FEEDBACK_SCORE` | Minimum feedback score to consider for training | `3` |
| `TRAINING_BATCH_SIZE` | Batch size for training | `16` |
| `TRAINING_EPOCHS` | Number of epochs for training | `3` |
| `LEARNING_RATE` | Learning rate for training | `0.001` |

You can set these variables in a `.env` file or directly in the environment.

## API Reference

### Endpoints

#### Health Check

```
GET /health
```

Check the health of the Learning Module.

**Response Example:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

#### Create Feedback

```
POST /feedback
```

Create feedback for a bot response.

**Request Body:**
```json
{
  "user_id": "user-123",
  "bot_id": "bot-456",
  "conversation_id": "conv-789",
  "message_id": "msg-123",
  "rating": 5,
  "feedback_text": "Great response!",
  "tags": ["helpful", "accurate"]
}
```

**Response Example:**
```json
{
  "id": "feedback-123",
  "user_id": "user-123",
  "bot_id": "bot-456",
  "conversation_id": "conv-789",
  "message_id": "msg-123",
  "rating": 5,
  "feedback_text": "Great response!",
  "tags": ["helpful", "accurate"],
  "created_at": 1623456789
}
```

#### List Feedback

```
GET /feedback
```

Get a list of all feedback.

**Query Parameters:**
- `user_id` (optional): Filter feedback by user ID.
- `bot_id` (optional): Filter feedback by bot ID.
- `conversation_id` (optional): Filter feedback by conversation ID.
- `min_rating` (optional): Filter feedback by minimum rating.
- `max_rating` (optional): Filter feedback by maximum rating.
- `tags` (optional): Filter feedback by tags (comma-separated).

**Response Example:**
```json
[
  {
    "id": "feedback-123",
    "user_id": "user-123",
    "bot_id": "bot-456",
    "conversation_id": "conv-789",
    "message_id": "msg-123",
    "rating": 5,
    "feedback_text": "Great response!",
    "tags": ["helpful", "accurate"],
    "created_at": 1623456789
  },
  {
    "id": "feedback-124",
    "user_id": "user-456",
    "bot_id": "bot-456",
    "conversation_id": "conv-790",
    "message_id": "msg-124",
    "rating": 4,
    "feedback_text": "Good response, but could be more detailed.",
    "tags": ["helpful"],
    "created_at": 1623456790
  }
]
```

#### Get Feedback

```
GET /feedback/{feedback_id}
```

Get feedback by ID.

**Response Example:**
```json
{
  "id": "feedback-123",
  "user_id": "user-123",
  "bot_id": "bot-456",
  "conversation_id": "conv-789",
  "message_id": "msg-123",
  "rating": 5,
  "feedback_text": "Great response!",
  "tags": ["helpful", "accurate"],
  "created_at": 1623456789
}
```

#### Create Training Example

```
POST /examples
```

Create a training example.

**Request Body:**
```json
{
  "input_text": "What is the capital of France?",
  "output_text": "The capital of France is Paris.",
  "source": "feedback",
  "feedback_id": "feedback-123",
  "quality_score": 0.9,
  "metadata": {
    "category": "geography",
    "difficulty": "easy"
  }
}
```

**Response Example:**
```json
{
  "id": "example-123",
  "input_text": "What is the capital of France?",
  "output_text": "The capital of France is Paris.",
  "source": "feedback",
  "feedback_id": "feedback-123",
  "quality_score": 0.9,
  "metadata": {
    "category": "geography",
    "difficulty": "easy"
  },
  "created_at": 1623456789
}
```

#### List Training Examples

```
GET /examples
```

Get a list of all training examples.

**Query Parameters:**
- `source` (optional): Filter examples by source.
- `min_quality` (optional): Filter examples by minimum quality score.
- `category` (optional): Filter examples by category.

**Response Example:**
```json
[
  {
    "id": "example-123",
    "input_text": "What is the capital of France?",
    "output_text": "The capital of France is Paris.",
    "source": "feedback",
    "feedback_id": "feedback-123",
    "quality_score": 0.9,
    "metadata": {
      "category": "geography",
      "difficulty": "easy"
    },
    "created_at": 1623456789
  },
  {
    "id": "example-124",
    "input_text": "What is the largest planet in our solar system?",
    "output_text": "The largest planet in our solar system is Jupiter.",
    "source": "feedback",
    "feedback_id": "feedback-124",
    "quality_score": 0.8,
    "metadata": {
      "category": "astronomy",
      "difficulty": "easy"
    },
    "created_at": 1623456790
  }
]
```

#### Get Training Example

```
GET /examples/{example_id}
```

Get a training example by ID.

**Response Example:**
```json
{
  "id": "example-123",
  "input_text": "What is the capital of France?",
  "output_text": "The capital of France is Paris.",
  "source": "feedback",
  "feedback_id": "feedback-123",
  "quality_score": 0.9,
  "metadata": {
    "category": "geography",
    "difficulty": "easy"
  },
  "created_at": 1623456789
}
```

#### Create Training Job

```
POST /jobs
```

Create a training job.

**Request Body:**
```json
{
  "model_id": "vicuna-13b",
  "training_examples": ["example-123", "example-124"],
  "hyperparameters": {
    "learning_rate": 0.001,
    "batch_size": 16,
    "epochs": 3
  },
  "description": "Fine-tuning for geography questions"
}
```

**Response Example:**
```json
{
  "id": "job-123",
  "model_id": "vicuna-13b",
  "training_examples": ["example-123", "example-124"],
  "hyperparameters": {
    "learning_rate": 0.001,
    "batch_size": 16,
    "epochs": 3
  },
  "description": "Fine-tuning for geography questions",
  "status": "created",
  "created_at": 1623456789
}
```

#### List Training Jobs

```
GET /jobs
```

Get a list of all training jobs.

**Query Parameters:**
- `model_id` (optional): Filter jobs by model ID.
- `status` (optional): Filter jobs by status.

**Response Example:**
```json
[
  {
    "id": "job-123",
    "model_id": "vicuna-13b",
    "training_examples": ["example-123", "example-124"],
    "hyperparameters": {
      "learning_rate": 0.001,
      "batch_size": 16,
      "epochs": 3
    },
    "description": "Fine-tuning for geography questions",
    "status": "created",
    "created_at": 1623456789
  },
  {
    "id": "job-124",
    "model_id": "vicuna-13b",
    "training_examples": ["example-125", "example-126"],
    "hyperparameters": {
      "learning_rate": 0.001,
      "batch_size": 16,
      "epochs": 3
    },
    "description": "Fine-tuning for astronomy questions",
    "status": "completed",
    "created_at": 1623456790,
    "completed_at": 1623456800,
    "metrics": {
      "loss": 0.1,
      "accuracy": 0.9
    }
  }
]
```

#### Get Training Job

```
GET /jobs/{job_id}
```

Get a training job by ID.

**Response Example:**
```json
{
  "id": "job-123",
  "model_id": "vicuna-13b",
  "training_examples": ["example-123", "example-124"],
  "hyperparameters": {
    "learning_rate": 0.001,
    "batch_size": 16,
    "epochs": 3
  },
  "description": "Fine-tuning for geography questions",
  "status": "created",
  "created_at": 1623456789
}
```

#### Execute Training Job

```
POST /jobs/{job_id}/execute
```

Execute a training job.

**Response Example:**
```json
{
  "id": "job-123",
  "status": "running",
  "started_at": 1623456800
}
```

#### Cancel Training Job

```
POST /jobs/{job_id}/cancel
```

Cancel a training job.

**Response Example:**
```json
{
  "id": "job-123",
  "status": "cancelled",
  "cancelled_at": 1623456800
}
```

#### Get Training Job Metrics

```
GET /jobs/{job_id}/metrics
```

Get metrics for a training job.

**Response Example:**
```json
{
  "id": "job-123",
  "metrics": {
    "loss": 0.1,
    "accuracy": 0.9,
    "epochs": [
      {
        "epoch": 1,
        "loss": 0.3,
        "accuracy": 0.7
      },
      {
        "epoch": 2,
        "loss": 0.2,
        "accuracy": 0.8
      },
      {
        "epoch": 3,
        "loss": 0.1,
        "accuracy": 0.9
      }
    ]
  }
}
```

## Feedback Collection

The Learning Module collects feedback from users to improve the performance of the models. This section provides information about the feedback collection process.

### Feedback Types

The module supports different types of feedback:

1. **Rating**: A numerical rating (1-5) indicating the quality of the response.
2. **Text**: A text description of the feedback.
3. **Tags**: Keywords or categories associated with the feedback.

### Feedback Collection Process

The feedback collection process involves the following steps:

1. **User interaction**: The user interacts with a bot and receives a response.
2. **Feedback request**: The system requests feedback from the user.
3. **Feedback submission**: The user submits feedback (rating, text, tags).
4. **Feedback storage**: The feedback is stored in the system.
5. **Feedback analysis**: The feedback is analyzed to identify patterns and areas for improvement.

### Feedback Quality Control

To ensure the quality of the feedback, the module implements several quality control measures:

1. **Validation**: Feedback is validated to ensure it meets the required format and criteria.
2. **Filtering**: Low-quality or spam feedback is filtered out.
3. **Normalization**: Feedback is normalized to account for different user behaviors and biases.
4. **Aggregation**: Feedback is aggregated to identify trends and patterns.

## Training Example Generation

The Learning Module generates training examples from feedback and conversations. This section provides information about the training example generation process.

### Example Sources

Training examples can be generated from various sources:

1. **Feedback**: Examples generated from user feedback.
2. **Conversations**: Examples generated from user-bot conversations.
3. **Manual**: Examples created manually by system administrators.
4. **External**: Examples imported from external sources.

### Example Generation Process

The example generation process involves the following steps:

1. **Source selection**: Select a source for example generation (feedback, conversations, etc.).
2. **Data extraction**: Extract relevant data from the source.
3. **Example creation**: Create a training example with input and output text.
4. **Quality assessment**: Assess the quality of the example.
5. **Metadata assignment**: Assign metadata to the example (category, difficulty, etc.).
6. **Example storage**: Store the example in the system.

### Example Quality Assessment

To ensure the quality of the training examples, the module implements several quality assessment measures:

1. **Relevance**: Ensure the example is relevant to the model's domain.
2. **Correctness**: Ensure the example's output is correct.
3. **Diversity**: Ensure the examples cover a diverse range of topics and formats.
4. **Complexity**: Assess the complexity of the example.
5. **Uniqueness**: Ensure the example is not a duplicate of existing examples.

## Model Fine-Tuning

The Learning Module fine-tunes models using the generated training examples. This section provides information about the model fine-tuning process.

### Fine-Tuning Process

The fine-tuning process involves the following steps:

1. **Model selection**: Select a model to fine-tune.
2. **Example selection**: Select training examples for fine-tuning.
3. **Hyperparameter selection**: Select hyperparameters for fine-tuning.
4. **Training**: Train the model on the selected examples.
5. **Evaluation**: Evaluate the fine-tuned model's performance.
6. **Deployment**: Deploy the fine-tuned model if it meets the performance criteria.

### Fine-Tuning Techniques

The module supports various fine-tuning techniques:

1. **Full fine-tuning**: Fine-tune all parameters of the model.
2. **Parameter-efficient fine-tuning**: Fine-tune a subset of the model's parameters.
3. **Low-rank adaptation (LoRA)**: Fine-tune using low-rank adaptation.
4. **Quantized fine-tuning**: Fine-tune a quantized model.

### Fine-Tuning Hyperparameters

The module allows customization of various hyperparameters for fine-tuning:

1. **Learning rate**: The step size for gradient descent.
2. **Batch size**: The number of examples processed in each training step.
3. **Epochs**: The number of times the model processes the entire training dataset.
4. **Weight decay**: The regularization parameter to prevent overfitting.
5. **Warmup steps**: The number of steps to gradually increase the learning rate.

## Learning Strategies

The Learning Module implements various learning strategies to improve model performance. This section provides information about the learning strategies used by the module.

### Continuous Learning

The module supports continuous learning, where the model is continuously fine-tuned as new feedback and examples become available. This allows the model to adapt to changing user needs and preferences.

### Active Learning

The module implements active learning, where the system actively selects examples for labeling to maximize learning efficiency. This is particularly useful when labeling resources are limited.

### Transfer Learning

The module leverages transfer learning, where knowledge gained from one task is applied to a different but related task. This allows the model to benefit from pre-existing knowledge.

### Reinforcement Learning from Human Feedback (RLHF)

The module supports reinforcement learning from human feedback, where the model is trained to maximize a reward signal derived from human feedback. This allows the model to align with human preferences.

### Curriculum Learning

The module implements curriculum learning, where examples are presented to the model in order of increasing difficulty. This can lead to faster convergence and better performance.

## Performance Monitoring

The Learning Module monitors the performance of models before and after fine-tuning. This section provides information about the performance monitoring capabilities of the module.

### Metrics

The module tracks various metrics to evaluate model performance:

1. **Loss**: The training and validation loss.
2. **Accuracy**: The accuracy of the model on a validation set.
3. **Perplexity**: A measure of how well the model predicts the next token.
4. **BLEU score**: A measure of the quality of machine translation.
5. **ROUGE score**: A measure of the quality of summarization.
6. **Human evaluation**: Ratings and feedback from human evaluators.

### Monitoring Process

The performance monitoring process involves the following steps:

1. **Baseline establishment**: Establish a baseline performance for the model.
2. **Regular evaluation**: Regularly evaluate the model's performance on a validation set.
3. **Comparison**: Compare the model's performance to the baseline and previous versions.
4. **Alerting**: Alert system administrators if the model's performance degrades.
5. **Reporting**: Generate reports on the model's performance over time.

### A/B Testing

The module supports A/B testing, where different versions of a model are compared to determine which performs better. This allows for data-driven decision-making when deploying new models.

## Troubleshooting

### Common Issues

#### Training Job Failures

If a training job fails, check that:

1. The model ID is valid.
2. The training examples exist and are valid.
3. The hyperparameters are within acceptable ranges.
4. There is sufficient memory and disk space for training.
5. The training process has not been interrupted.

#### Example Generation Failures

If example generation fails, check that:

1. The source data (feedback, conversations) is valid.
2. The extraction process is working correctly.
3. The quality assessment criteria are not too strict.
4. There is sufficient disk space for storing examples.

#### Performance Degradation

If model performance degrades after fine-tuning, check that:

1. The training examples are of high quality.
2. The hyperparameters are appropriate for the task.
3. The model is not overfitting to the training data.
4. The evaluation metrics are appropriate for the task.
5. The baseline comparison is fair and accurate.

### Logs

The Learning Module logs information about requests, responses, and errors to help with troubleshooting. By default, logs are written to the console and to a log file (`learning_api.log`).

To increase the log level for more detailed information, set the `LOG_LEVEL` environment variable:

```
LOG_LEVEL=DEBUG
```

## References

1. [Fine-tuning Language Models](https://huggingface.co/docs/transformers/training)
2. [Reinforcement Learning from Human Feedback](https://arxiv.org/abs/2203.02155)
3. [Active Learning](https://en.wikipedia.org/wiki/Active_learning_(machine_learning))
4. [Curriculum Learning](https://arxiv.org/abs/1904.03626)
5. [Transfer Learning](https://en.wikipedia.org/wiki/Transfer_learning)
6. [Flask Documentation](https://flask.palletsprojects.com/)
7. [Docker Documentation](https://docs.docker.com/)

