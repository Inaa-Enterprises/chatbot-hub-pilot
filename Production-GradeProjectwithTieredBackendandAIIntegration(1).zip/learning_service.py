"""
Learning service for the Synapse-OD Hub system.

This module provides functionality for implementing learning capabilities
for all models in the system, including:
1. Feedback collection and processing
2. Model fine-tuning
3. Knowledge base updates
4. Performance tracking
"""

import os
import json
import time
import logging
import uuid
from typing import Dict, List, Any, Optional
import requests
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class FeedbackEntry:
    """
    Represents a feedback entry for model learning.
    """
    
    def __init__(
        self,
        user_id: str,
        bot_id: str,
        conversation_id: str,
        message_id: str,
        rating: int,
        feedback_text: Optional[str] = None,
        tags: Optional[List[str]] = None,
        id: Optional[str] = None,
        created_at: Optional[float] = None
    ):
        """
        Initialize a new FeedbackEntry instance.
        
        Args:
            user_id: ID of the user who provided the feedback
            bot_id: ID of the bot that received the feedback
            conversation_id: ID of the conversation
            message_id: ID of the specific message
            rating: Numeric rating (1-5)
            feedback_text: Optional text feedback
            tags: Optional tags for categorizing feedback
            id: Unique identifier (generated if not provided)
            created_at: Timestamp when the feedback was created
        """
        self.user_id = user_id
        self.bot_id = bot_id
        self.conversation_id = conversation_id
        self.message_id = message_id
        self.rating = rating
        self.feedback_text = feedback_text
        self.tags = tags or []
        self.id = id or str(uuid.uuid4())
        self.created_at = created_at or time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the feedback entry to a dictionary.
        
        Returns:
            Dict representation of the feedback entry
        """
        return {
            "id": self.id,
            "user_id": self.user_id,
            "bot_id": self.bot_id,
            "conversation_id": self.conversation_id,
            "message_id": self.message_id,
            "rating": self.rating,
            "feedback_text": self.feedback_text,
            "tags": self.tags,
            "created_at": self.created_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FeedbackEntry':
        """
        Create a FeedbackEntry instance from a dictionary.
        
        Args:
            data: Dictionary containing feedback entry data
            
        Returns:
            FeedbackEntry instance
        """
        return cls(
            user_id=data.get("user_id"),
            bot_id=data.get("bot_id"),
            conversation_id=data.get("conversation_id"),
            message_id=data.get("message_id"),
            rating=data.get("rating"),
            feedback_text=data.get("feedback_text"),
            tags=data.get("tags"),
            id=data.get("id"),
            created_at=data.get("created_at")
        )


class TrainingExample:
    """
    Represents a training example for model fine-tuning.
    """
    
    def __init__(
        self,
        input_text: str,
        output_text: str,
        source: str,
        quality_score: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None,
        id: Optional[str] = None,
        created_at: Optional[float] = None
    ):
        """
        Initialize a new TrainingExample instance.
        
        Args:
            input_text: Input text for the model
            output_text: Expected output text
            source: Source of the training example (e.g., "user_feedback", "expert", "generated")
            quality_score: Quality score for the example (0.0 to 1.0)
            metadata: Additional metadata
            id: Unique identifier (generated if not provided)
            created_at: Timestamp when the example was created
        """
        self.input_text = input_text
        self.output_text = output_text
        self.source = source
        self.quality_score = quality_score
        self.metadata = metadata or {}
        self.id = id or str(uuid.uuid4())
        self.created_at = created_at or time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the training example to a dictionary.
        
        Returns:
            Dict representation of the training example
        """
        return {
            "id": self.id,
            "input_text": self.input_text,
            "output_text": self.output_text,
            "source": self.source,
            "quality_score": self.quality_score,
            "metadata": self.metadata,
            "created_at": self.created_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TrainingExample':
        """
        Create a TrainingExample instance from a dictionary.
        
        Args:
            data: Dictionary containing training example data
            
        Returns:
            TrainingExample instance
        """
        return cls(
            input_text=data.get("input_text"),
            output_text=data.get("output_text"),
            source=data.get("source"),
            quality_score=data.get("quality_score", 1.0),
            metadata=data.get("metadata"),
            id=data.get("id"),
            created_at=data.get("created_at")
        )


class ModelTrainingJob:
    """
    Represents a model training job.
    """
    
    def __init__(
        self,
        model_id: str,
        training_examples: List[str],
        hyperparameters: Optional[Dict[str, Any]] = None,
        status: str = "pending",
        progress: float = 0.0,
        result: Optional[Dict[str, Any]] = None,
        id: Optional[str] = None,
        created_at: Optional[float] = None,
        updated_at: Optional[float] = None
    ):
        """
        Initialize a new ModelTrainingJob instance.
        
        Args:
            model_id: ID of the model to train
            training_examples: List of training example IDs
            hyperparameters: Training hyperparameters
            status: Job status (pending, running, completed, failed)
            progress: Training progress (0.0 to 1.0)
            result: Training result
            id: Unique identifier (generated if not provided)
            created_at: Timestamp when the job was created
            updated_at: Timestamp when the job was last updated
        """
        self.model_id = model_id
        self.training_examples = training_examples
        self.hyperparameters = hyperparameters or {}
        self.status = status
        self.progress = progress
        self.result = result or {}
        self.id = id or str(uuid.uuid4())
        self.created_at = created_at or time.time()
        self.updated_at = updated_at or time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the model training job to a dictionary.
        
        Returns:
            Dict representation of the model training job
        """
        return {
            "id": self.id,
            "model_id": self.model_id,
            "training_examples": self.training_examples,
            "hyperparameters": self.hyperparameters,
            "status": self.status,
            "progress": self.progress,
            "result": self.result,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ModelTrainingJob':
        """
        Create a ModelTrainingJob instance from a dictionary.
        
        Args:
            data: Dictionary containing model training job data
            
        Returns:
            ModelTrainingJob instance
        """
        return cls(
            model_id=data.get("model_id"),
            training_examples=data.get("training_examples", []),
            hyperparameters=data.get("hyperparameters"),
            status=data.get("status", "pending"),
            progress=data.get("progress", 0.0),
            result=data.get("result"),
            id=data.get("id"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at")
        )


class LearningService:
    """
    Service for implementing learning capabilities for models.
    """
    
    def __init__(self, data_dir: str = None):
        """
        Initialize the learning service.
        
        Args:
            data_dir: Directory for storing learning data
        """
        self.data_dir = data_dir or os.environ.get("LEARNING_DATA_DIR", "learning_data")
        self.feedback_dir = os.path.join(self.data_dir, "feedback")
        self.examples_dir = os.path.join(self.data_dir, "examples")
        self.jobs_dir = os.path.join(self.data_dir, "jobs")
        self.models_dir = os.path.join(self.data_dir, "models")
        
        # Create directories if they don't exist
        for directory in [self.data_dir, self.feedback_dir, self.examples_dir, self.jobs_dir, self.models_dir]:
            os.makedirs(directory, exist_ok=True)
    
    def save_feedback(self, feedback: FeedbackEntry) -> str:
        """
        Save feedback to storage.
        
        Args:
            feedback: Feedback entry to save
            
        Returns:
            Path to the saved file
        """
        file_path = os.path.join(self.feedback_dir, f"{feedback.id}.json")
        
        with open(file_path, 'w') as f:
            json.dump(feedback.to_dict(), f, indent=2)
        
        logger.info(f"Saved feedback: {feedback.id}")
        
        return file_path
    
    def get_feedback(self, feedback_id: str) -> Optional[FeedbackEntry]:
        """
        Get feedback by ID.
        
        Args:
            feedback_id: ID of the feedback to get
            
        Returns:
            Feedback entry or None if not found
        """
        file_path = os.path.join(self.feedback_dir, f"{feedback_id}.json")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            return FeedbackEntry.from_dict(data)
        except Exception as e:
            logger.exception(f"Error loading feedback: {feedback_id}")
            return None
    
    def list_feedback(
        self,
        bot_id: Optional[str] = None,
        user_id: Optional[str] = None,
        min_rating: Optional[int] = None,
        max_rating: Optional[int] = None
    ) -> List[FeedbackEntry]:
        """
        List feedback entries with optional filtering.
        
        Args:
            bot_id: Optional bot ID to filter by
            user_id: Optional user ID to filter by
            min_rating: Optional minimum rating to filter by
            max_rating: Optional maximum rating to filter by
            
        Returns:
            List of feedback entries
        """
        feedback_entries = []
        
        for filename in os.listdir(self.feedback_dir):
            if not filename.endswith('.json'):
                continue
            
            file_path = os.path.join(self.feedback_dir, filename)
            
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                feedback = FeedbackEntry.from_dict(data)
                
                # Apply filters
                if bot_id and feedback.bot_id != bot_id:
                    continue
                if user_id and feedback.user_id != user_id:
                    continue
                if min_rating is not None and feedback.rating < min_rating:
                    continue
                if max_rating is not None and feedback.rating > max_rating:
                    continue
                
                feedback_entries.append(feedback)
            except Exception as e:
                logger.exception(f"Error loading feedback from {file_path}")
        
        return feedback_entries
    
    def save_training_example(self, example: TrainingExample) -> str:
        """
        Save a training example to storage.
        
        Args:
            example: Training example to save
            
        Returns:
            Path to the saved file
        """
        file_path = os.path.join(self.examples_dir, f"{example.id}.json")
        
        with open(file_path, 'w') as f:
            json.dump(example.to_dict(), f, indent=2)
        
        logger.info(f"Saved training example: {example.id}")
        
        return file_path
    
    def get_training_example(self, example_id: str) -> Optional[TrainingExample]:
        """
        Get a training example by ID.
        
        Args:
            example_id: ID of the training example to get
            
        Returns:
            Training example or None if not found
        """
        file_path = os.path.join(self.examples_dir, f"{example_id}.json")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            return TrainingExample.from_dict(data)
        except Exception as e:
            logger.exception(f"Error loading training example: {example_id}")
            return None
    
    def list_training_examples(
        self,
        source: Optional[str] = None,
        min_quality: Optional[float] = None
    ) -> List[TrainingExample]:
        """
        List training examples with optional filtering.
        
        Args:
            source: Optional source to filter by
            min_quality: Optional minimum quality score to filter by
            
        Returns:
            List of training examples
        """
        examples = []
        
        for filename in os.listdir(self.examples_dir):
            if not filename.endswith('.json'):
                continue
            
            file_path = os.path.join(self.examples_dir, filename)
            
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                example = TrainingExample.from_dict(data)
                
                # Apply filters
                if source and example.source != source:
                    continue
                if min_quality is not None and example.quality_score < min_quality:
                    continue
                
                examples.append(example)
            except Exception as e:
                logger.exception(f"Error loading training example from {file_path}")
        
        return examples
    
    def create_training_job(
        self,
        model_id: str,
        training_examples: List[str],
        hyperparameters: Optional[Dict[str, Any]] = None
    ) -> ModelTrainingJob:
        """
        Create a new model training job.
        
        Args:
            model_id: ID of the model to train
            training_examples: List of training example IDs
            hyperparameters: Training hyperparameters
            
        Returns:
            Created model training job
        """
        job = ModelTrainingJob(
            model_id=model_id,
            training_examples=training_examples,
            hyperparameters=hyperparameters
        )
        
        file_path = os.path.join(self.jobs_dir, f"{job.id}.json")
        
        with open(file_path, 'w') as f:
            json.dump(job.to_dict(), f, indent=2)
        
        logger.info(f"Created training job: {job.id} for model: {model_id}")
        
        return job
    
    def get_training_job(self, job_id: str) -> Optional[ModelTrainingJob]:
        """
        Get a training job by ID.
        
        Args:
            job_id: ID of the training job to get
            
        Returns:
            Training job or None if not found
        """
        file_path = os.path.join(self.jobs_dir, f"{job_id}.json")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            return ModelTrainingJob.from_dict(data)
        except Exception as e:
            logger.exception(f"Error loading training job: {job_id}")
            return None
    
    def update_training_job(self, job_id: str, updates: Dict[str, Any]) -> Optional[ModelTrainingJob]:
        """
        Update a training job.
        
        Args:
            job_id: ID of the training job to update
            updates: Dictionary of updates to apply
            
        Returns:
            Updated training job or None if not found
        """
        job = self.get_training_job(job_id)
        
        if not job:
            return None
        
        # Apply updates
        if "status" in updates:
            job.status = updates["status"]
        if "progress" in updates:
            job.progress = updates["progress"]
        if "result" in updates:
            job.result = updates["result"]
        
        job.updated_at = time.time()
        
        # Save the updated job
        file_path = os.path.join(self.jobs_dir, f"{job.id}.json")
        
        with open(file_path, 'w') as f:
            json.dump(job.to_dict(), f, indent=2)
        
        logger.info(f"Updated training job: {job.id}")
        
        return job
    
    def generate_training_examples_from_feedback(
        self,
        min_rating: int = 4,
        max_examples: int = 100
    ) -> List[TrainingExample]:
        """
        Generate training examples from feedback.
        
        Args:
            min_rating: Minimum rating for feedback to be considered
            max_examples: Maximum number of examples to generate
            
        Returns:
            List of generated training examples
        """
        # Get high-rated feedback
        feedback_entries = self.list_feedback(min_rating=min_rating)
        
        # Limit the number of examples
        feedback_entries = feedback_entries[:max_examples]
        
        examples = []
        
        for feedback in feedback_entries:
            # TODO: Implement logic to extract conversation context and response
            # For now, we'll create a placeholder example
            example = TrainingExample(
                input_text=f"This is a placeholder input for feedback {feedback.id}",
                output_text=f"This is a placeholder output for feedback {feedback.id}",
                source="user_feedback",
                quality_score=feedback.rating / 5.0,
                metadata={
                    "feedback_id": feedback.id,
                    "bot_id": feedback.bot_id,
                    "user_id": feedback.user_id
                }
            )
            
            self.save_training_example(example)
            examples.append(example)
        
        return examples
    
    def execute_training_job(self, job_id: str) -> bool:
        """
        Execute a training job.
        
        Args:
            job_id: ID of the training job to execute
            
        Returns:
            True if the job was executed successfully, False otherwise
        """
        job = self.get_training_job(job_id)
        
        if not job:
            logger.error(f"Training job not found: {job_id}")
            return False
        
        if job.status != "pending":
            logger.warning(f"Training job is not pending: {job_id}, status: {job.status}")
            return False
        
        try:
            # Update job status to running
            self.update_training_job(job_id, {"status": "running", "progress": 0.0})
            
            # Load training examples
            examples = []
            for example_id in job.training_examples:
                example = self.get_training_example(example_id)
                if example:
                    examples.append(example)
            
            if not examples:
                logger.error(f"No valid training examples found for job: {job_id}")
                self.update_training_job(job_id, {
                    "status": "failed",
                    "result": {"error": "No valid training examples found"}
                })
                return False
            
            # TODO: Implement actual model training logic
            # For now, we'll simulate training with a delay
            for i in range(10):
                time.sleep(0.5)  # Simulate training step
                progress = (i + 1) / 10
                self.update_training_job(job_id, {"progress": progress})
            
            # Update job status to completed
            self.update_training_job(job_id, {
                "status": "completed",
                "progress": 1.0,
                "result": {
                    "examples_processed": len(examples),
                    "training_loss": 0.01,
                    "validation_loss": 0.02,
                    "completed_at": time.time()
                }
            })
            
            logger.info(f"Training job completed: {job_id}")
            return True
        
        except Exception as e:
            logger.exception(f"Error executing training job: {job_id}")
            self.update_training_job(job_id, {
                "status": "failed",
                "result": {"error": str(e)}
            })
            return False
    
    def create_feedback_from_conversation(
        self,
        conversation_id: str,
        bot_id: str,
        user_id: str,
        rating: int,
        feedback_text: Optional[str] = None,
        tags: Optional[List[str]] = None
    ) -> FeedbackEntry:
        """
        Create feedback from a conversation.
        
        Args:
            conversation_id: ID of the conversation
            bot_id: ID of the bot
            user_id: ID of the user
            rating: Numeric rating (1-5)
            feedback_text: Optional text feedback
            tags: Optional tags for categorizing feedback
            
        Returns:
            Created feedback entry
        """
        # TODO: Implement logic to extract the message ID from the conversation
        # For now, we'll use a placeholder
        message_id = f"msg_{uuid.uuid4()}"
        
        feedback = FeedbackEntry(
            user_id=user_id,
            bot_id=bot_id,
            conversation_id=conversation_id,
            message_id=message_id,
            rating=rating,
            feedback_text=feedback_text,
            tags=tags
        )
        
        self.save_feedback(feedback)
        
        return feedback
    
    def get_model_performance_metrics(self, model_id: str) -> Dict[str, Any]:
        """
        Get performance metrics for a model.
        
        Args:
            model_id: ID of the model
            
        Returns:
            Dictionary of performance metrics
        """
        # TODO: Implement logic to calculate actual performance metrics
        # For now, we'll return placeholder metrics
        return {
            "model_id": model_id,
            "average_rating": 4.2,
            "total_conversations": 150,
            "total_messages": 1200,
            "response_time_ms": 250,
            "accuracy": 0.85,
            "last_updated": datetime.now().isoformat()
        }
    
    def update_knowledge_base_from_feedback(
        self,
        knowledge_base_id: str,
        min_rating: int = 4,
        max_entries: int = 50
    ) -> Dict[str, Any]:
        """
        Update a knowledge base from feedback.
        
        Args:
            knowledge_base_id: ID of the knowledge base to update
            min_rating: Minimum rating for feedback to be considered
            max_entries: Maximum number of entries to add
            
        Returns:
            Dictionary with update results
        """
        # TODO: Implement logic to update the knowledge base
        # For now, we'll return placeholder results
        return {
            "knowledge_base_id": knowledge_base_id,
            "entries_added": 5,
            "entries_updated": 3,
            "total_entries": 120,
            "updated_at": datetime.now().isoformat()
        }

