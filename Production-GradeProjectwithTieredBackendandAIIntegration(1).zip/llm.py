from flask import Blueprint, request, jsonify
import requests
import os
import time
import logging
import json
from functools import wraps

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("llm_server_wrapper.log"),
        logging.StreamHandler()
    ]
)

llm_bp = Blueprint('llm', __name__)

# Configuration
LOCAL_LLM_ENDPOINT = os.environ.get("LOCAL_LLM_ENDPOINT", "http://localhost:8000")
CLOUD_LLM_ENDPOINT = os.environ.get("CLOUD_LLM_ENDPOINT", "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent")
CLOUD_API_KEY = os.environ.get("GEMINI_API_KEY", "")
DEFAULT_TIMEOUT = int(os.environ.get("DEFAULT_TIMEOUT", 30))

# Cache for responses
response_cache = {}
cache_ttl = 3600  # 1 hour

def check_local_availability():
    """Check if the local LLM server is available"""
    try:
        response = requests.get(f"{LOCAL_LLM_ENDPOINT}/health", timeout=2)
        return response.status_code == 200
    except:
        return False

def api_key_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            return jsonify({"error": "API key is required"}), 401
        
        # In a production environment, you would validate the API key against a database
        # For now, we'll use a simple environment variable for demonstration
        valid_api_key = os.environ.get("LLM_API_KEY", "test-api-key")
        if api_key != valid_api_key:
            return jsonify({"error": "Invalid API key"}), 401
        
        return f(*args, **kwargs)
    return decorated_function

@llm_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    local_available = check_local_availability()
    return jsonify({
        "status": "ok",
        "local_llm_available": local_available,
        "cloud_llm_available": bool(CLOUD_API_KEY),
        "timestamp": time.time()
    })

@llm_bp.route('/chat', methods=['POST'])
@api_key_required
def chat():
    """Chat completion endpoint"""
    data = request.json
    messages = data.get('messages', [])
    options = data.get('options', {})
    
    # Generate cache key
    cache_key = str(hash(str(messages) + str(options)))
    
    # Check cache
    if cache_key in response_cache:
        cached_response, timestamp = response_cache[cache_key]
        if time.time() - timestamp < cache_ttl:
            logging.info("Returning cached response")
            return jsonify(cached_response)
    
    # Determine whether to use local or cloud
    use_local = check_local_availability() and not options.get('forceCloud', False)
    
    try:
        if use_local:
            # Call local LLM server
            logging.info("Using local LLM server")
            response = requests.post(
                f"{LOCAL_LLM_ENDPOINT}/v1/chat/completions",
                json={
                    "model": options.get('model', 'vicuna-13b'),
                    "messages": messages,
                    "temperature": options.get('temperature', 0.7),
                    "max_tokens": options.get('maxTokens', 1024),
                    "top_p": options.get('topP', 0.95),
                    "top_k": options.get('topK', 40)
                },
                timeout=options.get('timeout', DEFAULT_TIMEOUT)
            )
            
            if response.status_code == 200:
                result = response.json()
                # Cache the response
                response_cache[cache_key] = (result, time.time())
                return jsonify(result)
            else:
                logging.error(f"Local LLM server error: {response.status_code} - {response.text}")
                # Fall back to cloud if local fails
        
        # Use cloud service
        if not CLOUD_API_KEY:
            return jsonify({"error": "Cloud API key not configured and local server unavailable"}), 503
        
        logging.info("Using cloud LLM service")
        # Format request for cloud service
        cloud_request = {
            "contents": [
                {
                    "role": "USER" if msg["role"] == "user" else "SYSTEM" if msg["role"] == "system" else "MODEL",
                    "parts": [{"text": msg["content"]}]
                } for msg in messages
            ],
            "generationConfig": {
                "temperature": options.get('temperature', 0.7),
                "maxOutputTokens": options.get('maxTokens', 1024),
                "topP": options.get('topP', 0.95),
                "topK": options.get('topK', 40)
            }
        }
        
        response = requests.post(
            CLOUD_LLM_ENDPOINT,
            json=cloud_request,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {CLOUD_API_KEY}"
            },
            timeout=options.get('timeout', DEFAULT_TIMEOUT)
        )
        
        if response.status_code == 200:
            cloud_response = response.json()
            
            # Convert cloud response to match local format
            result = {
                "id": f"cloud-{int(time.time())}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": "cloud-model",
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": cloud_response["candidates"][0]["content"]["parts"][0]["text"]
                    },
                    "finish_reason": "stop"
                }],
                "usage": {
                    "prompt_tokens": -1,
                    "completion_tokens": -1,
                    "total_tokens": -1
                }
            }
            
            # Cache the response
            response_cache[cache_key] = (result, time.time())
            return jsonify(result)
        else:
            logging.error(f"Cloud LLM service error: {response.status_code} - {response.text}")
            return jsonify({"error": f"Cloud service error: {response.status_code}"}), response.status_code
            
    except Exception as e:
        logging.exception("Error processing chat request")
        return jsonify({"error": str(e)}), 500

@llm_bp.route('/models', methods=['GET'])
@api_key_required
def list_models():
    """List available models"""
    models = [
        {
            "id": "vicuna-13b",
            "object": "model",
            "created": int(time.time()),
            "owned_by": "local"
        }
    ]
    
    # Add cloud models if available
    if CLOUD_API_KEY:
        models.append({
            "id": "gemini-pro",
            "object": "model",
            "created": int(time.time()),
            "owned_by": "google"
        })
    
    return jsonify({"data": models})

@llm_bp.route('/completions', methods=['POST'])
@api_key_required
def completions():
    """Text completion endpoint (for compatibility)"""
    data = request.json
    prompt = data.get('prompt', '')
    options = data.get('options', {})
    
    # Convert to chat format
    messages = [{"role": "user", "content": prompt}]
    
    # Call chat endpoint internally
    chat_response = chat()
    
    # If it's a tuple (response, status_code), return it directly
    if isinstance(chat_response, tuple):
        return chat_response
    
    # Otherwise, it's a response object
    response_data = json.loads(chat_response.get_data(as_text=True))
    
    # Convert chat response to completions format
    if "choices" in response_data and len(response_data["choices"]) > 0:
        completion_response = {
            "id": response_data["id"].replace("chat", "cmpl"),
            "object": "text_completion",
            "created": response_data["created"],
            "model": response_data["model"],
            "choices": [{
                "text": response_data["choices"][0]["message"]["content"],
                "index": 0,
                "logprobs": None,
                "finish_reason": response_data["choices"][0]["finish_reason"]
            }],
            "usage": response_data["usage"]
        }
        return jsonify(completion_response)
    else:
        return jsonify(response_data)

