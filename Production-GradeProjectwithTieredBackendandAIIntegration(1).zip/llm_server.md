# LLM Server Documentation

**Author:** Manus AI  
**Date:** June 7, 2025

## Table of Contents

1. [Introduction](#introduction)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [API Reference](#api-reference)
6. [Integration with LMStudio](#integration-with-lmstudio)
7. [Cloud Fallback](#cloud-fallback)
8. [Performance Optimization](#performance-optimization)
9. [Troubleshooting](#troubleshooting)
10. [References](#references)

## Introduction

The LLM Server is a Flask API wrapper for LMStudio that provides access to large language models like Vicuna 13B. It handles requests for text generation, chat completion, and other language model tasks. The server can use either a local model running in LMStudio or fall back to cloud-based models when needed.

This document provides detailed information about the LLM Server component of the Synapse-OD Hub system, including its architecture, installation, configuration, and API reference.

## Architecture

The LLM Server is built on a Flask web framework and provides a RESTful API for interacting with language models. It consists of the following main components:

1. **API Server**: A Flask application that handles HTTP requests and responses.
2. **LLM Client**: A client that communicates with LMStudio's API to access local language models.
3. **Cloud Client**: A client that communicates with cloud-based language models as a fallback.
4. **Model Manager**: A component that manages the available models and their configurations.
5. **Request Handler**: A component that processes incoming requests and routes them to the appropriate client.

The server is designed to be lightweight, efficient, and easy to deploy. It uses a simple API key-based authentication system to secure the API endpoints.

## Installation

### Prerequisites

- Python 3.9+
- LMStudio with Vicuna 13B or equivalent model
- Docker (optional, for containerized deployment)

### Installation Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/synapse-od-hub.git
   cd synapse-od-hub/llm-server
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

4. Start the server:
   ```bash
   python src/main.py
   ```

### Docker Installation

1. Build the Docker image:
   ```bash
   docker build -t llm-server .
   ```

2. Run the Docker container:
   ```bash
   docker run -p 3001:3001 -e LMSTUDIO_URL=http://host.docker.internal:1234/v1 -e CLOUD_API_KEY=your-api-key llm-server
   ```

## Configuration

The LLM Server can be configured using environment variables or a configuration file. Here are the available configuration options:

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port to run the server on | `3001` |
| `LMSTUDIO_URL` | URL of the LMStudio API | `http://localhost:1234/v1` |
| `CLOUD_API_KEY` | API key for cloud-based language models | `""` |
| `DEFAULT_MODEL` | Default model to use | `vicuna-13b` |
| `MAX_TOKENS` | Maximum number of tokens to generate | `1024` |
| `TEMPERATURE` | Temperature for text generation | `0.7` |
| `API_KEY` | API key for authenticating requests | `test-api-key` |

You can set these variables in a `.env` file or directly in the environment.

## API Reference

### Authentication

All API endpoints require an API key to be provided in the `X-API-Key` header.

```
X-API-Key: your-api-key
```

### Endpoints

#### Health Check

```
GET /health
```

Check the health of the LLM Server.

**Response Example:**
```json
{
  "status": "ok",
  "version": "1.0.0",
  "models": ["vicuna-13b", "gpt-4"]
}
```

#### Models

```
GET /models
```

Get a list of available models.

**Response Example:**
```json
{
  "data": [
    {
      "id": "vicuna-13b",
      "name": "Vicuna 13B",
      "description": "A 13B parameter language model",
      "type": "local"
    },
    {
      "id": "gpt-4",
      "name": "GPT-4",
      "description": "OpenAI's GPT-4 model",
      "type": "cloud"
    }
  ]
}
```

#### Chat Completion

```
POST /chat
```

Generate a chat completion.

**Request Body:**
```json
{
  "messages": [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "Hello, how are you?"}
  ],
  "options": {
    "model": "vicuna-13b",
    "temperature": 0.7,
    "maxTokens": 1024,
    "forceCloud": false
  }
}
```

**Response Example:**
```json
{
  "id": "chat-123",
  "object": "chat.completion",
  "created": 1623456789,
  "model": "vicuna-13b",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "I'm doing well, thank you for asking! How can I assist you today?"
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 23,
    "completion_tokens": 15,
    "total_tokens": 38
  }
}
```

#### Text Completion

```
POST /completions
```

Generate a text completion.

**Request Body:**
```json
{
  "prompt": "Once upon a time",
  "options": {
    "model": "vicuna-13b",
    "temperature": 0.7,
    "maxTokens": 1024,
    "forceCloud": false
  }
}
```

**Response Example:**
```json
{
  "id": "cmpl-123",
  "object": "text_completion",
  "created": 1623456789,
  "model": "vicuna-13b",
  "choices": [
    {
      "text": " in a land far, far away, there lived a brave knight named Sir Galahad.",
      "index": 0,
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 4,
    "completion_tokens": 18,
    "total_tokens": 22
  }
}
```

## Integration with LMStudio

The LLM Server integrates with LMStudio to access local language models. LMStudio provides an API that is compatible with the OpenAI API, making it easy to use with the LLM Server.

### Setting Up LMStudio

1. Download and install LMStudio from the [official website](https://lmstudio.ai/).

2. Load the Vicuna 13B model or any other compatible model.

3. Enable the API server in LMStudio:
   - Go to the "API" tab
   - Click "Start Server"
   - Note the server URL (usually `http://localhost:1234/v1`)

4. Configure the LLM Server to use the LMStudio API:
   ```
   LMSTUDIO_URL=http://localhost:1234/v1
   ```

### Model Compatibility

The LLM Server is designed to work with any model that is compatible with the OpenAI API format. This includes models like:

- Vicuna (7B, 13B, 33B)
- Llama 2 (7B, 13B, 70B)
- Mistral (7B)
- And many others

## Cloud Fallback

The LLM Server can fall back to cloud-based language models when the local model is not available or when explicitly requested. This provides a reliable backup option for production environments.

### Configuring Cloud Fallback

To enable cloud fallback, set the `CLOUD_API_KEY` environment variable to your API key for the cloud service.

```
CLOUD_API_KEY=your-api-key
```

### Forcing Cloud Usage

You can force the use of cloud-based models by setting the `forceCloud` option to `true` in the request:

```json
{
  "messages": [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "Hello, how are you?"}
  ],
  "options": {
    "model": "gpt-4",
    "temperature": 0.7,
    "maxTokens": 1024,
    "forceCloud": true
  }
}
```

## Performance Optimization

The LLM Server includes several optimizations to improve performance:

### Caching

The server implements a simple in-memory cache for responses to reduce the load on the language models. The cache is keyed by the request parameters and has a configurable TTL (time to live).

### Batching

For high-throughput scenarios, the server supports batching of requests to the language models. This can significantly improve performance when processing multiple requests simultaneously.

### Streaming

The server supports streaming responses for chat and text completions. This allows the client to start receiving the response before the entire generation is complete, improving the perceived responsiveness of the system.

## Troubleshooting

### Common Issues

#### LMStudio Not Responding

If the LLM Server cannot connect to LMStudio, check that:

1. LMStudio is running and the API server is started.
2. The `LMSTUDIO_URL` environment variable is set correctly.
3. There are no firewall or network issues blocking the connection.

#### Cloud Fallback Not Working

If the cloud fallback is not working, check that:

1. The `CLOUD_API_KEY` environment variable is set correctly.
2. The cloud service is available and the API key is valid.
3. The model specified in the request is available on the cloud service.

#### High Memory Usage

If the server is using too much memory, consider:

1. Reducing the batch size for requests.
2. Limiting the maximum number of tokens in responses.
3. Using a smaller model if available.

### Logs

The LLM Server logs information about requests, responses, and errors to help with troubleshooting. By default, logs are written to the console and to a log file (`llm_api.log`).

To increase the log level for more detailed information, set the `LOG_LEVEL` environment variable:

```
LOG_LEVEL=DEBUG
```

## References

1. [LMStudio Documentation](https://lmstudio.ai/docs)
2. [OpenAI API Reference](https://platform.openai.com/docs/api-reference)
3. [Flask Documentation](https://flask.palletsprojects.com/)
4. [Vicuna Model](https://lmsys.org/blog/2023-03-30-vicuna/)
5. [Docker Documentation](https://docs.docker.com/)

