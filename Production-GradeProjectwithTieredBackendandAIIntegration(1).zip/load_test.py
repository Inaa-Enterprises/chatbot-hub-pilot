#!/usr/bin/env python3
"""
Load testing script for the Synapse-OD Hub system.
"""

import requests
import json
import argparse
import sys
import time
import threading
import random
import logging
from typing import Dict, Any, List, Optional
from concurrent.futures import ThreadPoolExecutor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("load_test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class LoadTester:
    """
    Load tester for the Synapse-OD Hub system.
    """
    
    def __init__(
        self,
        integration_url: str,
        num_users: int = 10,
        requests_per_user: int = 10,
        max_concurrent: int = 5
    ):
        """
        Initialize the load tester.
        
        Args:
            integration_url: URL of the Integration API
            num_users: Number of simulated users
            requests_per_user: Number of requests per user
            max_concurrent: Maximum number of concurrent requests
        """
        self.integration_url = integration_url
        self.num_users = num_users
        self.requests_per_user = requests_per_user
        self.max_concurrent = max_concurrent
        self.users = []
        self.bots = []
        self.conversations = {}
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "total_time": 0,
            "min_time": float('inf'),
            "max_time": 0,
            "avg_time": 0
        }
    
    def setup(self):
        """
        Set up the test environment.
        """
        logger.info("Setting up test environment")
        
        # Create users
        for i in range(self.num_users):
            user_id = f"load-test-user-{i}"
            self.users.append(user_id)
        
        # Create bots
        try:
            response = requests.get(f"{self.integration_url}/api/bots")
            if response.status_code == 200:
                self.bots = response.json()
                if not self.bots:
                    # Create a test bot if none exist
                    self._create_test_bot()
            else:
                # Create a test bot
                self._create_test_bot()
        except Exception as e:
            logger.exception("Error getting bots")
            # Create a test bot
            self._create_test_bot()
        
        # Create conversations for each user with each bot
        for user_id in self.users:
            self.conversations[user_id] = {}
            for bot in self.bots:
                bot_id = bot["id"]
                conversation = self._create_conversation(bot_id, user_id)
                if conversation:
                    self.conversations[user_id][bot_id] = conversation["id"]
        
        logger.info(f"Setup complete. Created {len(self.users)} users and {len(self.bots)} bots.")
    
    def _create_test_bot(self):
        """
        Create a test bot.
        """
        logger.info("Creating test bot")
        try:
            data = {
                "name": "Load Test Bot",
                "description": "A bot for load testing",
                "model_id": "vicuna-13b",
                "knowledge_base_id": "test-kb"
            }
            
            response = requests.post(
                f"{self.integration_url}/api/bots",
                json=data
            )
            
            if response.status_code == 201:
                bot = response.json()
                logger.info(f"Created test bot: {bot['id']}")
                self.bots.append(bot)
            else:
                logger.error(f"Failed to create test bot: {response.status_code} - {response.text}")
        except Exception as e:
            logger.exception("Error creating test bot")
    
    def _create_conversation(self, bot_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Create a conversation.
        
        Args:
            bot_id: ID of the bot
            user_id: ID of the user
            
        Returns:
            Conversation data if successful, None otherwise
        """
        try:
            data = {
                "user_id": user_id
            }
            
            response = requests.post(
                f"{self.integration_url}/api/bots/{bot_id}/conversations",
                json=data
            )
            
            if response.status_code == 201:
                conversation = response.json()
                logger.debug(f"Created conversation: {conversation['id']} for user {user_id} and bot {bot_id}")
                return conversation
            else:
                logger.error(f"Failed to create conversation: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.exception(f"Error creating conversation for user {user_id} and bot {bot_id}")
            return None
    
    def _send_chat_request(self, user_id: str, bot_id: str, conversation_id: str, message: str) -> Dict[str, Any]:
        """
        Send a chat request.
        
        Args:
            user_id: ID of the user
            bot_id: ID of the bot
            conversation_id: ID of the conversation
            message: Message to send
            
        Returns:
            Result of the request
        """
        start_time = time.time()
        result = {
            "success": False,
            "time": 0,
            "error": None
        }
        
        try:
            data = {
                "bot_id": bot_id,
                "conversation_id": conversation_id,
                "message": message,
                "user_id": user_id
            }
            
            response = requests.post(
                f"{self.integration_url}/api/chat",
                json=data
            )
            
            end_time = time.time()
            result["time"] = end_time - start_time
            
            if response.status_code == 200:
                result["success"] = True
            else:
                result["error"] = f"Status code: {response.status_code}, Response: {response.text}"
        except Exception as e:
            end_time = time.time()
            result["time"] = end_time - start_time
            result["error"] = str(e)
        
        return result
    
    def _send_text_to_speech_request(self, text: str) -> Dict[str, Any]:
        """
        Send a text-to-speech request.
        
        Args:
            text: Text to convert to speech
            
        Returns:
            Result of the request
        """
        start_time = time.time()
        result = {
            "success": False,
            "time": 0,
            "error": None
        }
        
        try:
            data = {
                "text": text,
                "language_code": "en-US",
                "voice_name": "en-US-Neural2-F"
            }
            
            response = requests.post(
                f"{self.integration_url}/api/text-to-speech",
                json=data
            )
            
            end_time = time.time()
            result["time"] = end_time - start_time
            
            if response.status_code == 200:
                result["success"] = True
            else:
                result["error"] = f"Status code: {response.status_code}, Response: {response.text}"
        except Exception as e:
            end_time = time.time()
            result["time"] = end_time - start_time
            result["error"] = str(e)
        
        return result
    
    def _send_feedback_request(self, user_id: str, bot_id: str, conversation_id: str) -> Dict[str, Any]:
        """
        Send a feedback request.
        
        Args:
            user_id: ID of the user
            bot_id: ID of the bot
            conversation_id: ID of the conversation
            
        Returns:
            Result of the request
        """
        start_time = time.time()
        result = {
            "success": False,
            "time": 0,
            "error": None
        }
        
        try:
            data = {
                "user_id": user_id,
                "bot_id": bot_id,
                "conversation_id": conversation_id,
                "rating": random.randint(3, 5),
                "feedback_text": "This is a load test feedback",
                "tags": ["load-test"]
            }
            
            response = requests.post(
                f"{self.integration_url}/api/feedback",
                json=data
            )
            
            end_time = time.time()
            result["time"] = end_time - start_time
            
            if response.status_code == 201:
                result["success"] = True
            else:
                result["error"] = f"Status code: {response.status_code}, Response: {response.text}"
        except Exception as e:
            end_time = time.time()
            result["time"] = end_time - start_time
            result["error"] = str(e)
        
        return result
    
    def _worker(self, user_id: str):
        """
        Worker function for a simulated user.
        
        Args:
            user_id: ID of the user
        """
        logger.info(f"Starting worker for user {user_id}")
        
        if not self.bots or user_id not in self.conversations:
            logger.error(f"No bots or conversations for user {user_id}")
            return
        
        for i in range(self.requests_per_user):
            # Select a random bot
            bot = random.choice(self.bots)
            bot_id = bot["id"]
            
            if bot_id not in self.conversations[user_id]:
                logger.error(f"No conversation for user {user_id} and bot {bot_id}")
                continue
            
            conversation_id = self.conversations[user_id][bot_id]
            
            # Select a random request type
            request_type = random.choice(["chat", "tts", "feedback"])
            
            result = None
            if request_type == "chat":
                messages = [
                    "Hello, how are you?",
                    "What's the weather like today?",
                    "Tell me a joke",
                    "What's your name?",
                    "What can you do?",
                    "Tell me about yourself",
                    "What time is it?",
                    "What's the capital of France?",
                    "How does a computer work?",
                    "What's the meaning of life?"
                ]
                message = random.choice(messages)
                result = self._send_chat_request(user_id, bot_id, conversation_id, message)
            elif request_type == "tts":
                texts = [
                    "Hello, this is a test of the text-to-speech API.",
                    "The quick brown fox jumps over the lazy dog.",
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
                    "This is a load test for the Synapse-OD Hub system.",
                    "Testing the performance of the text-to-speech service."
                ]
                text = random.choice(texts)
                result = self._send_text_to_speech_request(text)
            elif request_type == "feedback":
                result = self._send_feedback_request(user_id, bot_id, conversation_id)
            
            # Update stats
            if result:
                self.stats["total_requests"] += 1
                if result["success"]:
                    self.stats["successful_requests"] += 1
                else:
                    self.stats["failed_requests"] += 1
                    logger.error(f"Request failed: {result['error']}")
                
                self.stats["total_time"] += result["time"]
                self.stats["min_time"] = min(self.stats["min_time"], result["time"])
                self.stats["max_time"] = max(self.stats["max_time"], result["time"])
            
            # Sleep for a random time between requests
            time.sleep(random.uniform(0.1, 0.5))
    
    def run(self):
        """
        Run the load test.
        """
        logger.info(f"Starting load test with {self.num_users} users, {self.requests_per_user} requests per user, and {self.max_concurrent} max concurrent requests")
        
        start_time = time.time()
        
        with ThreadPoolExecutor(max_workers=self.max_concurrent) as executor:
            futures = [executor.submit(self._worker, user_id) for user_id in self.users]
            
            # Wait for all workers to complete
            for future in futures:
                future.result()
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Calculate average time
        if self.stats["total_requests"] > 0:
            self.stats["avg_time"] = self.stats["total_time"] / self.stats["total_requests"]
        
        # Print stats
        logger.info("Load test completed")
        logger.info(f"Total time: {total_time:.2f} seconds")
        logger.info(f"Total requests: {self.stats['total_requests']}")
        logger.info(f"Successful requests: {self.stats['successful_requests']}")
        logger.info(f"Failed requests: {self.stats['failed_requests']}")
        logger.info(f"Success rate: {self.stats['successful_requests'] / self.stats['total_requests'] * 100:.2f}%")
        logger.info(f"Requests per second: {self.stats['total_requests'] / total_time:.2f}")
        logger.info(f"Min request time: {self.stats['min_time']:.4f} seconds")
        logger.info(f"Max request time: {self.stats['max_time']:.4f} seconds")
        logger.info(f"Avg request time: {self.stats['avg_time']:.4f} seconds")
        
        return self.stats


def main():
    parser = argparse.ArgumentParser(description='Load test the Synapse-OD Hub system')
    parser.add_argument('--url', default='http://localhost:3005', help='URL of the Integration API')
    parser.add_argument('--users', type=int, default=10, help='Number of simulated users')
    parser.add_argument('--requests', type=int, default=10, help='Number of requests per user')
    parser.add_argument('--concurrent', type=int, default=5, help='Maximum number of concurrent requests')
    
    args = parser.parse_args()
    
    load_tester = LoadTester(
        integration_url=args.url,
        num_users=args.users,
        requests_per_user=args.requests,
        max_concurrent=args.concurrent
    )
    
    load_tester.setup()
    stats = load_tester.run()
    
    # Exit with non-zero status if any requests failed
    if stats["failed_requests"] > 0:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()

