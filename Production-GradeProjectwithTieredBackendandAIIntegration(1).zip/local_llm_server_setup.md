# Local LLM Server Setup with LMStudio

This document outlines the setup and configuration of a local LLM server using LMStudio with Vicuna 13B or an equivalent model. The server will be integrated with the Synapse-OD Hub system to provide local AI processing capabilities.

## Overview

The local LLM server will:
1. Run Vicuna 13B or an equivalent model using LMStudio
2. Expose an API compatible with the OpenAI API format
3. Handle requests from the backend system
4. Provide fallback options when the local server is unavailable
5. Optimize performance and resource usage

## Hardware Requirements

For optimal performance with a 13B parameter model:

| Component | Minimum Requirement | Recommended |
|-----------|---------------------|-------------|
| CPU | 4+ cores | 8+ cores |
| RAM | 16GB | 32GB+ |
| GPU | 8GB VRAM | 16GB+ VRAM (NVIDIA RTX series) |
| Storage | 50GB SSD | 100GB+ NVMe SSD |
| OS | Windows 10/11, macOS, Linux | Linux (Ubuntu 20.04+) |

## LMStudio Installation

### Windows Installation

1. Download LMStudio from the official website: https://lmstudio.ai/
2. Run the installer and follow the installation wizard
3. Launch LMStudio after installation

### macOS Installation

1. Download LMStudio from the official website: https://lmstudio.ai/
2. Open the downloaded DMG file
3. Drag LMStudio to the Applications folder
4. Launch LMStudio from the Applications folder

### Linux Installation

1. Download LMStudio AppImage from the official website: https://lmstudio.ai/
2. Make the AppImage executable:
   ```bash
   chmod +x LM_Studio-*.AppImage
   ```
3. Run the AppImage:
   ```bash
   ./LM_Studio-*.AppImage
   ```

## Model Download and Setup

### Downloading Vicuna 13B

1. Launch LMStudio
2. Navigate to the "Models" tab
3. Search for "Vicuna 13B"
4. Click on the download button for the model
5. Wait for the download to complete (this may take some time depending on your internet connection)

### Alternative Models

If Vicuna 13B is not available or if you prefer a different model, consider these alternatives:

1. **Llama 2 13B**: Meta's open-source model with good general capabilities
2. **Mistral 7B**: Smaller but highly efficient model with performance comparable to larger models
3. **WizardLM 13B**: Optimized for instruction following
4. **Orca 2 13B**: Microsoft's research model with strong reasoning capabilities

### Model Configuration

1. In LMStudio, select the downloaded model
2. Configure the model parameters:
   - Context Length: 4096 (or maximum available)
   - Temperature: 0.7 (adjust based on requirements)
   - Top P: 0.95
   - Top K: 40
   - Repetition Penalty: 1.1
3. Save the configuration

## Setting Up the Local API Server

LMStudio provides a built-in API server that mimics the OpenAI API format, making it easy to integrate with existing applications.

### Starting the API Server

1. In LMStudio, go to the "Local Server" tab
2. Select the model you want to use (Vicuna 13B or alternative)
3. Configure server settings:
   - Host: 0.0.0.0 (to allow external connections)
   - Port: 8000 (or any available port)
   - Max Tokens: 4096 (or based on your requirements)
4. Click "Start Server"

### API Server Configuration

Create a configuration file for the API server to ensure consistent settings across restarts:

```json
// lmstudio-server-config.json
{
  "host": "0.0.0.0",
  "port": 8000,
  "model_path": "/path/to/vicuna-13b",
  "context_length": 4096,
  "max_tokens": 4096,
  "temperature": 0.7,
  "top_p": 0.95,
  "top_k": 40,
  "repetition_penalty": 1.1,
  "seed": -1,
  "threads": 8,
  "batch_size": 512,
  "gpu_layers": -1
}
```

### Running the Server as a Service

To ensure the LLM server runs continuously and starts automatically on system boot, set it up as a system service.

#### Linux (systemd)

1. Create a systemd service file:

```bash
sudo nano /etc/systemd/system/lmstudio-server.service
```

2. Add the following content:

```
[Unit]
Description=LMStudio API Server
After=network.target

[Service]
Type=simple
User=<your-username>
ExecStart=/path/to/LM_Studio-*.AppImage --server --config /path/to/lmstudio-server-config.json
Restart=on-failure
RestartSec=5
StartLimitInterval=60s
StartLimitBurst=3

[Install]
WantedBy=multi-user.target
```

3. Enable and start the service:

```bash
sudo systemctl enable lmstudio-server
sudo systemctl start lmstudio-server
```

4. Check the service status:

```bash
sudo systemctl status lmstudio-server
```

#### Windows

1. Create a batch file (start-lmstudio-server.bat):

```batch
@echo off
start "" "C:\Path\to\LMStudio.exe" --server --config "C:\Path\to\lmstudio-server-config.json"
```

2. Create a scheduled task:
   - Open Task Scheduler
   - Create a new task
   - Set it to run at system startup
   - Set the action to run the batch file
   - Configure to run with highest privileges
   - Set to restart if the task fails

## API Integration

The LMStudio API server provides endpoints compatible with the OpenAI API format, making it easy to integrate with existing applications.

### API Endpoints

- **Chat Completions**: `/v1/chat/completions`
- **Completions**: `/v1/completions`
- **Models**: `/v1/models`
- **Health Check**: `/health`

### Example API Request

```javascript
const axios = require('axios');

async function getChatCompletion(messages) {
  try {
    const response = await axios.post('http://localhost:8000/v1/chat/completions', {
      model: 'vicuna-13b',
      messages: messages,
      temperature: 0.7,
      max_tokens: 1024
    });
    
    return response.data;
  } catch (error) {
    console.error('Error calling local LLM server:', error);
    throw error;
  }
}

// Example usage
const messages = [
  { role: 'system', content: 'You are a helpful assistant.' },
  { role: 'user', content: 'What is the capital of France?' }
];

getChatCompletion(messages)
  .then(response => console.log(response.choices[0].message.content))
  .catch(error => console.error('Failed to get completion:', error));
```

### API Response Format

```json
{
  "id": "chatcmpl-123",
  "object": "chat.completion",
  "created": 1677858242,
  "model": "vicuna-13b",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "The capital of France is Paris."
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 25,
    "completion_tokens": 7,
    "total_tokens": 32
  }
}
```

## Performance Optimization

### GPU Acceleration

To maximize performance with GPU acceleration:

1. Ensure you have the latest NVIDIA drivers installed
2. Install CUDA Toolkit (compatible with your GPU)
3. Configure LMStudio to use GPU acceleration:
   - In LMStudio settings, enable "Use GPU"
   - Set "GPU Layers" to -1 (use all available layers)
   - Adjust batch size based on your GPU memory

### Memory Optimization

To optimize memory usage:

1. Enable 4-bit or 8-bit quantization in LMStudio settings
2. Adjust context length based on your use case
3. Set an appropriate batch size (smaller for less memory usage)
4. Close other memory-intensive applications when running the server

### CPU Optimization

If running on CPU only:

1. Set the number of threads based on your CPU cores (typically # of cores - 2)
2. Use 4-bit quantization to reduce memory requirements
3. Reduce context length and max tokens
4. Consider using a smaller model (e.g., 7B parameter model)

## Monitoring and Logging

### Setting Up Logging

Create a logging configuration to track server activity:

```javascript
// In your server wrapper or monitoring script
const fs = require('fs');
const { spawn } = require('child_process');
const path = require('path');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir);
}

// Create log file with timestamp
const timestamp = new Date().toISOString().replace(/:/g, '-');
const logFile = path.join(logsDir, `lmstudio-server-${timestamp}.log`);
const logStream = fs.createWriteStream(logFile, { flags: 'a' });

// Start LMStudio server process
const serverProcess = spawn('/path/to/LM_Studio-*.AppImage', [
  '--server',
  '--config', '/path/to/lmstudio-server-config.json'
]);

// Pipe stdout and stderr to log file
serverProcess.stdout.pipe(logStream);
serverProcess.stderr.pipe(logStream);

// Log process events
serverProcess.on('error', (error) => {
  logStream.write(`Error: ${error.message}\n`);
});

serverProcess.on('exit', (code, signal) => {
  logStream.write(`Process exited with code ${code} and signal ${signal}\n`);
  logStream.end();
});
```

### Health Monitoring

Create a simple health check script to monitor the server:

```javascript
const axios = require('axios');
const nodemailer = require('nodemailer');

// Configure email transport
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

async function checkServerHealth() {
  try {
    const response = await axios.get('http://localhost:8000/health', { timeout: 5000 });
    
    if (response.status === 200) {
      console.log('Server is healthy:', response.data);
      return true;
    } else {
      console.error('Server returned non-200 status:', response.status);
      await sendAlert(`LLM Server Health Check Failed: Status ${response.status}`);
      return false;
    }
  } catch (error) {
    console.error('Server health check failed:', error.message);
    await sendAlert(`LLM Server Health Check Failed: ${error.message}`);
    return false;
  }
}

async function sendAlert(message) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.ALERT_EMAIL,
      subject: 'LLM Server Alert',
      text: message
    });
    console.log('Alert email sent');
  } catch (error) {
    console.error('Failed to send alert email:', error);
  }
}

// Run health check every 5 minutes
setInterval(checkServerHealth, 5 * 60 * 1000);

// Initial check
checkServerHealth();
```

## Fallback Mechanism

Implement a fallback mechanism to handle situations when the local LLM server is unavailable:

```javascript
const axios = require('axios');

class LLMService {
  constructor(localEndpoint, cloudEndpoint, apiKey) {
    this.localEndpoint = localEndpoint;
    this.cloudEndpoint = cloudEndpoint;
    this.apiKey = apiKey;
    this.localAvailable = true;
    
    // Check local server availability periodically
    setInterval(() => this.checkLocalAvailability(), 60 * 1000);
    this.checkLocalAvailability();
  }
  
  async checkLocalAvailability() {
    try {
      const response = await axios.get(`${this.localEndpoint}/health`, { timeout: 2000 });
      this.localAvailable = response.status === 200;
      console.log(`Local LLM server available: ${this.localAvailable}`);
    } catch (error) {
      this.localAvailable = false;
      console.log('Local LLM server unavailable:', error.message);
    }
  }
  
  async getChatCompletion(messages, options = {}) {
    // Try local server first if available and not explicitly set to use cloud
    if (this.localAvailable && !options.forceCloud) {
      try {
        const response = await axios.post(`${this.localEndpoint}/v1/chat/completions`, {
          model: options.model || 'vicuna-13b',
          messages: messages,
          temperature: options.temperature || 0.7,
          max_tokens: options.maxTokens || 1024,
          top_p: options.topP || 0.95,
          top_k: options.topK || 40
        }, { timeout: options.timeout || 30000 });
        
        return response.data;
      } catch (error) {
        console.error('Error with local LLM server, falling back to cloud:', error.message);
        // Fall back to cloud service
      }
    }
    
    // Use cloud service
    try {
      // Format may differ based on the cloud service being used
      const response = await axios.post(this.cloudEndpoint, {
        contents: messages.map(msg => ({
          role: msg.role === 'user' ? 'USER' : msg.role === 'system' ? 'SYSTEM' : 'MODEL',
          parts: [{ text: msg.content }]
        })),
        generationConfig: {
          temperature: options.temperature || 0.7,
          maxOutputTokens: options.maxTokens || 1024,
          topP: options.topP || 0.95,
          topK: options.topK || 40
        }
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        timeout: options.timeout || 30000
      });
      
      // Convert cloud response to match local format
      return {
        id: `cloud-${Date.now()}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: 'cloud-model',
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: response.data.candidates[0].content.parts[0].text
          },
          finish_reason: 'stop'
        }],
        usage: {
          prompt_tokens: -1,
          completion_tokens: -1,
          total_tokens: -1
        }
      };
    } catch (error) {
      console.error('Error with cloud LLM service:', error.message);
      throw new Error(`Failed to get completion from both local and cloud services: ${error.message}`);
    }
  }
}

// Usage
const llmService = new LLMService(
  'http://localhost:8000',
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent',
  process.env.GEMINI_API_KEY
);

// Example usage
async function getCompletion() {
  const messages = [
    { role: 'system', content: 'You are a helpful assistant.' },
    { role: 'user', content: 'What is the capital of France?' }
  ];
  
  try {
    const response = await llmService.getChatCompletion(messages);
    console.log(response.choices[0].message.content);
  } catch (error) {
    console.error('Failed to get completion:', error);
  }
}

getCompletion();
```

## Flask API Wrapper

Create a Flask API wrapper to provide additional functionality and better integration with the backend system:

```python
# app.py
from flask import Flask, request, jsonify
import requests
import os
import time
import logging
from flask_cors import CORS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("llm_server_wrapper.log"),
        logging.StreamHandler()
    ]
)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configuration
LOCAL_LLM_ENDPOINT = os.environ.get("LOCAL_LLM_ENDPOINT", "http://localhost:8000")
CLOUD_LLM_ENDPOINT = os.environ.get("CLOUD_LLM_ENDPOINT", "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent")
CLOUD_API_KEY = os.environ.get("GEMINI_API_KEY", "")
DEFAULT_TIMEOUT = int(os.environ.get("DEFAULT_TIMEOUT", 30))

# Cache for responses
response_cache = {}
cache_ttl = 3600  # 1 hour

def check_local_availability():
    """Check if the local LLM server is available"""
    try:
        response = requests.get(f"{LOCAL_LLM_ENDPOINT}/health", timeout=2)
        return response.status_code == 200
    except:
        return False

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    local_available = check_local_availability()
    return jsonify({
        "status": "ok",
        "local_llm_available": local_available,
        "cloud_llm_available": bool(CLOUD_API_KEY),
        "timestamp": time.time()
    })

@app.route('/api/chat', methods=['POST'])
def chat():
    """Chat completion endpoint"""
    data = request.json
    messages = data.get('messages', [])
    options = data.get('options', {})
    
    # Generate cache key
    cache_key = str(hash(str(messages) + str(options)))
    
    # Check cache
    if cache_key in response_cache:
        cached_response, timestamp = response_cache[cache_key]
        if time.time() - timestamp < cache_ttl:
            logging.info("Returning cached response")
            return jsonify(cached_response)
    
    # Determine whether to use local or cloud
    use_local = check_local_availability() and not options.get('forceCloud', False)
    
    try:
        if use_local:
            # Call local LLM server
            logging.info("Using local LLM server")
            response = requests.post(
                f"{LOCAL_LLM_ENDPOINT}/v1/chat/completions",
                json={
                    "model": options.get('model', 'vicuna-13b'),
                    "messages": messages,
                    "temperature": options.get('temperature', 0.7),
                    "max_tokens": options.get('maxTokens', 1024),
                    "top_p": options.get('topP', 0.95),
                    "top_k": options.get('topK', 40)
                },
                timeout=options.get('timeout', DEFAULT_TIMEOUT)
            )
            
            if response.status_code == 200:
                result = response.json()
                # Cache the response
                response_cache[cache_key] = (result, time.time())
                return jsonify(result)
            else:
                logging.error(f"Local LLM server error: {response.status_code} - {response.text}")
                # Fall back to cloud if local fails
        
        # Use cloud service
        if not CLOUD_API_KEY:
            return jsonify({"error": "Cloud API key not configured and local server unavailable"}), 503
        
        logging.info("Using cloud LLM service")
        # Format request for cloud service
        cloud_request = {
            "contents": [
                {
                    "role": "USER" if msg["role"] == "user" else "SYSTEM" if msg["role"] == "system" else "MODEL",
                    "parts": [{"text": msg["content"]}]
                } for msg in messages
            ],
            "generationConfig": {
                "temperature": options.get('temperature', 0.7),
                "maxOutputTokens": options.get('maxTokens', 1024),
                "topP": options.get('topP', 0.95),
                "topK": options.get('topK', 40)
            }
        }
        
        response = requests.post(
            CLOUD_LLM_ENDPOINT,
            json=cloud_request,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {CLOUD_API_KEY}"
            },
            timeout=options.get('timeout', DEFAULT_TIMEOUT)
        )
        
        if response.status_code == 200:
            cloud_response = response.json()
            
            # Convert cloud response to match local format
            result = {
                "id": f"cloud-{int(time.time())}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": "cloud-model",
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": cloud_response["candidates"][0]["content"]["parts"][0]["text"]
                    },
                    "finish_reason": "stop"
                }],
                "usage": {
                    "prompt_tokens": -1,
                    "completion_tokens": -1,
                    "total_tokens": -1
                }
            }
            
            # Cache the response
            response_cache[cache_key] = (result, time.time())
            return jsonify(result)
        else:
            logging.error(f"Cloud LLM service error: {response.status_code} - {response.text}")
            return jsonify({"error": f"Cloud service error: {response.status_code}"}), response.status_code
            
    except Exception as e:
        logging.exception("Error processing chat request")
        return jsonify({"error": str(e)}), 500

@app.route('/api/models', methods=['GET'])
def list_models():
    """List available models"""
    models = [
        {
            "id": "vicuna-13b",
            "object": "model",
            "created": int(time.time()),
            "owned_by": "local"
        }
    ]
    
    # Add cloud models if available
    if CLOUD_API_KEY:
        models.append({
            "id": "gemini-pro",
            "object": "model",
            "created": int(time.time()),
            "owned_by": "google"
        })
    
    return jsonify({"data": models})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)
```

## Docker Deployment

For easier deployment and management, containerize the Flask API wrapper:

```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app.py .

ENV LOCAL_LLM_ENDPOINT=http://host.docker.internal:8000
ENV CLOUD_LLM_ENDPOINT=https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent
ENV GEMINI_API_KEY=""
ENV DEFAULT_TIMEOUT=30

EXPOSE 3000

CMD ["python", "app.py"]
```

Create a requirements.txt file:

```
flask==2.0.1
requests==2.26.0
flask-cors==3.0.10
gunicorn==20.1.0
```

Build and run the Docker container:

```bash
docker build -t llm-server-wrapper .
docker run -p 3000:3000 -e GEMINI_API_KEY=your-api-key llm-server-wrapper
```

## Testing the Setup

### Basic API Test

Create a test script to verify the setup:

```javascript
// test-llm-server.js
const axios = require('axios');

async function testServer() {
  try {
    // Test health endpoint
    console.log('Testing health endpoint...');
    const healthResponse = await axios.get('http://localhost:3000/api/health');
    console.log('Health check result:', healthResponse.data);
    
    // Test chat endpoint
    console.log('\nTesting chat endpoint...');
    const chatResponse = await axios.post('http://localhost:3000/api/chat', {
      messages: [
        { role: 'system', content: 'You are a helpful assistant.' },
        { role: 'user', content: 'What is the capital of France?' }
      ],
      options: {
        temperature: 0.7,
        maxTokens: 100
      }
    });
    
    console.log('Chat response:');
    console.log('Model:', chatResponse.data.model);
    console.log('Content:', chatResponse.data.choices[0].message.content);
    
    // Test models endpoint
    console.log('\nTesting models endpoint...');
    const modelsResponse = await axios.get('http://localhost:3000/api/models');
    console.log('Available models:', modelsResponse.data.data);
    
    console.log('\nAll tests passed!');
  } catch (error) {
    console.error('Test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testServer();
```

### Load Testing

Create a simple load test to evaluate performance:

```javascript
// load-test.js
const axios = require('axios');

async function runLoadTest(concurrentRequests, totalRequests) {
  console.log(`Starting load test with ${concurrentRequests} concurrent requests, ${totalRequests} total requests`);
  
  const startTime = Date.now();
  let completedRequests = 0;
  let successfulRequests = 0;
  let failedRequests = 0;
  
  const sendRequest = async () => {
    try {
      const response = await axios.post('http://localhost:3000/api/chat', {
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'Give me a one-sentence response.' }
        ],
        options: {
          temperature: 0.7,
          maxTokens: 50
        }
      });
      
      successfulRequests++;
      return response.data;
    } catch (error) {
      failedRequests++;
      return null;
    } finally {
      completedRequests++;
      
      // Print progress
      if (completedRequests % 10 === 0 || completedRequests === totalRequests) {
        const elapsedSeconds = (Date.now() - startTime) / 1000;
        console.log(`Completed ${completedRequests}/${totalRequests} requests (${successfulRequests} successful, ${failedRequests} failed) in ${elapsedSeconds.toFixed(2)}s`);
      }
      
      // Send another request if we haven't reached the total
      if (completedRequests < totalRequests) {
        return sendRequest();
      }
    }
  };
  
  // Start concurrent requests
  const promises = [];
  for (let i = 0; i < Math.min(concurrentRequests, totalRequests); i++) {
    promises.push(sendRequest());
  }
  
  // Wait for all requests to complete
  await Promise.all(promises);
  
  const totalTime = (Date.now() - startTime) / 1000;
  console.log('\nLoad test completed:');
  console.log(`Total time: ${totalTime.toFixed(2)} seconds`);
  console.log(`Requests per second: ${(successfulRequests / totalTime).toFixed(2)}`);
  console.log(`Success rate: ${((successfulRequests / totalRequests) * 100).toFixed(2)}%`);
}

// Run load test with 5 concurrent requests, 50 total requests
runLoadTest(5, 50);
```

## Integration with Backend System

### Node.js Integration

```javascript
// llm-service.js
const axios = require('axios');

class LLMService {
  constructor(apiEndpoint) {
    this.apiEndpoint = apiEndpoint;
  }
  
  async getHealth() {
    try {
      const response = await axios.get(`${this.apiEndpoint}/api/health`);
      return response.data;
    } catch (error) {
      console.error('Error checking LLM server health:', error.message);
      throw error;
    }
  }
  
  async getChatCompletion(messages, options = {}) {
    try {
      const response = await axios.post(`${this.apiEndpoint}/api/chat`, {
        messages,
        options
      });
      
      return response.data;
    } catch (error) {
      console.error('Error getting chat completion:', error.message);
      throw error;
    }
  }
  
  async getAvailableModels() {
    try {
      const response = await axios.get(`${this.apiEndpoint}/api/models`);
      return response.data.data;
    } catch (error) {
      console.error('Error getting available models:', error.message);
      throw error;
    }
  }
}

module.exports = LLMService;
```

### Firebase Cloud Function Integration

```javascript
// functions/index.js
const functions = require('firebase-functions');
const axios = require('axios');

// LLM server configuration
const LLM_API_ENDPOINT = process.env.LLM_API_ENDPOINT || 'http://localhost:3000';

exports.chat = functions.https.onCall(async (data, context) => {
  // Ensure user is authenticated
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }
  
  try {
    const { messages, options } = data;
    
    // Call LLM server
    const response = await axios.post(`${LLM_API_ENDPOINT}/api/chat`, {
      messages,
      options
    });
    
    return response.data;
  } catch (error) {
    console.error('Error calling LLM server:', error);
    throw new functions.https.HttpsError('internal', 'Failed to process chat request', error.message);
  }
});

exports.getModels = functions.https.onCall(async (data, context) => {
  // Ensure user is authenticated
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }
  
  try {
    const response = await axios.get(`${LLM_API_ENDPOINT}/api/models`);
    return response.data;
  } catch (error) {
    console.error('Error getting models from LLM server:', error);
    throw new functions.https.HttpsError('internal', 'Failed to get models', error.message);
  }
});
```

## Troubleshooting

### Common Issues and Solutions

1. **Server Won't Start**
   - Check if another process is using the same port
   - Verify GPU drivers are properly installed
   - Check if the model file is corrupted or incomplete

2. **High Memory Usage**
   - Enable model quantization (4-bit or 8-bit)
   - Reduce context length
   - Use a smaller model

3. **Slow Response Times**
   - Increase batch size if GPU memory allows
   - Reduce max tokens for generation
   - Check for CPU/GPU throttling due to temperature

4. **API Connection Issues**
   - Verify the server is listening on 0.0.0.0 (not just localhost)
   - Check firewall settings
   - Ensure correct port forwarding if using Docker

5. **Model Loading Errors**
   - Verify model files are complete and not corrupted
   - Check for sufficient disk space
   - Ensure compatible CUDA version if using GPU

### Debugging

For advanced debugging:

1. Enable verbose logging in LMStudio
2. Monitor GPU usage with `nvidia-smi` (for NVIDIA GPUs)
3. Check system resources with `htop` or Task Manager
4. Use `curl` to test API endpoints directly:

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "vicuna-13b",
    "messages": [
      {"role": "system", "content": "You are a helpful assistant."},
      {"role": "user", "content": "Hello, how are you?"}
    ],
    "temperature": 0.7,
    "max_tokens": 100
  }'
```

## Conclusion

This setup provides a robust local LLM server using LMStudio with Vicuna 13B or an equivalent model. The server is integrated with the Synapse-OD Hub system through a Flask API wrapper, providing fallback options and optimization strategies. The system is designed to be reliable, performant, and easy to maintain.

