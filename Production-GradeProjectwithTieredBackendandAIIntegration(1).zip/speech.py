"""
Speech routes for the speech API.
"""

import os
import uuid
import logging
from flask import Blueprint, request, jsonify, send_file
import tempfile
from werkzeug.utils import secure_filename

from src.services.speech_to_text import SpeechToTextService
from src.services.text_to_speech import TextToSpeechService

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create blueprint
speech_bp = Blueprint('speech', __name__)

# Create services
speech_to_text_service = SpeechToTextService()
text_to_speech_service = TextToSpeechService()

# Create upload directory
UPLOAD_DIR = os.path.join(tempfile.gettempdir(), "speech_api_uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

@speech_bp.route('/health', methods=['GET'])
def health():
    """
    Check the health of the speech services.
    """
    return jsonify({
        "status": "ok",
        "speech_to_text": speech_to_text_service.client is not None,
        "text_to_speech": text_to_speech_service.client is not None
    })

@speech_bp.route('/stt', methods=['POST'])
def speech_to_text():
    """
    Convert speech to text.
    """
    # Check if file is provided
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400
    
    file = request.files['audio']
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    # Get parameters
    language_code = request.form.get('language_code', 'en-US')
    sample_rate_hertz = int(request.form.get('sample_rate_hertz', 16000))
    enable_automatic_punctuation = request.form.get('enable_automatic_punctuation', 'true').lower() == 'true'
    model = request.form.get('model', 'default')
    
    # Determine encoding from MIME type
    mime_type = file.content_type
    encoding = speech_to_text_service.get_encoding_from_mime_type(mime_type)
    
    if not encoding:
        return jsonify({"error": f"Unsupported audio format: {mime_type}"}), 400
    
    try:
        # Save the file temporarily
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}_{filename}")
        file.save(file_path)
        
        # Transcribe the audio
        result = speech_to_text_service.transcribe_file(
            file_path=file_path,
            language_code=language_code,
            sample_rate_hertz=sample_rate_hertz,
            encoding=encoding,
            enable_automatic_punctuation=enable_automatic_punctuation,
            model=model
        )
        
        # Clean up
        os.remove(file_path)
        
        if not result.get('success', False):
            return jsonify(result), 500
        
        return jsonify(result)
    
    except Exception as e:
        logger.exception("Error processing speech-to-text request")
        return jsonify({"error": str(e)}), 500

@speech_bp.route('/tts', methods=['POST'])
def text_to_speech():
    """
    Convert text to speech.
    """
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    if 'text' not in data:
        return jsonify({"error": "No text provided"}), 400
    
    # Get parameters
    text = data['text']
    language_code = data.get('language_code', 'en-US')
    voice_name = data.get('voice_name', 'en-US-Neural2-F')
    speaking_rate = float(data.get('speaking_rate', 1.0))
    pitch = float(data.get('pitch', 0.0))
    volume_gain_db = float(data.get('volume_gain_db', 0.0))
    audio_encoding = data.get('audio_encoding', 'MP3')
    
    try:
        # Synthesize speech
        result = text_to_speech_service.synthesize_speech(
            text=text,
            language_code=language_code,
            voice_name=voice_name,
            speaking_rate=speaking_rate,
            pitch=pitch,
            volume_gain_db=volume_gain_db,
            audio_encoding=audio_encoding
        )
        
        if not result.get('success', False):
            return jsonify(result), 500
        
        # Save the audio to a temporary file
        file_extension = ".mp3" if audio_encoding == "MP3" else ".wav"
        file_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}{file_extension}")
        
        save_result = text_to_speech_service.save_to_file(
            audio_content=result['audio_content'],
            file_path=file_path
        )
        
        if not save_result.get('success', False):
            return jsonify(save_result), 500
        
        # Return the audio file
        return send_file(
            file_path,
            mimetype=f"audio/{file_extension[1:]}",
            as_attachment=True,
            download_name=f"speech{file_extension}"
        )
    
    except Exception as e:
        logger.exception("Error processing text-to-speech request")
        return jsonify({"error": str(e)}), 500

@speech_bp.route('/tts/voices', methods=['GET'])
def list_voices():
    """
    List available voices for text-to-speech.
    """
    language_code = request.args.get('language_code')
    
    try:
        result = text_to_speech_service.list_voices(language_code=language_code)
        
        if not result.get('success', False):
            return jsonify(result), 500
        
        return jsonify(result)
    
    except Exception as e:
        logger.exception("Error listing voices")
        return jsonify({"error": str(e)}), 500

@speech_bp.route('/stt-tts', methods=['POST'])
def speech_to_text_to_speech():
    """
    Convert speech to text, then text to speech.
    """
    # Check if file is provided
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400
    
    file = request.files['audio']
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    # Get parameters for speech-to-text
    stt_language_code = request.form.get('stt_language_code', 'en-US')
    stt_sample_rate_hertz = int(request.form.get('stt_sample_rate_hertz', 16000))
    stt_enable_automatic_punctuation = request.form.get('stt_enable_automatic_punctuation', 'true').lower() == 'true'
    stt_model = request.form.get('stt_model', 'default')
    
    # Get parameters for text-to-speech
    tts_language_code = request.form.get('tts_language_code', 'en-US')
    tts_voice_name = request.form.get('tts_voice_name', 'en-US-Neural2-F')
    tts_speaking_rate = float(request.form.get('tts_speaking_rate', 1.0))
    tts_pitch = float(request.form.get('tts_pitch', 0.0))
    tts_volume_gain_db = float(request.form.get('tts_volume_gain_db', 0.0))
    tts_audio_encoding = request.form.get('tts_audio_encoding', 'MP3')
    
    # Determine encoding from MIME type
    mime_type = file.content_type
    encoding = speech_to_text_service.get_encoding_from_mime_type(mime_type)
    
    if not encoding:
        return jsonify({"error": f"Unsupported audio format: {mime_type}"}), 400
    
    try:
        # Save the file temporarily
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}_{filename}")
        file.save(file_path)
        
        # Transcribe the audio
        stt_result = speech_to_text_service.transcribe_file(
            file_path=file_path,
            language_code=stt_language_code,
            sample_rate_hertz=stt_sample_rate_hertz,
            encoding=encoding,
            enable_automatic_punctuation=stt_enable_automatic_punctuation,
            model=stt_model
        )
        
        # Clean up
        os.remove(file_path)
        
        if not stt_result.get('success', False):
            return jsonify(stt_result), 500
        
        # Extract the transcribed text
        if not stt_result.get('results') or len(stt_result['results']) == 0:
            return jsonify({"error": "No transcription results"}), 500
        
        text = stt_result['results'][0]['transcript']
        
        # Synthesize speech
        tts_result = text_to_speech_service.synthesize_speech(
            text=text,
            language_code=tts_language_code,
            voice_name=tts_voice_name,
            speaking_rate=tts_speaking_rate,
            pitch=tts_pitch,
            volume_gain_db=tts_volume_gain_db,
            audio_encoding=tts_audio_encoding
        )
        
        if not tts_result.get('success', False):
            return jsonify(tts_result), 500
        
        # Save the audio to a temporary file
        file_extension = ".mp3" if tts_audio_encoding == "MP3" else ".wav"
        output_file_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}{file_extension}")
        
        save_result = text_to_speech_service.save_to_file(
            audio_content=tts_result['audio_content'],
            file_path=output_file_path
        )
        
        if not save_result.get('success', False):
            return jsonify(save_result), 500
        
        # Return the audio file and transcription
        response = {
            "transcription": text,
            "confidence": stt_result['results'][0].get('confidence', 0.0)
        }
        
        return send_file(
            output_file_path,
            mimetype=f"audio/{file_extension[1:]}",
            as_attachment=True,
            download_name=f"speech{file_extension}",
            attachment_filename=f"speech{file_extension}"
        ), 200, {"X-Transcription": text}
    
    except Exception as e:
        logger.exception("Error processing speech-to-text-to-speech request")
        return jsonify({"error": str(e)}), 500

