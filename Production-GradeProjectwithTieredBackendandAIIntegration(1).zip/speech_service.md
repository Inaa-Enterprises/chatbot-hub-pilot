# Speech Service Documentation

**Author:** Manus AI  
**Date:** June 7, 2025

## Table of Contents

1. [Introduction](#introduction)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [API Reference](#api-reference)
6. [Google Cloud Integration](#google-cloud-integration)
7. [Speech-to-Text](#speech-to-text)
8. [Text-to-Speech](#text-to-speech)
9. [Voice Selection](#voice-selection)
10. [Performance Optimization](#performance-optimization)
11. [Troubleshooting](#troubleshooting)
12. [References](#references)

## Introduction

The Speech Service is a component of the Synapse-OD Hub that provides speech-to-text and text-to-speech capabilities using Google Cloud services. It allows for converting audio to text, text to audio, and supports various languages and voices.

This document provides detailed information about the Speech Service component, including its architecture, installation, configuration, and API reference.

## Architecture

The Speech Service is built on a Flask web framework and provides a RESTful API for speech-to-text and text-to-speech conversion. It consists of the following main components:

1. **API Server**: A Flask application that handles HTTP requests and responses.
2. **Speech-to-Text Service**: A service that converts audio to text using Google Cloud Speech-to-Text API.
3. **Text-to-Speech Service**: A service that converts text to audio using Google Cloud Text-to-Speech API.
4. **Voice Manager**: A component that manages available voices and their configurations.
5. **Audio Processor**: A component that processes audio files for optimal conversion.

The service is designed to be scalable, maintainable, and easy to deploy. It uses Google Cloud services for speech processing, providing high-quality and reliable conversions.

## Installation

### Prerequisites

- Python 3.9+
- Google Cloud account with Speech-to-Text and Text-to-Speech APIs enabled
- Google Cloud credentials
- Docker (optional, for containerized deployment)

### Installation Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/synapse-od-hub.git
   cd synapse-od-hub/speech-service
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Set up Google Cloud credentials:
   ```bash
   # Download your Google Cloud credentials JSON file
   # Set the GOOGLE_APPLICATION_CREDENTIALS environment variable
   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/your/credentials.json
   ```

4. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

5. Start the server:
   ```bash
   python src/main.py
   ```

### Docker Installation

1. Build the Docker image:
   ```bash
   docker build -t speech-service .
   ```

2. Run the Docker container:
   ```bash
   docker run -p 3003:3003 -v /path/to/your/credentials.json:/app/credentials/google-credentials.json -e GOOGLE_APPLICATION_CREDENTIALS=/app/credentials/google-credentials.json speech-service
   ```

## Configuration

The Speech Service can be configured using environment variables or a configuration file. Here are the available configuration options:

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port to run the server on | `3003` |
| `GOOGLE_APPLICATION_CREDENTIALS` | Path to Google Cloud credentials JSON file | `""` |
| `DEFAULT_LANGUAGE_CODE` | Default language code for speech processing | `en-US` |
| `DEFAULT_VOICE_NAME` | Default voice name for text-to-speech | `en-US-Neural2-F` |
| `AUDIO_SAMPLE_RATE` | Sample rate for audio processing | `16000` |
| `MAX_AUDIO_SIZE_MB` | Maximum size of audio files in MB | `10` |

You can set these variables in a `.env` file or directly in the environment.

## API Reference

### Endpoints

#### Health Check

```
GET /health
```

Check the health of the Speech Service.

**Response Example:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

#### Speech-to-Text

```
POST /speech/stt
```

Convert speech to text.

**Request:**
Form data with the following fields:
- `audio`: Audio file (WAV, MP3, FLAC, etc.)
- `language_code` (optional): Language code (e.g., `en-US`, `fr-FR`)
- `model` (optional): Speech recognition model to use
- `enhanced` (optional): Whether to use enhanced speech recognition

**Response Example:**
```json
{
  "status": "ok",
  "result": {
    "results": [
      {
        "transcript": "Hello, this is a test of the speech-to-text API.",
        "confidence": 0.98
      }
    ],
    "language_code": "en-US",
    "success": true
  }
}
```

#### Text-to-Speech

```
POST /speech/tts
```

Convert text to speech.

**Request Body:**
```json
{
  "text": "Hello, this is a test of the text-to-speech API.",
  "language_code": "en-US",
  "voice_name": "en-US-Neural2-F",
  "speaking_rate": 1.0,
  "pitch": 0.0,
  "volume_gain_db": 0.0,
  "audio_encoding": "MP3"
}
```

**Response:**
Audio file (MP3, WAV, etc.) with the following headers:
- `Content-Type`: Audio MIME type (e.g., `audio/mp3`)
- `Content-Disposition`: Attachment with filename

#### List Voices

```
GET /speech/tts/voices
```

Get a list of available voices for text-to-speech.

**Query Parameters:**
- `language_code` (optional): Filter voices by language code.

**Response Example:**
```json
{
  "success": true,
  "voices": [
    {
      "name": "en-US-Neural2-F",
      "language_codes": ["en-US"],
      "ssml_gender": "FEMALE",
      "natural_sample_rate_hertz": 24000
    },
    {
      "name": "en-US-Neural2-M",
      "language_codes": ["en-US"],
      "ssml_gender": "MALE",
      "natural_sample_rate_hertz": 24000
    },
    {
      "name": "fr-FR-Neural2-A",
      "language_codes": ["fr-FR"],
      "ssml_gender": "FEMALE",
      "natural_sample_rate_hertz": 24000
    }
  ]
}
```

#### Speech Health Check

```
GET /speech/health
```

Check the health of the speech services.

**Response Example:**
```json
{
  "status": "ok",
  "stt": {
    "status": "ok",
    "available_languages": ["en-US", "fr-FR", "es-ES", "de-DE", "ja-JP"]
  },
  "tts": {
    "status": "ok",
    "available_voices": 100
  }
}
```

## Google Cloud Integration

The Speech Service integrates with Google Cloud services for speech processing. This section provides information about setting up and configuring Google Cloud for use with the Speech Service.

### Setting Up Google Cloud

1. Create a Google Cloud account if you don't have one.

2. Create a new project in the Google Cloud Console.

3. Enable the Speech-to-Text and Text-to-Speech APIs:
   - Go to the API Library
   - Search for "Speech-to-Text" and "Text-to-Speech"
   - Enable both APIs

4. Create a service account:
   - Go to IAM & Admin > Service Accounts
   - Click "Create Service Account"
   - Enter a name and description
   - Grant the following roles:
     - Speech-to-Text Admin
     - Text-to-Speech Admin
   - Click "Create Key" and download the JSON key file

5. Set the `GOOGLE_APPLICATION_CREDENTIALS` environment variable to the path of the downloaded JSON key file.

### Google Cloud Quotas and Limits

Google Cloud services have quotas and limits that may affect the Speech Service. Here are some important limits to be aware of:

#### Speech-to-Text

- 60 minutes of audio processing per day for the free tier
- Maximum audio file size: 10 MB
- Maximum audio duration: 1 minute for synchronous recognition

#### Text-to-Speech

- 4 million characters per month for the free tier
- Maximum text length: 5,000 characters per request

For more information about quotas and limits, see the [Google Cloud documentation](https://cloud.google.com/speech-to-text/quotas) and [Text-to-Speech documentation](https://cloud.google.com/text-to-speech/quotas).

## Speech-to-Text

The Speech Service provides speech-to-text conversion using Google Cloud Speech-to-Text API. This section provides information about the speech-to-text capabilities of the service.

### Supported Audio Formats

The service supports the following audio formats:

- WAV
- MP3
- FLAC
- OGG
- M4A
- AMR
- WEBM

### Supported Languages

The service supports a wide range of languages for speech recognition. Some of the supported languages include:

- English (various dialects)
- French
- Spanish
- German
- Japanese
- Chinese
- Russian
- Arabic
- And many more

For a complete list of supported languages, see the [Google Cloud Speech-to-Text documentation](https://cloud.google.com/speech-to-text/docs/languages).

### Speech Recognition Models

The service supports different speech recognition models for different use cases:

- **Standard**: General-purpose speech recognition
- **Enhanced**: Higher accuracy for specific domains
- **Video**: Optimized for video transcription
- **Phone Call**: Optimized for phone call audio

### Advanced Features

The service supports several advanced features for speech recognition:

- **Automatic punctuation**: Adds punctuation to the transcription
- **Speaker diarization**: Identifies different speakers in the audio
- **Word-level timestamps**: Provides timestamps for each word
- **Profanity filtering**: Filters out profanity from the transcription

## Text-to-Speech

The Speech Service provides text-to-speech conversion using Google Cloud Text-to-Speech API. This section provides information about the text-to-speech capabilities of the service.

### Supported Audio Formats

The service supports the following audio formats for output:

- MP3
- WAV
- OGG
- LINEAR16

### Supported Languages and Voices

The service supports a wide range of languages and voices for text-to-speech conversion. Some of the supported languages include:

- English (various dialects)
- French
- Spanish
- German
- Japanese
- Chinese
- Russian
- Arabic
- And many more

Each language has multiple voices available, including both standard and neural voices.

### SSML Support

The service supports Speech Synthesis Markup Language (SSML) for more control over the speech synthesis. SSML allows you to:

- Add pauses and breaks
- Emphasize specific words
- Control pronunciation
- Add audio effects
- And more

Example SSML:
```xml
<speak>
  Hello, this is a <emphasis level="strong">test</emphasis> of the text-to-speech API.
  <break time="1s"/>
  It supports SSML for more control over the speech synthesis.
</speak>
```

## Voice Selection

The Speech Service provides a wide range of voices for text-to-speech conversion. This section provides information about selecting and using different voices.

### Voice Types

The service supports two types of voices:

- **Standard**: Traditional text-to-speech voices
- **Neural**: High-quality, natural-sounding voices based on neural networks

### Voice Parameters

When using text-to-speech, you can customize the voice using the following parameters:

- **Speaking rate**: Controls the speed of the speech (0.25 to 4.0, default is 1.0)
- **Pitch**: Controls the pitch of the voice (-20.0 to 20.0, default is 0.0)
- **Volume gain**: Controls the volume of the speech (-96.0 to 16.0, default is 0.0)

### Voice Selection Best Practices

Here are some best practices for selecting voices:

1. **Match the language**: Use a voice that matches the language of the text.
2. **Consider the audience**: Choose a voice that is appropriate for the target audience.
3. **Test different voices**: Try different voices to find the one that best fits your needs.
4. **Use neural voices**: For the highest quality, use neural voices when available.
5. **Adjust parameters**: Fine-tune the speaking rate, pitch, and volume to get the desired effect.

## Performance Optimization

The Speech Service includes several optimizations to improve performance:

### Caching

The service implements caching for:

- Voice lists
- Common text-to-speech conversions
- Speech recognition results

### Audio Processing

The service includes optimizations for audio processing:

- **Audio normalization**: Normalizes audio levels for better recognition
- **Noise reduction**: Reduces background noise in audio
- **Sample rate conversion**: Converts audio to the optimal sample rate for recognition

### Batch Processing

For high-throughput scenarios, the service supports batch processing of:

- Speech recognition requests
- Text-to-speech requests

## Troubleshooting

### Common Issues

#### Google Cloud Authentication Errors

If the service cannot authenticate with Google Cloud, check that:

1. The `GOOGLE_APPLICATION_CREDENTIALS` environment variable is set correctly.
2. The credentials file exists and is readable.
3. The service account has the necessary permissions.
4. The APIs are enabled in the Google Cloud Console.

#### Audio Format Issues

If the service cannot process an audio file, check that:

1. The audio file is in a supported format.
2. The audio file is not corrupted.
3. The audio file is not too large (maximum size is 10 MB).
4. The audio file has a valid sample rate (8000 Hz to 48000 Hz).

#### Text-to-Speech Errors

If the service cannot convert text to speech, check that:

1. The text is not too long (maximum length is 5,000 characters).
2. The language code is valid.
3. The voice name is valid for the specified language.
4. The Google Cloud Text-to-Speech API quota has not been exceeded.

### Logs

The Speech Service logs information about requests, responses, and errors to help with troubleshooting. By default, logs are written to the console and to a log file (`speech_api.log`).

To increase the log level for more detailed information, set the `LOG_LEVEL` environment variable:

```
LOG_LEVEL=DEBUG
```

## References

1. [Google Cloud Speech-to-Text Documentation](https://cloud.google.com/speech-to-text/docs)
2. [Google Cloud Text-to-Speech Documentation](https://cloud.google.com/text-to-speech/docs)
3. [Flask Documentation](https://flask.palletsprojects.com/)
4. [SSML Reference](https://cloud.google.com/text-to-speech/docs/ssml)
5. [Docker Documentation](https://docs.docker.com/)

