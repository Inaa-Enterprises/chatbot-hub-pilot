"""
Speech-to-text service using Google Cloud Speech API.
"""

import os
import io
import logging
from typing import Dict, Any, Optional
from google.cloud import speech_v1 as speech

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SpeechToTextService:
    """
    Service for converting speech to text using Google Cloud Speech API.
    """
    
    def __init__(self, credentials_path: str = None):
        """
        Initialize the speech-to-text service.
        
        Args:
            credentials_path: Path to the Google Cloud credentials file
        """
        self.credentials_path = credentials_path or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
        
        # Initialize the client
        try:
            if self.credentials_path:
                self.client = speech.SpeechClient.from_service_account_file(self.credentials_path)
            else:
                self.client = speech.SpeechClient()
            logger.info("Speech-to-text client initialized successfully")
        except Exception as e:
            logger.exception("Failed to initialize speech-to-text client")
            self.client = None
    
    def transcribe_audio(
        self,
        audio_content: bytes,
        language_code: str = "en-US",
        sample_rate_hertz: int = 16000,
        encoding: str = "LINEAR16",
        enable_automatic_punctuation: bool = True,
        model: str = "default"
    ) -> Dict[str, Any]:
        """
        Transcribe audio to text.
        
        Args:
            audio_content: Audio content as bytes
            language_code: Language code (e.g., "en-US")
            sample_rate_hertz: Sample rate in Hertz
            encoding: Audio encoding (e.g., "LINEAR16")
            enable_automatic_punctuation: Whether to enable automatic punctuation
            model: Speech recognition model to use
            
        Returns:
            Dictionary with transcription results
        """
        if not self.client:
            return {"error": "Speech-to-text client not initialized"}
        
        try:
            # Configure audio
            audio = speech.RecognitionAudio(content=audio_content)
            
            # Configure recognition
            config = speech.RecognitionConfig(
                encoding=getattr(speech.RecognitionConfig.AudioEncoding, encoding),
                sample_rate_hertz=sample_rate_hertz,
                language_code=language_code,
                enable_automatic_punctuation=enable_automatic_punctuation,
                model=model
            )
            
            # Perform recognition
            response = self.client.recognize(config=config, audio=audio)
            
            # Process results
            results = []
            for result in response.results:
                for alternative in result.alternatives:
                    results.append({
                        "transcript": alternative.transcript,
                        "confidence": alternative.confidence
                    })
            
            return {
                "results": results,
                "success": True
            }
        
        except Exception as e:
            logger.exception("Error transcribing audio")
            return {
                "error": str(e),
                "success": False
            }
    
    def transcribe_file(
        self,
        file_path: str,
        language_code: str = "en-US",
        sample_rate_hertz: int = 16000,
        encoding: str = "LINEAR16",
        enable_automatic_punctuation: bool = True,
        model: str = "default"
    ) -> Dict[str, Any]:
        """
        Transcribe an audio file to text.
        
        Args:
            file_path: Path to the audio file
            language_code: Language code (e.g., "en-US")
            sample_rate_hertz: Sample rate in Hertz
            encoding: Audio encoding (e.g., "LINEAR16")
            enable_automatic_punctuation: Whether to enable automatic punctuation
            model: Speech recognition model to use
            
        Returns:
            Dictionary with transcription results
        """
        try:
            with io.open(file_path, "rb") as audio_file:
                content = audio_file.read()
                
            return self.transcribe_audio(
                audio_content=content,
                language_code=language_code,
                sample_rate_hertz=sample_rate_hertz,
                encoding=encoding,
                enable_automatic_punctuation=enable_automatic_punctuation,
                model=model
            )
        
        except Exception as e:
            logger.exception(f"Error reading audio file: {file_path}")
            return {
                "error": str(e),
                "success": False
            }
    
    def get_encoding_from_mime_type(self, mime_type: str) -> Optional[str]:
        """
        Get the appropriate encoding for a given MIME type.
        
        Args:
            mime_type: MIME type of the audio file
            
        Returns:
            Encoding name or None if not supported
        """
        mime_to_encoding = {
            "audio/wav": "LINEAR16",
            "audio/x-wav": "LINEAR16",
            "audio/flac": "FLAC",
            "audio/x-flac": "FLAC",
            "audio/ogg": "OGG_OPUS",
            "audio/ogg;codecs=opus": "OGG_OPUS",
            "audio/mp3": "MP3",
            "audio/mpeg": "MP3",
            "audio/webm": "WEBM_OPUS"
        }
        
        return mime_to_encoding.get(mime_type.lower())

