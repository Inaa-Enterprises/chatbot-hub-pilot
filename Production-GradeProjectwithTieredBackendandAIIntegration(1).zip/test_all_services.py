#!/usr/bin/env python3
"""
Comprehensive test suite for all services in the Synapse-OD Hub system.
"""

import requests
import json
import argparse
import sys
import time
import os
import tempfile
import logging
from typing import Dict, Any, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("test_all_services.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ServiceTester:
    """
    Base class for service testers.
    """
    
    def __init__(self, base_url: str):
        """
        Initialize the service tester.
        
        Args:
            base_url: Base URL of the service
        """
        self.base_url = base_url
    
    def test_health(self) -> bool:
        """
        Test the health endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info(f"Testing health endpoint for {self.base_url}")
        try:
            response = requests.get(f"{self.base_url}/health")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Health check successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Health check failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Health check failed with exception: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """
        Run all tests for the service.
        
        Returns:
            True if all tests passed, False otherwise
        """
        return self.test_health()


class LLMServiceTester(ServiceTester):
    """
    Tester for the LLM service.
    """
    
    def __init__(self, base_url: str, api_key: str = "test-api-key"):
        """
        Initialize the LLM service tester.
        
        Args:
            base_url: Base URL of the LLM service
            api_key: API key for authentication
        """
        super().__init__(base_url)
        self.api_key = api_key
    
    def test_health(self) -> bool:
        """
        Test the health endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info(f"Testing health endpoint for {self.base_url}")
        try:
            response = requests.get(
                f"{self.base_url}/health",
                headers={"X-API-Key": self.api_key}
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Health check successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Health check failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Health check failed with exception: {e}")
            return False
    
    def test_models(self) -> bool:
        """
        Test the models endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing models endpoint")
        try:
            response = requests.get(
                f"{self.base_url}/models",
                headers={"X-API-Key": self.api_key}
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Models endpoint successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Models endpoint failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Models endpoint failed with exception: {e}")
            return False
    
    def test_chat(self) -> bool:
        """
        Test the chat endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing chat endpoint")
        try:
            data = {
                "messages": [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "Hello, how are you?"}
                ],
                "options": {
                    "model": "vicuna-13b",
                    "temperature": 0.7,
                    "maxTokens": 100,
                    "forceCloud": False
                }
            }
            
            response = requests.post(
                f"{self.base_url}/chat",
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": self.api_key
                },
                json=data
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Chat endpoint successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Chat endpoint failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Chat endpoint failed with exception: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """
        Run all tests for the LLM service.
        
        Returns:
            True if all tests passed, False otherwise
        """
        health_result = self.test_health()
        models_result = self.test_models()
        chat_result = self.test_chat()
        
        return health_result and models_result and chat_result


class BotServiceTester(ServiceTester):
    """
    Tester for the Bot service.
    """
    
    def test_bots(self) -> bool:
        """
        Test the bots endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing bots endpoint")
        try:
            response = requests.get(f"{self.base_url}/bots")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Bots endpoint successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Bots endpoint failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Bots endpoint failed with exception: {e}")
            return False
    
    def test_create_bot(self) -> Optional[str]:
        """
        Test creating a bot.
        
        Returns:
            Bot ID if the test passed, None otherwise
        """
        logger.info("Testing create bot endpoint")
        try:
            data = {
                "name": "Test Bot",
                "description": "A bot for testing",
                "model_id": "vicuna-13b",
                "knowledge_base_id": "test-kb"
            }
            
            response = requests.post(
                f"{self.base_url}/bots",
                json=data
            )
            
            if response.status_code == 201:
                bot = response.json()
                logger.info(f"✅ Create bot successful: {json.dumps(bot, indent=2)}")
                return bot.get("id")
            else:
                logger.error(f"❌ Create bot failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Create bot failed with exception: {e}")
            return None
    
    def test_create_conversation(self, bot_id: str) -> Optional[str]:
        """
        Test creating a conversation.
        
        Args:
            bot_id: ID of the bot
            
        Returns:
            Conversation ID if the test passed, None otherwise
        """
        logger.info(f"Testing create conversation endpoint for bot {bot_id}")
        try:
            data = {
                "user_id": "test-user"
            }
            
            response = requests.post(
                f"{self.base_url}/bots/{bot_id}/conversations",
                json=data
            )
            
            if response.status_code == 201:
                conversation = response.json()
                logger.info(f"✅ Create conversation successful: {json.dumps(conversation, indent=2)}")
                return conversation.get("id")
            else:
                logger.error(f"❌ Create conversation failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Create conversation failed with exception: {e}")
            return None
    
    def test_send_message(self, bot_id: str, conversation_id: str) -> bool:
        """
        Test sending a message.
        
        Args:
            bot_id: ID of the bot
            conversation_id: ID of the conversation
            
        Returns:
            True if the test passed, False otherwise
        """
        logger.info(f"Testing send message endpoint for bot {bot_id} and conversation {conversation_id}")
        try:
            data = {
                "message": "Hello, how are you?",
                "user_id": "test-user"
            }
            
            response = requests.post(
                f"{self.base_url}/bots/{bot_id}/conversations/{conversation_id}/messages",
                json=data
            )
            
            if response.status_code == 200:
                result = response.json()
                logger.info(f"✅ Send message successful: {json.dumps(result, indent=2)}")
                return True
            else:
                logger.error(f"❌ Send message failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Send message failed with exception: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """
        Run all tests for the Bot service.
        
        Returns:
            True if all tests passed, False otherwise
        """
        health_result = self.test_health()
        bots_result = self.test_bots()
        
        bot_id = self.test_create_bot()
        if not bot_id:
            return False
        
        conversation_id = self.test_create_conversation(bot_id)
        if not conversation_id:
            return False
        
        message_result = self.test_send_message(bot_id, conversation_id)
        
        return health_result and bots_result and message_result


class SpeechServiceTester(ServiceTester):
    """
    Tester for the Speech service.
    """
    
    def test_speech_health(self) -> bool:
        """
        Test the speech health endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing speech health endpoint")
        try:
            response = requests.get(f"{self.base_url}/speech/health")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Speech health check successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Speech health check failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Speech health check failed with exception: {e}")
            return False
    
    def test_text_to_speech(self) -> bool:
        """
        Test the text-to-speech endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing text-to-speech endpoint")
        try:
            data = {
                "text": "Hello, this is a test of the text-to-speech API.",
                "language_code": "en-US",
                "voice_name": "en-US-Neural2-F"
            }
            
            response = requests.post(
                f"{self.base_url}/speech/tts",
                json=data
            )
            
            if response.status_code == 200:
                # Save the audio to a temporary file
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
                temp_file.write(response.content)
                temp_file.close()
                
                logger.info(f"✅ Text-to-speech successful. Audio saved to {temp_file.name}")
                return True
            else:
                logger.error(f"❌ Text-to-speech failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Text-to-speech failed with exception: {e}")
            return False
    
    def test_list_voices(self) -> bool:
        """
        Test the list voices endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing list voices endpoint")
        try:
            response = requests.get(f"{self.base_url}/speech/tts/voices")
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success") and "voices" in data:
                    logger.info(f"✅ List voices successful. Found {len(data['voices'])} voices.")
                    return True
                else:
                    logger.error(f"❌ List voices failed. Response: {json.dumps(data, indent=2)}")
                    return False
            else:
                logger.error(f"❌ List voices failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ List voices failed with exception: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """
        Run all tests for the Speech service.
        
        Returns:
            True if all tests passed, False otherwise
        """
        health_result = self.test_health()
        speech_health_result = self.test_speech_health()
        tts_result = self.test_text_to_speech()
        voices_result = self.test_list_voices()
        
        return health_result and speech_health_result and tts_result and voices_result


class LearningServiceTester(ServiceTester):
    """
    Tester for the Learning service.
    """
    
    def test_create_feedback(self) -> Optional[str]:
        """
        Test creating feedback.
        
        Returns:
            Feedback ID if the test passed, None otherwise
        """
        logger.info("Testing feedback creation")
        try:
            data = {
                "user_id": "test-user",
                "bot_id": "test-bot",
                "conversation_id": "test-conversation",
                "rating": 5,
                "feedback_text": "This is a test feedback",
                "tags": ["test", "api"]
            }
            
            response = requests.post(f"{self.base_url}/feedback", json=data)
            
            if response.status_code == 201:
                feedback = response.json()
                logger.info(f"✅ Feedback created successfully: {feedback['id']}")
                return feedback['id']
            else:
                logger.error(f"❌ Feedback creation failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Feedback creation failed with exception: {e}")
            return None
    
    def test_create_training_example(self) -> Optional[str]:
        """
        Test creating a training example.
        
        Returns:
            Example ID if the test passed, None otherwise
        """
        logger.info("Testing training example creation")
        try:
            data = {
                "input_text": "What is the capital of France?",
                "output_text": "The capital of France is Paris.",
                "source": "test",
                "quality_score": 0.9,
                "metadata": {
                    "category": "geography",
                    "difficulty": "easy"
                }
            }
            
            response = requests.post(f"{self.base_url}/examples", json=data)
            
            if response.status_code == 201:
                example = response.json()
                logger.info(f"✅ Training example created successfully: {example['id']}")
                return example['id']
            else:
                logger.error(f"❌ Training example creation failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Training example creation failed with exception: {e}")
            return None
    
    def test_create_training_job(self, example_ids: List[str]) -> Optional[str]:
        """
        Test creating a training job.
        
        Args:
            example_ids: List of training example IDs
            
        Returns:
            Job ID if the test passed, None otherwise
        """
        logger.info("Testing training job creation")
        try:
            data = {
                "model_id": "test-model",
                "training_examples": example_ids,
                "hyperparameters": {
                    "learning_rate": 0.001,
                    "batch_size": 16,
                    "epochs": 3
                }
            }
            
            response = requests.post(f"{self.base_url}/jobs", json=data)
            
            if response.status_code == 201:
                job = response.json()
                logger.info(f"✅ Training job created successfully: {job['id']}")
                return job['id']
            else:
                logger.error(f"❌ Training job creation failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Training job creation failed with exception: {e}")
            return None
    
    def test_execute_training_job(self, job_id: str) -> bool:
        """
        Test executing a training job.
        
        Args:
            job_id: ID of the job to execute
            
        Returns:
            True if the test passed, False otherwise
        """
        logger.info(f"Testing execute training job: {job_id}")
        try:
            response = requests.post(f"{self.base_url}/jobs/{job_id}/execute")
            
            if response.status_code == 200:
                result = response.json()
                logger.info(f"✅ Training job execution started: {result['job_id']}")
                
                # Poll for job completion
                logger.info("Polling for job completion...")
                max_polls = 20
                for i in range(max_polls):
                    time.sleep(1)
                    job_response = requests.get(f"{self.base_url}/jobs/{job_id}")
                    if job_response.status_code == 200:
                        job = job_response.json()
                        if job['status'] in ['completed', 'failed']:
                            break
                
                if job['status'] == 'completed':
                    logger.info(f"✅ Training job completed successfully")
                    return True
                else:
                    logger.error(f"❌ Training job did not complete within timeout or failed")
                    return False
            else:
                logger.error(f"❌ Execute training job failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Execute training job failed with exception: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """
        Run all tests for the Learning service.
        
        Returns:
            True if all tests passed, False otherwise
        """
        health_result = self.test_health()
        
        feedback_id = self.test_create_feedback()
        if not feedback_id:
            return False
        
        example_id = self.test_create_training_example()
        if not example_id:
            return False
        
        job_id = self.test_create_training_job([example_id])
        if not job_id:
            return False
        
        job_result = self.test_execute_training_job(job_id)
        
        return health_result and job_result


class IntegrationServiceTester(ServiceTester):
    """
    Tester for the Integration service.
    """
    
    def test_integration_health(self) -> bool:
        """
        Test the integration health endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing integration health endpoint")
        try:
            response = requests.get(f"{self.base_url}/api/health")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Integration health check successful: {json.dumps(data, indent=2)}")
                return True
            else:
                logger.error(f"❌ Integration health check failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Integration health check failed with exception: {e}")
            return False
    
    def test_create_bot(self) -> Optional[Dict[str, Any]]:
        """
        Test creating a bot through the integration API.
        
        Returns:
            Bot data if the test passed, None otherwise
        """
        logger.info("Testing create bot endpoint")
        try:
            data = {
                "name": "Integration Test Bot",
                "description": "A bot for integration testing",
                "model_id": "vicuna-13b",
                "knowledge_base_id": "test-kb"
            }
            
            response = requests.post(
                f"{self.base_url}/api/bots",
                json=data
            )
            
            if response.status_code == 201:
                bot = response.json()
                logger.info(f"✅ Create bot successful: {json.dumps(bot, indent=2)}")
                return bot
            else:
                logger.error(f"❌ Create bot failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Create bot failed with exception: {e}")
            return None
    
    def test_create_conversation(self, bot_id: str) -> Optional[Dict[str, Any]]:
        """
        Test creating a conversation through the integration API.
        
        Args:
            bot_id: ID of the bot
            
        Returns:
            Conversation data if the test passed, None otherwise
        """
        logger.info(f"Testing create conversation endpoint for bot {bot_id}")
        try:
            data = {
                "user_id": "integration-test-user"
            }
            
            response = requests.post(
                f"{self.base_url}/api/bots/{bot_id}/conversations",
                json=data
            )
            
            if response.status_code == 201:
                conversation = response.json()
                logger.info(f"✅ Create conversation successful: {json.dumps(conversation, indent=2)}")
                return conversation
            else:
                logger.error(f"❌ Create conversation failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
        except Exception as e:
            logger.exception(f"❌ Create conversation failed with exception: {e}")
            return None
    
    def test_chat(self, bot_id: str, conversation_id: str) -> bool:
        """
        Test the chat endpoint.
        
        Args:
            bot_id: ID of the bot
            conversation_id: ID of the conversation
            
        Returns:
            True if the test passed, False otherwise
        """
        logger.info(f"Testing chat endpoint for bot {bot_id} and conversation {conversation_id}")
        try:
            data = {
                "bot_id": bot_id,
                "conversation_id": conversation_id,
                "message": "Hello, how are you?",
                "user_id": "integration-test-user"
            }
            
            response = requests.post(
                f"{self.base_url}/api/chat",
                json=data
            )
            
            if response.status_code == 200:
                result = response.json()
                logger.info(f"✅ Chat successful: {json.dumps(result, indent=2)}")
                return True
            else:
                logger.error(f"❌ Chat failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Chat failed with exception: {e}")
            return False
    
    def test_text_to_speech(self) -> bool:
        """
        Test the text-to-speech endpoint.
        
        Returns:
            True if the test passed, False otherwise
        """
        logger.info("Testing text-to-speech endpoint")
        try:
            data = {
                "text": "Hello, this is a test of the integration API text-to-speech endpoint.",
                "language_code": "en-US",
                "voice_name": "en-US-Neural2-F"
            }
            
            response = requests.post(
                f"{self.base_url}/api/text-to-speech",
                json=data
            )
            
            if response.status_code == 200:
                # Save the audio to a temporary file
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
                temp_file.write(response.content)
                temp_file.close()
                
                logger.info(f"✅ Text-to-speech successful. Audio saved to {temp_file.name}")
                return True
            else:
                logger.error(f"❌ Text-to-speech failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Text-to-speech failed with exception: {e}")
            return False
    
    def test_feedback(self, bot_id: str, conversation_id: str) -> bool:
        """
        Test the feedback endpoint.
        
        Args:
            bot_id: ID of the bot
            conversation_id: ID of the conversation
            
        Returns:
            True if the test passed, False otherwise
        """
        logger.info(f"Testing feedback endpoint for bot {bot_id} and conversation {conversation_id}")
        try:
            data = {
                "user_id": "integration-test-user",
                "bot_id": bot_id,
                "conversation_id": conversation_id,
                "rating": 5,
                "feedback_text": "This is a test feedback from the integration API",
                "tags": ["integration", "test"]
            }
            
            response = requests.post(
                f"{self.base_url}/api/feedback",
                json=data
            )
            
            if response.status_code == 201:
                feedback = response.json()
                logger.info(f"✅ Feedback successful: {json.dumps(feedback, indent=2)}")
                return True
            else:
                logger.error(f"❌ Feedback failed with status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
        except Exception as e:
            logger.exception(f"❌ Feedback failed with exception: {e}")
            return False
    
    def run_all_tests(self) -> bool:
        """
        Run all tests for the Integration service.
        
        Returns:
            True if all tests passed, False otherwise
        """
        health_result = self.test_health()
        integration_health_result = self.test_integration_health()
        
        bot = self.test_create_bot()
        if not bot:
            return False
        
        conversation = self.test_create_conversation(bot["id"])
        if not conversation:
            return False
        
        chat_result = self.test_chat(bot["id"], conversation["id"])
        tts_result = self.test_text_to_speech()
        feedback_result = self.test_feedback(bot["id"], conversation["id"])
        
        return health_result and integration_health_result and chat_result and tts_result and feedback_result


def main():
    parser = argparse.ArgumentParser(description='Test all services in the Synapse-OD Hub system')
    parser.add_argument('--llm-url', default='http://localhost:3001/api', help='URL of the LLM API')
    parser.add_argument('--bot-url', default='http://localhost:3002/api', help='URL of the Bot API')
    parser.add_argument('--speech-url', default='http://localhost:3003/api', help='URL of the Speech API')
    parser.add_argument('--learning-url', default='http://localhost:3004', help='URL of the Learning API')
    parser.add_argument('--integration-url', default='http://localhost:3005', help='URL of the Integration API')
    parser.add_argument('--test', choices=['llm', 'bot', 'speech', 'learning', 'integration', 'all'], default='all', help='Which service to test')
    
    args = parser.parse_args()
    
    success = True
    
    if args.test in ['llm', 'all']:
        logger.info("=== Testing LLM Service ===")
        llm_tester = LLMServiceTester(args.llm_url)
        if not llm_tester.run_all_tests():
            success = False
            logger.error("❌ LLM Service tests failed")
        else:
            logger.info("✅ LLM Service tests passed")
    
    if args.test in ['bot', 'all']:
        logger.info("=== Testing Bot Service ===")
        bot_tester = BotServiceTester(args.bot_url)
        if not bot_tester.run_all_tests():
            success = False
            logger.error("❌ Bot Service tests failed")
        else:
            logger.info("✅ Bot Service tests passed")
    
    if args.test in ['speech', 'all']:
        logger.info("=== Testing Speech Service ===")
        speech_tester = SpeechServiceTester(args.speech_url)
        if not speech_tester.run_all_tests():
            success = False
            logger.error("❌ Speech Service tests failed")
        else:
            logger.info("✅ Speech Service tests passed")
    
    if args.test in ['learning', 'all']:
        logger.info("=== Testing Learning Service ===")
        learning_tester = LearningServiceTester(args.learning_url)
        if not learning_tester.run_all_tests():
            success = False
            logger.error("❌ Learning Service tests failed")
        else:
            logger.info("✅ Learning Service tests passed")
    
    if args.test in ['integration', 'all']:
        logger.info("=== Testing Integration Service ===")
        integration_tester = IntegrationServiceTester(args.integration_url)
        if not integration_tester.run_all_tests():
            success = False
            logger.error("❌ Integration Service tests failed")
        else:
            logger.info("✅ Integration Service tests passed")
    
    if success:
        logger.info("✅ All tests passed!")
        sys.exit(0)
    else:
        logger.error("❌ Some tests failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()

