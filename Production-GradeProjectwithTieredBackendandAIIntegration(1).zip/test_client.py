#!/usr/bin/env python3
"""
Test client for the LLM API Server.
This script tests the API endpoints and verifies that they are working correctly.
"""

import requests
import json
import time
import argparse
import sys

def test_health(base_url):
    """Test the health endpoint"""
    print("Testing health endpoint...")
    try:
        response = requests.get(f"{base_url}/api/health")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Health check successful: {json.dumps(data, indent=2)}")
            return True
        else:
            print(f"❌ Health check failed with status code {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Health check failed with exception: {e}")
        return False

def test_models(base_url, api_key):
    """Test the models endpoint"""
    print("\nTesting models endpoint...")
    try:
        headers = {"X-API-Key": api_key}
        response = requests.get(f"{base_url}/api/models", headers=headers)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Models check successful: {json.dumps(data, indent=2)}")
            return True
        else:
            print(f"❌ Models check failed with status code {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Models check failed with exception: {e}")
        return False

def test_chat(base_url, api_key):
    """Test the chat endpoint"""
    print("\nTesting chat endpoint...")
    try:
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        data = {
            "messages": [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": "What is the capital of France?"}
            ],
            "options": {
                "temperature": 0.7,
                "maxTokens": 100
            }
        }
        
        print("Sending request...")
        start_time = time.time()
        response = requests.post(f"{base_url}/api/chat", headers=headers, json=data)
        elapsed_time = time.time() - start_time
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Chat request successful (took {elapsed_time:.2f}s)")
            print(f"Model: {result.get('model', 'unknown')}")
            if 'choices' in result and len(result['choices']) > 0:
                print(f"Response: {result['choices'][0]['message']['content']}")
            else:
                print(f"Response structure: {json.dumps(result, indent=2)}")
            return True
        else:
            print(f"❌ Chat request failed with status code {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Chat request failed with exception: {e}")
        return False

def test_completions(base_url, api_key):
    """Test the completions endpoint"""
    print("\nTesting completions endpoint...")
    try:
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        data = {
            "prompt": "What is the capital of France?",
            "options": {
                "temperature": 0.7,
                "maxTokens": 100
            }
        }
        
        print("Sending request...")
        start_time = time.time()
        response = requests.post(f"{base_url}/api/completions", headers=headers, json=data)
        elapsed_time = time.time() - start_time
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Completions request successful (took {elapsed_time:.2f}s)")
            print(f"Model: {result.get('model', 'unknown')}")
            if 'choices' in result and len(result['choices']) > 0:
                print(f"Response: {result['choices'][0]['text']}")
            else:
                print(f"Response structure: {json.dumps(result, indent=2)}")
            return True
        else:
            print(f"❌ Completions request failed with status code {response.status_code}")
            print(f"Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Completions request failed with exception: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description='Test the LLM API Server')
    parser.add_argument('--url', default='http://localhost:3000', help='Base URL of the API server')
    parser.add_argument('--api-key', default='test-api-key', help='API key for authentication')
    parser.add_argument('--test', choices=['health', 'models', 'chat', 'completions', 'all'], default='all', help='Which test to run')
    
    args = parser.parse_args()
    
    success = True
    
    if args.test in ['health', 'all']:
        if not test_health(args.url):
            success = False
            if args.test != 'all':
                sys.exit(1)
    
    if args.test in ['models', 'all']:
        if not test_models(args.url, args.api_key):
            success = False
            if args.test != 'all':
                sys.exit(1)
    
    if args.test in ['chat', 'all']:
        if not test_chat(args.url, args.api_key):
            success = False
            if args.test != 'all':
                sys.exit(1)
    
    if args.test in ['completions', 'all']:
        if not test_completions(args.url, args.api_key):
            success = False
            if args.test != 'all':
                sys.exit(1)
    
    if success:
        print("\n✅ All tests passed!")
        sys.exit(0)
    else:
        print("\n❌ Some tests failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()

