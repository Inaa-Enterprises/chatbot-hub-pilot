"""
Text-to-speech service using Google Cloud Text-to-Speech API.
"""

import os
import io
import logging
from typing import Dict, Any, Optional, List
from google.cloud import texttospeech_v1 as texttospeech

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TextToSpeechService:
    """
    Service for converting text to speech using Google Cloud Text-to-Speech API.
    """
    
    def __init__(self, credentials_path: str = None):
        """
        Initialize the text-to-speech service.
        
        Args:
            credentials_path: Path to the Google Cloud credentials file
        """
        self.credentials_path = credentials_path or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
        
        # Initialize the client
        try:
            if self.credentials_path:
                self.client = texttospeech.TextToSpeechClient.from_service_account_file(self.credentials_path)
            else:
                self.client = texttospeech.TextToSpeechClient()
            logger.info("Text-to-speech client initialized successfully")
        except Exception as e:
            logger.exception("Failed to initialize text-to-speech client")
            self.client = None
    
    def synthesize_speech(
        self,
        text: str,
        language_code: str = "en-US",
        voice_name: str = "en-US-Neural2-F",
        speaking_rate: float = 1.0,
        pitch: float = 0.0,
        volume_gain_db: float = 0.0,
        audio_encoding: str = "MP3"
    ) -> Dict[str, Any]:
        """
        Synthesize speech from text.
        
        Args:
            text: Text to synthesize
            language_code: Language code (e.g., "en-US")
            voice_name: Voice name (e.g., "en-US-Neural2-F")
            speaking_rate: Speaking rate (1.0 is normal speed)
            pitch: Voice pitch (-20.0 to 20.0)
            volume_gain_db: Volume gain in dB (-96.0 to 16.0)
            audio_encoding: Audio encoding format
            
        Returns:
            Dictionary with synthesis results
        """
        if not self.client:
            return {"error": "Text-to-speech client not initialized", "success": False}
        
        try:
            # Set the text input to be synthesized
            synthesis_input = texttospeech.SynthesisInput(text=text)
            
            # Build the voice request
            voice = texttospeech.VoiceSelectionParams(
                language_code=language_code,
                name=voice_name
            )
            
            # Select the audio encoding
            audio_config = texttospeech.AudioConfig(
                audio_encoding=getattr(texttospeech.AudioEncoding, audio_encoding),
                speaking_rate=speaking_rate,
                pitch=pitch,
                volume_gain_db=volume_gain_db
            )
            
            # Perform the synthesis
            response = self.client.synthesize_speech(
                input=synthesis_input,
                voice=voice,
                audio_config=audio_config
            )
            
            return {
                "audio_content": response.audio_content,
                "success": True
            }
        
        except Exception as e:
            logger.exception("Error synthesizing speech")
            return {
                "error": str(e),
                "success": False
            }
    
    def save_to_file(self, audio_content: bytes, file_path: str) -> Dict[str, Any]:
        """
        Save audio content to a file.
        
        Args:
            audio_content: Audio content as bytes
            file_path: Path to save the audio file
            
        Returns:
            Dictionary with save results
        """
        try:
            with open(file_path, "wb") as out:
                out.write(audio_content)
            
            return {
                "file_path": file_path,
                "success": True
            }
        
        except Exception as e:
            logger.exception(f"Error saving audio to file: {file_path}")
            return {
                "error": str(e),
                "success": False
            }
    
    def list_voices(self, language_code: str = None) -> Dict[str, Any]:
        """
        List available voices.
        
        Args:
            language_code: Optional language code to filter voices
            
        Returns:
            Dictionary with available voices
        """
        if not self.client:
            return {"error": "Text-to-speech client not initialized", "success": False}
        
        try:
            response = self.client.list_voices(language_code=language_code)
            
            voices = []
            for voice in response.voices:
                voices.append({
                    "name": voice.name,
                    "language_codes": voice.language_codes,
                    "ssml_gender": texttospeech.SsmlVoiceGender(voice.ssml_gender).name,
                    "natural_sample_rate_hertz": voice.natural_sample_rate_hertz
                })
            
            return {
                "voices": voices,
                "success": True
            }
        
        except Exception as e:
            logger.exception("Error listing voices")
            return {
                "error": str(e),
                "success": False
            }
    
    def get_audio_encoding_from_extension(self, file_extension: str) -> Optional[str]:
        """
        Get the appropriate audio encoding for a given file extension.
        
        Args:
            file_extension: File extension (e.g., ".mp3")
            
        Returns:
            Audio encoding name or None if not supported
        """
        extension_to_encoding = {
            ".mp3": "MP3",
            ".wav": "LINEAR16",
            ".ogg": "OGG_OPUS",
            ".opus": "OGG_OPUS"
        }
        
        return extension_to_encoding.get(file_extension.lower())

