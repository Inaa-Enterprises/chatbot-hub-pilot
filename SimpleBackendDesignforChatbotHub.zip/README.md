# Backend project structure

/home/ubuntu/synapse_backend/
├── app/
│   ├── main.py         # FastAPI app, chat endpoint
│   ├── personas.py     # Persona definitions (system prompts)
│   ├── models.py       # Pydantic models
│   └── services.py     # Gemini interaction logic
├── requirements.txt    # Python dependencies
└── .env.example        # Example environment variables
