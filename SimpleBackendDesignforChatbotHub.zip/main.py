from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
import os
import logging
import sys
import argparse

# Add the current directory to the path so that we can import from src
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))

# Parse command line arguments
parser = argparse.ArgumentParser(description='LLM API Server')
parser.add_argument('--port', type=int, default=3000, help='Port to run the server on')
args = parser.parse_args()

# Import routes
from src.routes.llm import llm_bp

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("llm_api_server.log"),
        logging.StreamHandler()
    ]
)

# Create Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Register blueprints
app.register_blueprint(llm_bp, url_prefix='/api')

# Default route
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

# Health check route
@app.route('/health')
def health():
    return jsonify({"status": "ok"})

# Error handlers
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    # Get port from command line arguments or environment variable
    port = args.port or int(os.environ.get("PORT", 3000))
    
    # Set environment variables for LLM server
    os.environ.setdefault("LOCAL_LLM_ENDPOINT", "http://localhost:8000")
    os.environ.setdefault("LLM_API_KEY", "test-api-key")
    
    print(f"Starting server on port {port}")
    
    # Start server
    app.run(host='0.0.0.0', port=port, debug=True)

