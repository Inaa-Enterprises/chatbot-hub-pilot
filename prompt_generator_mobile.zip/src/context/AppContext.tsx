import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { QuestionnaireTemplate, SavedPrompt } from '../types';

interface AppContextType {
  savedPrompts: SavedPrompt[];
  addSavedPrompt: (prompt: SavedPrompt) => void;
  deleteSavedPrompt: (id: string) => void;
  initialText: string;
  setInitialText: (text: string) => void;
  activeTemplate: QuestionnaireTemplate | null;
  setActiveTemplate: (template: QuestionnaireTemplate | null) => void;
  answers: Record<string, any>;
  setAnswers: (answers: Record<string, any>) => void;
  updateAnswer: (questionId: string, value: any) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>([]);
  const [initialText, setInitialText] = useState<string>('');
  const [activeTemplate, setActiveTemplate] = useState<QuestionnaireTemplate | null>(null);
  const [answers, setAnswers] = useState<Record<string, any>>({});

  // Load saved prompts from localStorage on initial render
  useEffect(() => {
    const storedPrompts = localStorage.getItem('savedPrompts');
    if (storedPrompts) {
      setSavedPrompts(JSON.parse(storedPrompts));
    }
  }, []);

  // Save prompts to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('savedPrompts', JSON.stringify(savedPrompts));
  }, [savedPrompts]);

  const addSavedPrompt = (prompt: SavedPrompt) => {
    setSavedPrompts((prev) => [...prev, prompt]);
  };

  const deleteSavedPrompt = (id: string) => {
    setSavedPrompts((prev) => prev.filter((prompt) => prompt.id !== id));
  };

  const updateAnswer = (questionId: string, value: any) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: value,
    }));
  };

  return (
    <AppContext.Provider
      value={{
        savedPrompts,
        addSavedPrompt,
        deleteSavedPrompt,
        initialText,
        setInitialText,
        activeTemplate,
        setActiveTemplate,
        answers,
        setAnswers,
        updateAnswer,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
