import { useState } from 'react';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

interface CameraHookResult {
  photo: string | null;
  takePhoto: () => Promise<void>;
  error: string | null;
}

export function useCamera(): CameraHookResult {
  const [photo, setPhoto] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const takePhoto = async () => {
    try {
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: true,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera
      });
      
      setPhoto(image.dataUrl || null);
      setError(null);
    } catch (e) {
      setError('Error taking photo: ' + (e instanceof Error ? e.message : String(e)));
      console.error('Camera error:', e);
    }
  };

  return {
    photo,
    takePhoto,
    error
  };
}
