import { useState, useEffect } from 'react';
import { useCamera } from '../hooks/useCamera';
import { useAppContext } from '../context/AppContext';

interface ImageToTextResult {
  text: string;
  isProcessing: boolean;
  error: string | null;
}

// Mock function to simulate on-device AI text extraction
// In a real app, this would use device ML capabilities or a cloud API
const extractTextFromImage = async (imageDataUrl: string): Promise<string> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // In a real implementation, this would use ML to extract text
  // For now, we'll return a placeholder based on the image size
  const imgSize = imageDataUrl.length;
  return `Extracted text from image (${Math.floor(imgSize / 1000)}KB): This appears to be ${
    imgSize > 100000 ? 'a detailed image' : 'a simple image'
  } that could be used for ${
    imgSize > 150000 ? 'creating complex visual content' : 'basic reference material'
  }.`;
};

export function useCameraWithTextExtraction(): ImageToTextResult & { 
  photo: string | null; 
  takePhoto: () => Promise<void>;
  applyExtractedText: () => void;
} {
  const { photo, takePhoto, error: cameraError } = useCamera();
  const [extractedText, setExtractedText] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(cameraError);
  const { setInitialText } = useAppContext();

  useEffect(() => {
    if (photo) {
      setIsProcessing(true);
      extractTextFromImage(photo)
        .then(text => {
          setExtractedText(text);
          setError(null);
        })
        .catch(err => {
          setError('Error extracting text: ' + (err instanceof Error ? err.message : String(err)));
          console.error('Text extraction error:', err);
        })
        .finally(() => {
          setIsProcessing(false);
        });
    }
  }, [photo]);

  const applyExtractedText = () => {
    if (extractedText) {
      setInitialText(extractedText);
    }
  };

  return {
    text: extractedText,
    isProcessing,
    error,
    photo,
    takePhoto,
    applyExtractedText
  };
}
