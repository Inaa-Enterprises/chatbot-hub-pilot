import { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';

// Hook for offline support and synchronization
export function useOfflineSupport() {
  const { setInitialText } = useAppContext();
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [pendingSync, setPendingSync] = useState<boolean>(false);

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // When coming back online, check if we need to sync
      if (pendingSync) {
        syncData();
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      // Mark that we'll need to sync when back online
      setPendingSync(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [pendingSync]);

  // Mock function to simulate syncing data when back online
  const syncData = () => {
    console.log('Syncing data with server...');
    // In a real app, this would sync with a backend
    setTimeout(() => {
      console.log('Sync complete');
      setPendingSync(false);
    }, 1500);
  };

  // Function to save data for offline use
  const saveForOffline = (text: string) => {
    setInitialText(text);
    // In a real app, we might queue this for later sync
    if (!isOnline) {
      setPendingSync(true);
    }
  };

  return {
    isOnline,
    pendingSync,
    saveForOffline
  };
}
