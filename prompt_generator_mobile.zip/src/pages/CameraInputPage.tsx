import React from 'react';
import { Link } from 'react-router-dom';
import { useCameraWithTextExtraction } from '../hooks/useCameraWithTextExtraction';

const CameraInputPage: React.FC = () => {
  const { 
    photo, 
    takePhoto, 
    text, 
    isProcessing, 
    error, 
    applyExtractedText 
  } = useCameraWithTextExtraction();

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 neon-text">Camera Input</h1>
      
      <div className="cyber-card grid-background p-6 mb-6">
        <h2 className="text-2xl font-bold mb-4 neon-text-cyan">Capture Image</h2>
        <p className="text-gray-300 mb-6">
          Take a photo to extract text and use it as a starting point for your prompt.
        </p>
        
        <div className="flex flex-col items-center">
          <button 
            onClick={takePhoto} 
            className="cyber-button mb-6"
            disabled={isProcessing}
          >
            {isProcessing ? 'Processing...' : 'Take Photo'}
          </button>
          
          {error && (
            <div className="bg-red-900 bg-opacity-50 border border-red-500 text-red-100 p-4 rounded mb-6 w-full">
              {error}
            </div>
          )}
          
          {photo && (
            <div className="mb-6 w-full">
              <img 
                src={photo} 
                alt="Captured" 
                className="w-full h-auto rounded neon-border mb-4" 
              />
            </div>
          )}
          
          {text && (
            <div className="w-full">
              <h3 className="text-xl font-bold mb-2 neon-text">Extracted Text</h3>
              <div className="bg-gray-900 p-4 rounded mb-4">
                <p className="text-gray-300">{text}</p>
              </div>
              
              <div className="flex justify-between">
                <button 
                  onClick={applyExtractedText} 
                  className="cyber-button"
                >
                  Use This Text
                </button>
                
                <Link to="/templates">
                  <button className="cyber-button-secondary">
                    Skip
                  </button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="cyber-card grid-background p-6">
        <h2 className="text-xl font-bold mb-4 neon-text-cyan">How it works</h2>
        <div className="space-y-4">
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              1
            </div>
            <p className="text-gray-300">
              Take a photo of text, notes, or any visual reference.
            </p>
          </div>
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              2
            </div>
            <p className="text-gray-300">
              The app will extract text and relevant information from the image.
            </p>
          </div>
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              3
            </div>
            <p className="text-gray-300">
              Use the extracted text as a starting point for your prompt.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CameraInputPage;
