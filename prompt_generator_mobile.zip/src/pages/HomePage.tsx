import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import TemplateCard from '../components/TemplateCard';
import questionnaireTemplates from '../data/questionnaireTemplates';

const HomePage: React.FC = () => {
  const { setInitialText, setActiveTemplate } = useAppContext();
  const [inputText, setInputText] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setInitialText(inputText);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4 neon-text glitch" data-text="PromptForge">
          PromptForge
        </h1>
        <p className="text-xl text-gray-300">
          Transform your ideas into powerful AI prompts
        </p>
      </div>

      <div className="cyber-card grid-background p-6 mb-8">
        <Link to="/camera" className="block w-full">
          <button className="cyber-button w-full flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Use Camera Input
          </button>
        </Link>
      </div>

      <div className="cyber-card grid-background p-6 mb-12">
        <h2 className="text-2xl font-bold mb-4 neon-text-cyan">Start with a description</h2>
        <p className="text-gray-300 mb-6">
          Enter a brief description of what you want to create, and we'll help you build a robust prompt.
        </p>
        
        <form onSubmit={handleSubmit}>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="e.g., I need to create a Python script that analyzes stock market data and predicts trends"
            className="cyber-input w-full h-32 mb-4"
          />
          
          <div className="flex justify-end">
            <Link to="/templates">
              <button 
                type="submit" 
                className="cyber-button"
                onClick={() => setInitialText(inputText)}
              >
                Continue
              </button>
            </Link>
          </div>
        </form>
      </div>

      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6 neon-text">Choose a template</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {questionnaireTemplates.map((template) => (
            <TemplateCard
              key={template.id}
              template={template}
              onClick={() => {
                setActiveTemplate(template);
              }}
            />
          ))}
        </div>
      </div>

      <div className="cyber-card grid-background p-6">
        <h2 className="text-2xl font-bold mb-4 neon-text-cyan">How it works</h2>
        <div className="space-y-4">
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              1
            </div>
            <p className="text-gray-300">
              Use your camera to capture text or enter a description of what you want to create.
            </p>
          </div>
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              2
            </div>
            <p className="text-gray-300">
              Fill out the dynamic questionnaire to provide details about your specific needs.
            </p>
          </div>
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              3
            </div>
            <p className="text-gray-300">
              Get a powerful, tool-specific prompt that you can use with your favorite AI tools.
            </p>
          </div>
          <div className="flex items-start">
            <div className="bg-primary text-background rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
              4
            </div>
            <p className="text-gray-300">
              Save your prompts for future use and refine them as needed, even when offline.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
