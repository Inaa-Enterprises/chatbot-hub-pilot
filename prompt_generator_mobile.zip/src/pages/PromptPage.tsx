import React from 'react';
import { useNavigate } from 'react-router-dom';
import PromptGenerator from '../components/PromptGenerator';
import { useAppContext } from '../context/AppContext';

const PromptPage: React.FC = () => {
  const navigate = useNavigate();
  const { activeTemplate } = useAppContext();
  
  React.useEffect(() => {
    if (!activeTemplate) {
      navigate('/templates');
    }
  }, [activeTemplate, navigate]);
  
  if (!activeTemplate) {
    return null;
  }
  
  const handleSave = () => {
    navigate('/saved-prompts');
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <PromptGenerator onSave={handleSave} />
    </div>
  );
};

export default PromptPage;
