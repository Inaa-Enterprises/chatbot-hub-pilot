import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import DynamicQuestionnaire from '../components/DynamicQuestionnaire';
import { useAppContext } from '../context/AppContext';
import questionnaireTemplates from '../data/questionnaireTemplates';

const QuestionnairePage: React.FC = () => {
  const { templateId } = useParams<{ templateId: string }>();
  const navigate = useNavigate();
  const { setActiveTemplate } = useAppContext();
  
  React.useEffect(() => {
    const template = questionnaireTemplates.find((t) => t.id === templateId);
    if (template) {
      setActiveTemplate(template);
    } else {
      navigate('/templates');
    }
  }, [templateId, setActiveTemplate, navigate]);
  
  const template = questionnaireTemplates.find((t) => t.id === templateId);
  
  if (!template) {
    return null;
  }
  
  const handleComplete = () => {
    navigate('/prompt');
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <DynamicQuestionnaire template={template} onComplete={handleComplete} />
    </div>
  );
};

export default QuestionnairePage;
