import React from 'react';
import { useNavigate } from 'react-router-dom';
import SavedPromptCard from '../components/SavedPromptCard';
import { useAppContext } from '../context/AppContext';

const SavedPromptsPage: React.FC = () => {
  const navigate = useNavigate();
  const { savedPrompts, deleteSavedPrompt } = useAppContext();

  const handleViewPrompt = (promptId: string) => {
    // In a real app, we would navigate to a detailed view of the prompt
    // For now, we'll just show an alert with the prompt content
    const prompt = savedPrompts.find((p) => p.id === promptId);
    if (prompt) {
      alert(prompt.prompt);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 neon-text">Saved Prompts</h1>
      
      {savedPrompts.length === 0 ? (
        <div className="cyber-card grid-background p-6 text-center">
          <p className="text-gray-300 mb-4">You don't have any saved prompts yet.</p>
          <button
            onClick={() => navigate('/templates')}
            className="cyber-button"
          >
            Create a Prompt
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {savedPrompts.map((prompt) => (
            <SavedPromptCard
              key={prompt.id}
              prompt={prompt}
              onSelect={() => handleViewPrompt(prompt.id)}
              onDelete={() => deleteSavedPrompt(prompt.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default SavedPromptsPage;
