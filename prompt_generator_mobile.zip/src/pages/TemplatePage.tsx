import React from 'react';
import { useNavigate } from 'react-router-dom';
import TemplateCard from '../components/TemplateCard';
import { useAppContext } from '../context/AppContext';
import questionnaireTemplates from '../data/questionnaireTemplates';

const TemplatePage: React.FC = () => {
  const navigate = useNavigate();
  const { setActiveTemplate } = useAppContext();

  const handleSelectTemplate = (templateId: string) => {
    const template = questionnaireTemplates.find((t) => t.id === templateId);
    if (template) {
      setActiveTemplate(template);
      navigate(`/questionnaire/${templateId}`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 neon-text">Select a Template</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {questionnaireTemplates.map((template) => (
          <TemplateCard
            key={template.id}
            template={template}
            onClick={() => handleSelectTemplate(template.id)}
          />
        ))}
      </div>
    </div>
  );
};

export default TemplatePage;
