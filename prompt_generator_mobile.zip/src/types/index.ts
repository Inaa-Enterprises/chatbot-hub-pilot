export interface Question {
  id: string;
  type: 'text' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'slider' | 'color';
  label: string;
  placeholder?: string;
  options?: Array<{
    value: string;
    label: string;
  }>;
  required?: boolean;
  min?: number;
  max?: number;
  step?: number;
  defaultValue?: string | number | boolean | string[];
  description?: string;
  category?: string;
}

export interface QuestionnaireTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  questions: Question[];
}

export interface PromptTemplate {
  id: string;
  name: string;
  template: string;
  description: string;
}

export interface SavedPrompt {
  id: string;
  templateId: string;
  name: string;
  prompt: string;
  answers: Record<string, any>;
  createdAt: number;
}
