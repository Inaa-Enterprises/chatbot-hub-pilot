
import React, { useState, useEffect, useRef, FormEvent } from 'react';
import ReactDOM from 'react-dom/client';
import type { GenerateContentResponse } from "@google/genai";

// Custom error types for better error handling
class ApiError extends Error {
  status: number;
  constructor(message: string, status: number = 500) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

class ValidationError extends Error {
  field?: string;
  constructor(message: string, field?: string) {
    super(message);
    this.name = 'ValidationError';
    this.field = field;
  }
}

class NetworkError extends Error {
  retryable: boolean;
  constructor(message: string, retryable: boolean = true) {
    super(message);
    this.name = 'NetworkError';
    this.retryable = retryable;
  }
}

// Utility functions for input validation
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePasswordStrength = (password: string): boolean => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
  return passwordRegex.test(password);
};

const sanitizeInput = (input: string): string => {
  // Basic sanitization: remove HTML tags and trim
  return input.replace(/<[^>]*>?/gm, '').trim();
};

// Utility function for exponential backoff retry
const retryWithExponentialBackoff = async <T,>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  initialDelay: number = 1000
): Promise<T> => {
  let retries = 0;
  while (true) {
    try {
      return await fn();
    } catch (error: any) {
      if (error instanceof NetworkError && !error.retryable) {
        throw error; // Don't retry non-retryable errors
      }

      if (retries >= maxRetries) {
        throw error; // Max retries reached
      }

      const delay = initialDelay * Math.pow(2, retries);
      console.log(`Retrying after ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      retries++;
    }
  }
};

// MONITORING INTEGRATION - REPLACE IN PRODUCTION
// These are placeholder functions that would be replaced with actual monitoring
// implementations in a production environment

// Crash reporting (e.g., Firebase Crashlytics, Sentry)
const reportCrash = (error: Error, context: Record<string, any> = {}): void => {
  // In production, this would send the error to a crash reporting service
  console.error('CRASH REPORT:', error, context);
  // Example implementation:
  // Crashlytics.recordError(error);
  // or
  // Sentry.captureException(error, { extra: context });
};

// Performance tracking (e.g., Firebase Performance, New Relic)
const trackPerformance = (name: string, startTime: number, metadata: Record<string, any> = {}): void => {
  const duration = performance.now() - startTime;
  // In production, this would send performance metrics to a monitoring service
  console.log(`PERFORMANCE: ${name} took ${duration.toFixed(2)}ms`, metadata);
  // Example implementation:
  // FirebasePerformance.trace(name).putAttribute('duration', duration.toString());
  // or
  // NewRelic.recordMetric(`Custom/${name}`, duration);
};

// Structured logging (e.g., Timber, Winston)
const logEvent = (level: 'info' | 'warn' | 'error', message: string, data: Record<string, any> = {}): void => {
  // In production, this would send logs to a logging service
  console[level](`LOG [${level.toUpperCase()}]: ${message}`, data);
  // Example implementation:
  // Logger.log({ level, message, ...data });
  // or
  // Timber.log(level, message, data);
};

// Feature flag checking (e.g., Firebase Remote Config)
const isFeatureEnabled = (featureName: string, defaultValue: boolean = false): boolean => {
  // In production, this would check if a feature is enabled in a feature flag service
  // For now, return the default value
  return defaultValue;
  // Example implementation:
  // return RemoteConfig.getBoolean(featureName, defaultValue);
};

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  isStreaming?: boolean;
}

interface ChatbotPersona {
  id: string;
  name: string;
  icon: string;
  description: string;
  shortTagline: string;
  systemInstruction: string;
  isDefault?: boolean;
}

interface User {
  name: string;
  email: string;
  role: 'admin' | 'user' | 'limited';
}

const CHATBOT_PERSONAS: ChatbotPersona[] = [
  {
    id: 'execubot-assistant',
    name: 'ExecuBot Assistant',
    icon: '🤖',
    description: 'Your versatile AI personal assistant for scheduling, reminders, research, and task management. Efficient and organized.',
    shortTagline: 'Your Personal AI PA',
    systemInstruction: "You are 'ExecuBot Assistant,' a highly efficient and versatile AI personal assistant. Attitude: Professional, proactive, organized, and polite. Nature: Task-oriented, helpful, anticipates needs. Communication: Clear, concise, and actionable. Provides summaries and options. Helps with scheduling, reminders, information retrieval, and light research. Always aims for user productivity.",
    isDefault: true,
  },
  {
    id: 'finance-oracle',
    name: 'Finance Oracle',
    icon: '💰',
    description: 'AI insights for accounting, budgeting, and financial planning. (Information is for educational purposes only).',
    shortTagline: 'Financial Guide',
    systemInstruction: "You are 'Finance Oracle,' an AI assistant providing information on accounting, budgeting, and financial concepts. Attitude: Analytical, informative, cautious. Nature: Provides general knowledge, explains financial terms, and can discuss budgeting strategies. Communication: Precise and clear. IMPORTANT: You must always include the disclaimer: 'The financial information I provide is for educational and general informational purposes only and should not be considered professional financial advice. Always consult with a qualified financial advisor before making any financial decisions.'",
  },
  {
    id: 'legal-eagle-ai',
    name: 'Legal Eagle AI',
    icon: '⚖️',
    description: 'General legal information and document understanding assistance. (Not a substitute for a human lawyer).',
    shortTagline: 'Legal Info AI',
    systemInstruction: "You are 'Legal Eagle AI,' an AI assistant providing general information about legal concepts and can help understand the structure of legal documents. Attitude: Objective, informative, careful. Nature: Explains legal terms and principles in simple language. Communication: Formal and precise. IMPORTANT: You must always include the disclaimer: 'I am an AI assistant and cannot provide legal advice. The information I offer is for general educational purposes only and is not a substitute for consultation with a qualified legal professional. Always seek advice from a licensed attorney for any legal issues.'",
  },
  {
    id: 'health-companion-ai',
    name: 'Health Companion AI',
    icon: '🩺',
    description: 'General health and wellness information. (For informational purposes only, not medical advice).',
    shortTagline: 'Wellness Info',
    systemInstruction: "You are 'Health Companion AI,' an AI assistant providing general health, wellness, and medical information. Attitude: Empathetic, informative, responsible. Nature: Discusses general health topics, explains medical terms, and can provide information on common conditions based on public knowledge. Communication: Clear, supportive, and easy to understand. IMPORTANT: You must always include the disclaimer: 'I am an AI assistant and cannot provide medical advice. The information I share is for general educational purposes only. Always consult with a qualified healthcare professional for any health concerns or before making any decisions related to your health.'",
  },
  {
    id: 'creative-spark-ai',
    name: 'Creative Spark AI',
    icon: '✨',
    description: 'Your AI partner for brainstorming, content creation, and storytelling. Ignites imagination.',
    shortTagline: 'Idea Generator',
    systemInstruction: "You are 'Creative Spark AI,' an AI assistant designed to help with brainstorming, content creation, and storytelling. Attitude: Imaginative, enthusiastic, inspiring. Nature: Generates ideas, helps write outlines, suggests creative angles, and can assist with various forms of writing. Communication: Engaging and playful, can adopt different tones. Encourages creativity.",
  },
  {
    id: 'market-maven-ai',
    name: 'Market Maven AI',
    icon: '📈', 
    description: 'Insights on stock market trends and cryptocurrency information. (Educational, not financial advice).',
    shortTagline: 'Market Insights',
    systemInstruction: "You are 'Market Maven AI,' an AI assistant providing information about stock market trends, financial markets, and cryptocurrencies. Attitude: Analytical, data-aware, cautious. Nature: Discusses market concepts, historical trends, and explains crypto terms. Communication: Informative and objective. IMPORTANT: You must always include the disclaimer: 'I am an AI and cannot provide financial or investment advice. Information on markets, stocks, or cryptocurrencies is for educational and general informational purposes only. Investing involves risk, and you should always consult with a qualified financial advisor.'",
  },
  {
    id: 'pixel-perfect-ai',
    name: 'Pixel Perfect AI',
    icon: '🎨', 
    description: 'AI assistant for web and app design principles, UX tips, and basic coding concepts.',
    shortTagline: 'Design & UX Guide',
    systemInstruction: "You are 'Pixel Perfect AI,' an AI assistant focused on web and app design principles, user experience (UX) best practices, and basic coding concepts. Attitude: Design-savvy, user-focused, helpful. Nature: Explains design theory, offers UX tips, can provide simple code examples or pseudocode. Communication: Clear, visual (descriptively), and practical.",
  },
  {
    id: 'prompt-prodigy',
    name: 'Prompt Prodigy',
    icon: '💡', 
    description: 'Master the art of AI communication. Helps craft effective prompts for LLMs.',
    shortTagline: 'Prompt Engineer',
    systemInstruction: "You are 'Prompt Prodigy,' an AI assistant specializing in helping users craft effective prompts for Large Language Models (LLMs). Attitude: Insightful, instructive, meta-aware. Nature: Explains prompt engineering techniques, helps refine user prompts, and suggests ways to get better AI responses. Communication: Clear, concise, and focused on prompt structure and strategy.",
  },
  {
    id: 'cyber-guardian-ai',
    name: 'Cyber Guardian AI',
    icon: '🛡️',
    description: 'Educational insights into cybersecurity and ethical hacking concepts. (For learning purposes only).',
    shortTagline: 'Security Educator',
    systemInstruction: "You are 'Cyber Guardian AI,' an AI assistant for educational purposes, focused on cybersecurity awareness and ethical hacking concepts. Attitude: Vigilant, informative, ethical. Nature: Explains cybersecurity threats, defensive measures, and ethical hacking principles. Communication: Clear and direct. IMPORTANT: You must strictly state: 'My purpose is purely educational. I cannot provide tools, specific instructions, or assistance for any hacking activities, even ethical ones. My goal is to promote understanding of cybersecurity concepts to help individuals protect themselves. For any real-world security testing or concerns, consult with certified cybersecurity professionals.' You will not generate malicious code or guide on exploiting vulnerabilities.",
  },
  {
    id: 'vision-weaver-ai',
    name: 'Vision Weaver AI',
    icon: '🖼️', 
    description: 'Helps conceptualize and describe detailed scenes for generative image and video AI prompts.',
    shortTagline: 'Visual Prompter',
    systemInstruction: "You are 'Vision Weaver AI,' an AI assistant that helps users conceptualize and create rich, detailed textual prompts for generative image and video AI models. Attitude: Imaginative, descriptive, artistic. Nature: Helps users break down their ideas into visual components, suggests artistic styles, camera angles, lighting, and specific details to include in prompts for other AI tools. Communication: Vivid and evocative. IMPORTANT: You do not generate images or videos yourself, but you are an expert in crafting the perfect text prompts to feed into other generative AI systems.",
  },
  {
    id: 'professor-synapse',
    name: 'Professor Synapse',
    icon: '👩‍🏫',
    description: 'Your knowledgeable AI tutor for explaining concepts across various subjects. Breaks down complex topics.',
    shortTagline: 'AI Tutor',
    systemInstruction: "You are 'Professor Synapse,' an AI educator. Attitude: Patient, encouraging, knowledgeable. Nature: Explains concepts clearly, provides examples, can answer questions on a wide range of academic subjects. Communication: Structured and easy to follow. Tailors explanations to the user's level of understanding if indicated. Promotes learning and critical thinking.",
  },
  {
    id: 'dr-anya-sharma',
    name: 'Dr. Anya Sharma',
    icon: '👨‍⚕️',
    description: 'Provides general health and medical information. (Not a substitute for professional medical advice).',
    shortTagline: 'Medical Info AI',
    systemInstruction: "You are 'Dr. Anya Sharma,' an AI persona providing general health and medical information. Attitude: Empathetic, informative, responsible, professional. Nature: Discusses general health topics, explains medical terms, and can provide information on common conditions based on publicly available, reputable medical knowledge. Communication: Clear, supportive, and easy to understand. IMPORTANT: You must always include the disclaimer: 'I am an AI persona and cannot provide medical advice, diagnosis, or treatment. The information I share is for general educational purposes only. Always consult with a qualified healthcare professional for any health concerns, medical conditions, or before making any decisions related to your health or treatment.' Do not attempt to diagnose or prescribe.",
  },
  {
    id: 'echo-buddy',
    name: 'Echo - Your AI Buddy',
    icon: '🫂',
    description: 'A friendly AI companion for casual conversation, sharing thoughts, or just chilling out.',
    shortTagline: 'Friendly Pal',
    systemInstruction: "You are 'Echo,' an AI buddy. Attitude: Friendly, empathetic, supportive, and a good listener. Nature: Engaging in casual conversation, offering encouragement, sharing jokes or interesting facts. You are not a therapist but a supportive friend. Communication: Relaxed, informal, and warm. You adapt to the user's mood and try to be a positive presence.",
  },
  {
    id: 'viral-vibe-creator',
    name: 'Viral Vibe',
    icon: '📱',
    description: 'Your AI assistant for brainstorming social media content, captions, and hashtag strategies.',
    shortTagline: 'Social Media Spark',
    systemInstruction: "You are 'Viral Vibe,' an AI assistant specializing in social media content creation. Attitude: Trendy, creative, enthusiastic. Nature: Generates ideas for posts, reels, stories across platforms like Instagram, TikTok, Twitter, Facebook. Helps craft engaging captions, suggests relevant hashtags, and can discuss current social media trends. Communication: Snappy, modern, and platform-aware. Can help with calls to action and engagement strategies.",
  },
  {
    id: 'deepthink-nerd',
    name: 'DeepThink',
    icon: '🤓',
    description: 'An AI that loves to dive deep into niche topics, facts, and technical details. Highly enthusiastic.',
    shortTagline: 'Niche Expert',
    systemInstruction: "You are 'DeepThink,' an AI with a 'nerdy' and enthusiastic personality. Attitude: Passionate about details, loves learning, eager to share in-depth knowledge. Nature: Focuses on specific, often niche, topics provided by the user. Enjoys detailed explanations, trivia, and exploring complexities. Communication: Enthusiastic, detailed, can use technical terms (and explain them if asked). Avoids generalizations and prefers specifics.",
  },
  {
    id: 'chef-remy-ai',
    name: 'Chef Remy AI',
    icon: '🧑‍🍳',
    description: 'Your AI culinary assistant for recipes, cooking tips, meal planning, and ingredient substitutions.',
    shortTagline: 'Kitchen Helper',
    systemInstruction: "You are 'Chef Remy AI,' an AI culinary assistant. Attitude: Passionate about food, helpful, creative. Nature: Provides recipes, cooking techniques, meal planning ideas, tips for ingredient substitutions, and information about cuisines. Communication: Clear, encouraging, and descriptive (especially about flavors and textures). Can adjust recipes for dietary needs if specified (e.g., vegetarian, gluten-free) with general suggestions.",
  },
  {
    id: 'archive-oracle-historian',
    name: 'Archive Oracle',
    icon: '🏛️', 
    description: 'An AI historian providing insights into historical events, figures, and eras.',
    shortTagline: 'History Expert',
    systemInstruction: "You are 'Archive Oracle,' an AI historian. Attitude: Objective, analytical, narrative. Nature: Discusses historical events, figures, periods, and cultural developments. Can provide timelines, contextual information, and different perspectives on historical interpretations (based on common scholarly understanding). Communication: Informative, engaging, tells a story when appropriate. Cites general understanding rather than specific undiscoverable sources.",
  },
  {
    id: 'imam-noor',
    name: 'Imam Noor',
    icon: '🕌',
    description: 'Provides general educational information about Islamic theology, practices, and history from a scholarly perspective.',
    shortTagline: 'Islamic Studies AI',
    systemInstruction: "You are 'Imam Noor,' an AI assistant designed to provide general educational information about Islamic theology, history, ethics, and practices from a scholarly and neutral perspective. Attitude: Respectful, informative, calm, and objective. Nature: Explains concepts, historical events, and common practices based on widely accepted scholarly sources within Islamic studies. Communication: Clear, concise, and neutral. IMPORTANT: You must always include the disclaimers: 'I am an AI assistant providing general educational information on Islamic topics. I cannot issue religious edicts (fatwas), provide religious counseling, or offer interpretations specific to individual circumstances. My knowledge is based on general scholarly texts and information. For personal religious guidance or specific rulings, please consult a qualified religious scholar or authority in your community.' Avoid taking sides in sectarian debates; present information neutrally.",
  },
  {
    id: 'the-motivator-ai',
    name: 'The Motivator',
    icon: '🌟',
    description: 'Your AI coach for positive affirmations, encouragement, and building a growth mindset.',
    shortTagline: 'Inspiration AI',
    systemInstruction: "You are 'The Motivator,' an AI life coach focused on encouragement and positive thinking. Attitude: Uplifting, positive, supportive, empathetic. Nature: Provides motivational quotes, affirmations, helps users reflect on their strengths, and offers general strategies for building a growth mindset and overcoming common self-doubts. Communication: Encouraging and hopeful. IMPORTANT: You must always state: 'I am an AI assistant and not a therapist or professional counselor. For mental health concerns, please consult a qualified professional.'",
  },
  {
    id: 'code-weaver',
    name: 'Code Weaver',
    icon: '💻', 
    description: 'AI expert for debugging code, explaining programming concepts, and discussing algorithms.',
    shortTagline: 'Coding Expert',
    systemInstruction: "You are 'Code Weaver,' an AI programming assistant. Attitude: Logical, precise, helpful. Nature: Helps debug code snippets (in various languages if specified), explains programming concepts, discusses algorithms and data structures, and can offer solutions to coding problems. Communication: Clear, technically accurate. Can provide code examples. Assumes user has some programming knowledge but can explain basics if asked.",
  },
  {
    id: 'glam-guide-ai',
    name: 'Glam Guide',
    icon: '💅',
    description: 'AI assistant for makeup tips, skincare routines, and general beauty advice.',
    shortTagline: 'Beauty AI',
    systemInstruction: "You are 'Glam Guide,' an AI beauty assistant. Attitude: Trendy, helpful, positive. Nature: Offers makeup tips and tutorials (descriptive), skincare routine suggestions (general advice), and discusses beauty trends. Communication: Upbeat and friendly. IMPORTANT: You must always include the disclaimer: 'I provide general beauty and skincare tips for informational purposes. I am not a dermatologist or medical professional. For specific skin conditions or health concerns, please consult a doctor or dermatologist.'",
  },
  {
    id: 'guardian-kai-self-defense',
    name: 'Guardian Kai',
    icon: '🥋',
    description: 'AI tutor for understanding self-defense principles, situational awareness, and de-escalation techniques.',
    shortTagline: 'Defense Concepts',
    systemInstruction: "You are 'Guardian Kai,' an AI tutor for self-defense concepts. Attitude: Calm, assertive, informative. Nature: Explains principles of situational awareness, de-escalation techniques, and general concepts behind various self-defense philosophies. Focuses on safety and prevention. Communication: Clear and direct. IMPORTANT: You must always include the disclaimer: 'I am an AI assistant providing educational information on self-defense concepts. I cannot provide physical training or instruction. This information is not a substitute for hands-on training with a qualified self-defense instructor. Always prioritize your safety and avoid confrontation if possible.' Do not describe specific physical moves in a way that implies it's training.",
  },
  {
    id: 'mindease-ai',
    name: 'MindEase AI',
    icon: '🧠', 
    description: 'AI for discussing general psychological concepts, stress management techniques, and promoting mental wellness.',
    shortTagline: 'Mental Wellness AI',
    systemInstruction: "You are 'MindEase AI,' an AI assistant focused on general psychological concepts and mental wellness. Attitude: Empathetic, understanding, informative, calm. Nature: Discusses stress management techniques, mindfulness, common psychological concepts (e.g., cognitive biases, emotional intelligence), and promotes mental well-being. Communication: Gentle, supportive, and clear. IMPORTANT: You must always include the disclaimers: 'I am an AI assistant and not a therapist, counselor, or medical professional. I cannot provide diagnosis, treatment, or therapy. The information I share is for general educational and informational purposes only. If you are experiencing mental health difficulties, please consult with a qualified mental health professional or a doctor. If you are in crisis, please contact a crisis hotline or emergency services immediately.'",
  },
  {
    id: 'strategos-business-analyst',
    name: 'Strategos',
    icon: '📊', 
    description: 'AI business analyst for discussing strategy, market analysis, process improvement, and data interpretation.',
    shortTagline: 'Business Strategist',
    systemInstruction: "You are 'Strategos,' an AI business analyst. Attitude: Analytical, strategic, objective, data-driven. Nature: Discusses business strategy concepts, market analysis frameworks (e.g., SWOT, Porter's Five Forces), process improvement ideas, and helps interpret general business data or trends. Communication: Professional, clear, and concise. Can explore hypothetical business scenarios. IMPORTANT: You must always include the disclaimer: 'I am an AI assistant and cannot provide financial or business advice. The information and analysis I provide are for educational and discussion purposes only. Always consult with qualified business professionals and conduct thorough due diligence before making any business decisions.'",
  },
  {
    id: 'music-maestro',
    name: 'Music Maestro',
    icon: '🎵',
    description: 'Your AI guide to music theory, history, instruments, and genres. Explore the world of sound!',
    shortTagline: 'Music Educator',
    systemInstruction: "You are 'Music Maestro,' an AI assistant dedicated to music education. Attitude: Passionate, articulate, encouraging. Nature: Explains music theory (scales, chords, rhythm), discusses music history and genres, describes various instruments (their sounds and roles), and can analyze song structures conceptually. Communication: Clear, engaging, and inspiring. IMPORTANT: You must always state: 'I am an AI and cannot listen to, generate, or identify specific pieces of music by sound. My knowledge is based on textual information about music. For practical music lessons or audio-related tasks, please use specialized tools or consult human instructors.'",
  },
  {
    id: 'palette-prodigy',
    name: 'Palette Prodigy',
    icon: '🎨', 
    description: 'Explore art history, art theory, techniques, and famous artists with this AI art educator.',
    shortTagline: 'Art Concepts AI',
    systemInstruction: "You are 'Palette Prodigy,' an AI assistant for art education. Attitude: Appreciative, insightful, descriptive. Nature: Discusses art history, art movements, famous artists and their works, explains artistic techniques (e.g., perspective, composition, color theory), and analyzes visual art conceptually. Communication: Vivid, respectful of art, and educational. IMPORTANT: You must always state: 'I am an AI and cannot create or critique visual art subjectively. My purpose is to provide educational information about art. For creating art or specific critiques, please refer to art tools or consult with art professionals.'",
  }
];

type AuthView = 'login' | 'register';
type TabId = 'chat' | 'upload' | 'creator' | 'history' | 'admin';

type Tab = {
  id: TabId;
  label: string;
  icon: string;
  disabled?: boolean;
  adminOnly?: boolean;
};

const INITIAL_TABS: Tab[] = [
  { id: 'chat', label: 'Chat', icon: '💬' }, 
  { id: 'upload', label: 'Upload', icon: '📤' },
  { id: 'creator', label: 'Creator', icon: '🛠️' },
  { id: 'history', label: 'History', icon: '📜', disabled: true },
  { id: 'admin', label: 'Admin', icon: '⚙️', adminOnly: true },
];

const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const recognition = SpeechRecognition ? new SpeechRecognition() : null;

if (recognition) {
  recognition.continuous = false;
  recognition.lang = 'en-US';
  recognition.interimResults = true;
}

const API_BASE_URL = process.env.VITE_API_BASE_URL || '/api'; 

const AppLogo: React.FC = () => (
  <svg viewBox="0 0 320 100" xmlns="http://www.w3.org/2000/svg" className="header-logo-svg" aria-label="Synapse-OD Logo">
    <defs>
      <linearGradient id="logoNeonBorderGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#00F5FF" /> {/* Cyan */}
        <stop offset="100%" stopColor="#BF00FF" /> {/* Magenta */}
      </linearGradient>
      <filter id="logoNeonGlowFilter" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="3.5" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
      <pattern id="circuitPattern" patternUnits="userSpaceOnUse" width="15" height="15" patternTransform="scale(1)">
        <path d="M0 2h15 M0 7h15 M0 12h15 M2 0v15 M7 0v15 M12 0v15" stroke="rgba(100,100,100,0.15)" strokeWidth="0.5"/>
      </pattern>
    </defs>
    <rect x="3" y="3" width="314" height="94" rx="10" ry="10"
          stroke="url(#logoNeonBorderGradient)" strokeWidth="5" fill="none" filter="url(#logoNeonGlowFilter)" />
    <rect x="10" y="10" width="300" height="80" rx="6" ry="6" fill="#1E1E1E" />
    <rect x="10" y="10" width="300" height="80" rx="6" ry="6" fill="url(#circuitPattern)" />
    <text x="160" y="55" fontFamily="Orbitron, sans-serif" fontSize="28" textAnchor="middle" dominantBaseline="central" letterSpacing="1.5" fontWeight="bold">
      <tspan fill="#FFFFFF">SYNAPSE</tspan>
      <tspan fill="#00F5FF" dx="2">-</tspan>
      <tspan dominantBaseline="central" fill="#00F5FF">O</tspan>
      <tspan
        fontSize="16"
        dy="-5"
        dx="-24"
        fill="#FFFFFF"
        fontWeight="bold"
      >
        Ai
      </tspan>
    </text>
  </svg>
);

const ChatApp: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authView, setAuthView] = useState<AuthView>('login');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authMessage, setAuthMessage] = useState<string | null>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const defaultPersona = CHATBOT_PERSONAS.find(p => p.isDefault) || CHATBOT_PERSONAS[0];
  const [currentPersonaId, setCurrentPersonaId] = useState<string>(defaultPersona.id);
  const currentActivePersona = CHATBOT_PERSONAS.find(p => p.id === currentPersonaId) || defaultPersona;

  const TABS = INITIAL_TABS.filter(tab => !tab.adminOnly || (currentUser?.role === 'admin'));
  const [activeTab, setActiveTab] = useState<TabId>(TABS[0].id);

  const [isNexusCoreVisible, setIsNexusCoreVisible] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [processingStatus, setProcessingStatus] = useState<string | null>(null);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isTTSEnabled, setIsTTSEnabled] = useState<boolean>(false);
  const [sttError, setSttError] = useState<string | null>(null);
  const [childBotName, setChildBotName] = useState<string>('');
  const [childBotIcon, setChildBotIcon] = useState<string>('🤖');
  const [selectedPrimaryRoleId, setSelectedPrimaryRoleId] = useState<string>(CHATBOT_PERSONAS[0].id);
  const [focusKeywordsInput, setFocusKeywordsInput] = useState<string>('');
  const [additionalInstructions, setAdditionalInstructions] = useState<string>('');
  const [generatedChildInstructionPreview, setGeneratedChildInstructionPreview] = useState<string>('');
  const [creationType, setCreationType] = useState<'template' | 'custom'>('template');
  const [customSystemInstruction, setCustomSystemInstruction] = useState<string>('');
  const [showUserDropdown, setShowUserDropdown] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const userDropdownRef = useRef<HTMLDivElement>(null);
  const [animationKey, setAnimationKey] = useState(0);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);
  useEffect(() => { setAnimationKey(prevKey => prevKey + 1); }, [activeTab, currentActivePersona.id, isNexusCoreVisible, isAuthenticated]);

  useEffect(() => {
    if (animationKey > 0) {
      document.body.classList.add('circuit-flow-active');
      const timer = setTimeout(() => { document.body.classList.remove('circuit-flow-active'); }, 1500);
      return () => { clearTimeout(timer); document.body.classList.remove('circuit-flow-active'); };
    }
  }, [animationKey]);

  useEffect(() => {
    document.body.classList.add('circuit-flow-active');
    const timer = setTimeout(() => { document.body.classList.remove('circuit-flow-active'); }, 1500);
    return () => { clearTimeout(timer); document.body.classList.remove('circuit-flow-active'); };
  }, []);

  useEffect(() => {
    if (!recognition) { setSttError("Speech recognition not supported."); return; }
    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      let interim = '', final = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) final += event.results[i][0].transcript;
        else interim += event.results[i][0].transcript;
      }
      setInput(final || interim);
      if (final && inputRef.current) inputRef.current.focus();
    };
    recognition.onerror = (event: any) => { setIsListening(false); setSttError(`STT Error: ${event.error}`); };
    recognition.onend = () => setIsListening(false);
    return () => { if (recognition) recognition.abort(); };
  }, []);

  useEffect(() => {
    const lastMsg = messages[messages.length - 1];
    if (isTTSEnabled && lastMsg && lastMsg.sender === 'ai' && !lastMsg.isStreaming && lastMsg.text) speak(lastMsg.text);
    return () => speechSynthesis.cancel();
  }, [messages, isTTSEnabled]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setShowUserDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [userDropdownRef]);

  const speak = (text: string) => { speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(text)); };
  const toggleTTS = () => { setIsTTSEnabled(prev => !prev); if (isTTSEnabled) speechSynthesis.cancel(); };

  const handleListen = () => {
    if (!recognition) return;
    if (isListening) recognition.stop();
    else { try { recognition.start(); setSttError(null); } catch (e) { setSttError("STT start failed."); } }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    setMessages([]);
    setError(null);
    setAuthView('login');
    setActiveTab(INITIAL_TABS[0].id); // Reset to default tab
    setShowUserDropdown(false);
  };

  const handleAuthSuccess = (user: User) => {
    setIsAuthenticated(true);
    setCurrentUser(user);
    setAuthError(null);
    setAuthMessage(null);
    setActiveTab(INITIAL_TABS[0].id); // Reset to default tab after login
    setMessages([]); // Clear messages from previous session or guest
    if (inputRef.current) inputRef.current.focus();
  };

  const handleNexusToggle = () => {
    setActiveTab('chat');
    setIsNexusCoreVisible(prev => !prev);
  };

  const handlePersonaSelect = (personaId: string) => {
    speechSynthesis.cancel();
    setCurrentPersonaId(personaId);
    setMessages([]);
    setActiveTab('chat');
    setIsNexusCoreVisible(false);
    setError(null);
    setIsLoading(false);
    setInput('');
    if(inputRef.current) inputRef.current.focus();
  };

  const streamAIResponseFromBackend = async (prompt: string, persona: ChatbotPersona): Promise<ReadableStream<Uint8Array>> => {
    // Sanitize input
    const sanitizedPrompt = sanitizeInput(prompt);

    // Function to make the API call with proper error handling
    const makeApiCall = async (): Promise<ReadableStream<Uint8Array>> => {
      try {
        // MOCK DATA - REPLACE IN PRODUCTION
        // In production, this would be a secure API call to a backend service
        // that handles the Gemini API key and other sensitive information
        const response = await fetch(`${API_BASE_URL}/chat`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            // In production, add authentication headers here
            // 'Authorization': `Bearer ${authToken}`,
          },
          body: JSON.stringify({ 
            prompt: sanitizedPrompt, 
            personaId: persona.id, 
            systemInstruction: persona.systemInstruction 
          }),
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ message: 'Unknown server error.' }));
          const errorMessage = errorData.message || `Server error: ${response.status}`;

          // Determine if error is retryable based on status code
          const isRetryable = [408, 429, 500, 502, 503, 504].includes(response.status);

          if (isRetryable) {
            throw new NetworkError(errorMessage, true);
          } else {
            throw new ApiError(errorMessage, response.status);
          }
        }

        if (!response.body) {
          throw new ApiError('Response body is null', 500);
        }

        return response.body;
      } catch (error) {
        // Rethrow NetworkError as is (for retry logic)
        if (error instanceof NetworkError) {
          throw error;
        }

        // Convert other errors to appropriate types
        if (error instanceof ApiError) {
          throw error;
        }

        // For any other error, wrap it in a NetworkError
        throw new NetworkError(`Failed to connect to AI service: ${error instanceof Error ? error.message : String(error)}`);
      }
    };

    // Use the retry utility to handle transient failures with exponential backoff
    return await retryWithExponentialBackoff(makeApiCall);
  };

  const handleSendMessage = async (e?: FormEvent) => {
    if (e) e.preventDefault();

    // Validate input
    const trimmedInput = input.trim();
    if (!trimmedInput || isLoading || isNexusCoreVisible) return;

    // Create user message
    const userMessage: Message = { id: Date.now().toString(), sender: 'user', text: trimmedInput };
    setMessages(prev => [...prev, userMessage]);

    // Clear input and prepare for AI response
    setInput('');
    setIsLoading(true);
    setError(null);

    // Create placeholder for AI response
    const aiMessageId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: aiMessageId, sender: 'ai', text: '', isStreaming: true }]);

    try {
      // Start performance tracking
      const startTime = performance.now();

      // Log the chat request
      logEvent('info', 'Chat request initiated', {
        personaId: currentActivePersona.id,
        messageLength: trimmedInput.length
      });

      // Get AI response with retry logic (implemented in streamAIResponseFromBackend)
      const stream = await streamAIResponseFromBackend(trimmedInput, currentActivePersona);

      // Process the stream
      const reader = stream.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      // Read and process chunks as they arrive
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Decode the chunk and update the message
        const chunk = decoder.decode(value, { stream: true });
        fullText += chunk;

        // Update the message with the new text
        setMessages(prev => prev.map(msg => 
          msg.id === aiMessageId ? { ...msg, text: fullText, isStreaming: true } : msg
        ));
      }

      // Clean up the response (remove JSON code blocks) and mark as complete
      const cleanedText = fullText.replace(/```json\s*([\s\S]*?)\s*```/, '$1').trim();
      setMessages(prev => prev.map(msg => 
        msg.id === aiMessageId ? { ...msg, text: cleanedText, isStreaming: false } : msg
      ));

      // Track performance of the entire operation
      trackPerformance('chat_message_complete', startTime, {
        personaId: currentActivePersona.id,
        responseLength: cleanedText.length
      });

      // MOCK DATA - REPLACE IN PRODUCTION
      // In production, log successful interactions for analytics
      logEvent('info', 'AI response completed', {
        personaId: currentActivePersona.id,
        responseLength: cleanedText.length,
        processingTime: performance.now() - startTime
      });

    } catch (err: any) {
      // Handle different types of errors
      let errorMessage = 'Failed to get AI response.';
      let errorType = 'unknown';

      if (err instanceof ApiError) {
        errorMessage = `API Error (${err.status}): ${err.message}`;
        errorType = 'api';
      } else if (err instanceof NetworkError) {
        errorMessage = `Network Error: ${err.message}`;
        errorType = 'network';
        if (err.retryable) {
          errorMessage += " (Retry attempts exhausted)";
        }
      } else if (err instanceof ValidationError) {
        errorMessage = `Validation Error: ${err.message}`;
        errorType = 'validation';
      } else if (err instanceof Error) {
        errorMessage = err.message;
        errorType = 'general';
      }

      // Update the AI message with the error
      const errorText = `// BACKEND ERROR // ${errorMessage}`;
      setMessages(prev => prev.map(msg => 
        msg.id === aiMessageId ? { ...msg, text: errorText, isStreaming: false, sender: 'ai' } : msg
      ));

      // Set the error state for display
      setError(errorText);

      // Log the error
      logEvent('error', `Chat error (${errorType})`, {
        personaId: currentActivePersona.id,
        errorMessage,
        errorType
      });

      // Report crash for non-network errors (which are expected occasionally)
      if (errorType !== 'network') {
        reportCrash(err instanceof Error ? err : new Error(errorMessage), {
          personaId: currentActivePersona.id,
          errorType,
          userMessage: trimmedInput.substring(0, 100) + (trimmedInput.length > 100 ? '...' : '')
        });
      }

    } finally {
      // Clean up regardless of success or failure
      setIsLoading(false);
      if (inputRef.current) inputRef.current.focus();
    }
  };

  // Validate file type and size
  const validateFile = (file: File): { valid: boolean; message?: string } => {
    // Define allowed file types and max size (10MB)
    const allowedTypes = ['application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'audio/mpeg', 'audio/wav', 'video/mp4'];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (!allowedTypes.includes(file.type)) {
      return { 
        valid: false, 
        message: `Invalid file type. Allowed types: PDF, TXT, DOC, DOCX, MP3, WAV, MP4. Got: ${file.type}` 
      };
    }

    if (file.size > maxSize) {
      return { 
        valid: false, 
        message: `File too large. Maximum size: 10MB. Got: ${(file.size / (1024 * 1024)).toFixed(2)}MB` 
      };
    }

    return { valid: true };
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setProcessingStatus(null);

    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];

      // Validate file
      const validation = validateFile(file);
      if (!validation.valid) {
        setError(validation.message);
        return;
      }

      setSelectedFile(file);
    }
  };

  const handleProcessFile = async () => {
    if (!selectedFile) {
      setError("Please select a file to upload.");
      return;
    }

    setProcessingStatus(`Sending ${selectedFile.name}...`);
    setError(null);

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      // MOCK DATA - REPLACE IN PRODUCTION
      // In production, this would be a secure API call to a backend service
      // that handles file uploads and processing
      const uploadFile = async (): Promise<any> => {
        const response = await fetch(`${API_BASE_URL}/uploadFile`, { 
          method: 'POST', 
          body: formData,
          // In production, add authentication headers here
          // headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({
            message: `Server error: ${response.status}`
          }));

          // Determine if error is retryable based on status code
          const isRetryable = [408, 429, 500, 502, 503, 504].includes(response.status);

          if (isRetryable) {
            throw new NetworkError(errorData.message, true);
          } else {
            throw new ApiError(errorData.message, response.status);
          }
        }

        return await response.json();
      };

      // Use retry logic for file uploads
      const result = await retryWithExponentialBackoff(uploadFile);

      // Handle successful upload
      setProcessingStatus(result.message || `File "${selectedFile.name}" processed successfully.`);
      setSelectedFile(null);

      // Clear status message after a delay
      setTimeout(() => setProcessingStatus(null), 4000);

    } catch (err: any) {
      // Handle different types of errors
      let errorMessage = 'File processing error.';

      if (err instanceof ApiError) {
        errorMessage = `API Error (${err.status}): ${err.message}`;
      } else if (err instanceof NetworkError) {
        errorMessage = `Network Error: ${err.message}`;
        if (err.retryable) {
          errorMessage += " (Retry attempts exhausted)";
        }
      } else if (err instanceof Error) {
        errorMessage = err.message;
      }

      setError(errorMessage);
      setProcessingStatus(null);
      console.error("File upload error:", err);
    }
  };

  // Validate YouTube URL
  const validateYoutubeUrl = (url: string): { valid: boolean; message?: string } => {
    // Basic YouTube URL validation
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/;

    if (!url.trim()) {
      return { valid: false, message: "URL is required." };
    }

    if (!youtubeRegex.test(url)) {
      return { 
        valid: false, 
        message: "Invalid YouTube URL. Please enter a valid YouTube video URL." 
      };
    }

    return { valid: true };
  };

  const handleProcessUrl = async () => {
    // Validate URL
    const validation = validateYoutubeUrl(youtubeUrl);
    if (!validation.valid) {
      setError(validation.message);
      return;
    }

    // Sanitize input
    const sanitizedUrl = sanitizeInput(youtubeUrl);

    setProcessingStatus(`Sending URL...`);
    setError(null);

    try {
      // MOCK DATA - REPLACE IN PRODUCTION
      // In production, this would be a secure API call to a backend service
      // that handles URL processing
      const processUrl = async (): Promise<any> => {
        const response = await fetch(`${API_BASE_URL}/uploadUrl`, { 
          method: 'POST', 
          headers: { 
            'Content-Type': 'application/json',
            // In production, add authentication headers here
            // 'Authorization': `Bearer ${authToken}`
          }, 
          body: JSON.stringify({ url: sanitizedUrl })
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({
            message: `Server error: ${response.status}`
          }));

          // Determine if error is retryable based on status code
          const isRetryable = [408, 429, 500, 502, 503, 504].includes(response.status);

          if (isRetryable) {
            throw new NetworkError(errorData.message, true);
          } else {
            throw new ApiError(errorData.message, response.status);
          }
        }

        return await response.json();
      };

      // Use retry logic for URL processing
      const result = await retryWithExponentialBackoff(processUrl);

      // Handle successful processing
      setProcessingStatus(result.message || `URL processed successfully.`);
      setYoutubeUrl(''); // Clear the input field

      // Clear status message after a delay
      setTimeout(() => setProcessingStatus(null), 4000);

    } catch (err: any) {
      // Handle different types of errors
      let errorMessage = 'URL processing error.';

      if (err instanceof ApiError) {
        errorMessage = `API Error (${err.status}): ${err.message}`;
      } else if (err instanceof NetworkError) {
        errorMessage = `Network Error: ${err.message}`;
        if (err.retryable) {
          errorMessage += " (Retry attempts exhausted)";
        }
      } else if (err instanceof ValidationError) {
        errorMessage = `Validation Error: ${err.message}`;
      } else if (err instanceof Error) {
        errorMessage = err.message;
      }

      setError(errorMessage);
      setProcessingStatus(null);
      console.error("URL processing error:", err);
    }
  };

  const handleGoHome = () => { setActiveTab('chat'); setIsNexusCoreVisible(false); };
  const handleGoBack = () => {
    if (isNexusCoreVisible) setIsNexusCoreVisible(false);
    else if (activeTab !== 'chat') setActiveTab('chat');
  };

  const AuthContainer: React.FC = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleLoginSubmit = (e: FormEvent) => {
      e.preventDefault(); setAuthError(null); setAuthMessage(null);

      try {
        // Input validation with detailed error messages
        if (!email) throw new ValidationError("Email is required.", "email");
        if (!password) throw new ValidationError("Password is required.", "password");

        const sanitizedEmail = sanitizeInput(email);
        if (!validateEmail(sanitizedEmail)) throw new ValidationError("Please enter a valid email address.", "email");

        // In a real app, password validation would happen on registration, not login
        // Here we're just sanitizing the input
        const sanitizedPassword = sanitizeInput(password);

        // MOCK DATA - REPLACE IN PRODUCTION
        // In production, this would be an API call to a backend authentication service
        if (sanitizedEmail === 'admin@example.com' && sanitizedPassword === 'adminpass') {
          handleAuthSuccess({ name: 'Admin User', email: sanitizedEmail, role: 'admin' });
        } else if (sanitizedPassword === 'userpass') { // Generic user
          handleAuthSuccess({ name: 'Demo User', email: sanitizedEmail, role: 'user' });
        } else {
          throw new ValidationError("Invalid credentials (try admin@example.com/adminpass or anyemail/userpass).");
        }
      } catch (error) {
        if (error instanceof ValidationError) {
          setAuthError(error.message);
          console.error(`Validation error: ${error.message}${error.field ? ` (Field: ${error.field})` : ''}`);
        } else {
          setAuthError("An unexpected error occurred. Please try again.");
          console.error("Login error:", error);
        }
      }
    };

    const handleRegisterSubmit = (e: FormEvent) => {
      e.preventDefault(); setAuthError(null); setAuthMessage(null);

      try {
        // Input validation with detailed error messages
        if (!name) throw new ValidationError("Full name is required.", "name");
        if (!email) throw new ValidationError("Email is required.", "email");
        if (!password) throw new ValidationError("Password is required.", "password");
        if (!confirmPassword) throw new ValidationError("Please confirm your password.", "confirmPassword");

        // Sanitize inputs
        const sanitizedName = sanitizeInput(name);
        const sanitizedEmail = sanitizeInput(email);

        // Validate email format
        if (!validateEmail(sanitizedEmail)) {
          throw new ValidationError("Please enter a valid email address.", "email");
        }

        // Validate password strength
        if (!validatePasswordStrength(password)) {
          throw new ValidationError(
            "Password must be at least 8 characters long and include uppercase, lowercase, and numbers.", 
            "password"
          );
        }

        // Check if passwords match
        if (password !== confirmPassword) {
          throw new ValidationError("Passwords do not match.", "confirmPassword");
        }

        // MOCK DATA - REPLACE IN PRODUCTION
        // In production, this would be an API call to a backend registration service
        // that would create a new user account and return the user data
        console.log("Registration data ready for backend submission:", {
          name: sanitizedName,
          email: sanitizedEmail,
          // Password would be securely hashed on the backend
        });

        handleAuthSuccess({ name: sanitizedName, email: sanitizedEmail, role: 'user' });
      } catch (error) {
        if (error instanceof ValidationError) {
          setAuthError(error.message);
          console.error(`Validation error: ${error.message}${error.field ? ` (Field: ${error.field})` : ''}`);
        } else {
          setAuthError("An unexpected error occurred. Please try again.");
          console.error("Registration error:", error);
        }
      }
    };

    const handleSocialLogin = (provider: string) => {
        setAuthError(null); setAuthMessage(`Simulating login with ${provider}...`);
        setTimeout(() => {
            handleAuthSuccess({ name: `${provider} User`, email: `${provider.toLowerCase()}@example.com`, role: 'user' });
        }, 1500);
    };

    return (
      <div className="auth-container">
        <div className="auth-logo-header">
           <AppLogo />
        </div>
        {authView === 'login' ? (
          <form onSubmit={handleLoginSubmit} className="auth-form">
            <h2 className="auth-title">Sign In</h2>
            {authError && <div className="error-message auth-feedback">{authError}</div>}
            {authMessage && <div className="status-message auth-feedback">{authMessage}</div>}
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="user@example.com" required />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" id="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <button type="submit" className="auth-button">Sign In</button>
            <div className="social-login-divider"><span>OR</span></div>
            <div className="social-login-buttons">
                <button type="button" onClick={() => handleSocialLogin('Google')} className="social-button google">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M21.35,11.1H12.18V13.83H18.69C18.36,17.64 15.19,19.27 12.19,19.27C8.36,19.27 5,16.25 5,12C5,7.9 8.2,4.73 12.19,4.73C15.5,4.73 17.96,6.89 17.96,6.89L20.47,4.71C20.47,4.71 16.74,2 12.19,2C6.42,2 2.03,6.8 2.03,12C2.03,17.05 6.16,22 12.19,22C17.6,22 21.54,18.33 21.54,12.25C21.54,11.62 21.48,11.34 21.35,11.1Z"></path></svg>
                    Sign in with Google
                </button>
                <button type="button" onClick={() => handleSocialLogin('Microsoft')} className="social-button microsoft">
                    <svg viewBox="0 0 24 24" fill="currentColor" width="1em" height="1em"><path d="M11.5 2C5.69 2 2 5.69 2 11.5C2 17.31 5.69 22 11.5 22C17.31 22 22 17.31 22 11.5C22 5.69 17.31 2 11.5 2ZM11.16 18.13V11.88H4.88V11.13H11.16V4.88H11.88V11.13H18.13V11.88H11.88V18.13H11.16Z" /></svg>
                    Sign in with Microsoft
                </button>
                 <button type="button" onClick={() => handleSocialLogin('Facebook')} className="social-button facebook">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 2.04C6.48 2.04 2 6.52 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.81C10.44 7.31 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96C18.34 21.21 22 17.06 22 12.06C22 6.52 17.52 2.04 12 2.04Z"></path></svg>
                    Sign in with Facebook
                </button>
            </div>
            <p className="auth-switch">Don't have an account? <button type="button" onClick={() => { setAuthView('register'); setAuthError(null); setAuthMessage(null); }} className="link-button">Create an account</button></p>
            <p className="auth-switch"><button type="button" onClick={() => alert("Forgot password functionality is not implemented in this simulation.")} className="link-button">Forgot password?</button></p>
          </form>
        ) : (
          <form onSubmit={handleRegisterSubmit} className="auth-form">
            <h2 className="auth-title">Create Account</h2>
            {authError && <div className="error-message auth-feedback">{authError}</div>}
            {authMessage && <div className="status-message auth-feedback">{authMessage}</div>}
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} placeholder="Your Name" required />
            </div>
            <div className="form-group">
              <label htmlFor="email-register">Email Address</label>
              <input type="email" id="email-register" value={email} onChange={e => setEmail(e.target.value)} placeholder="user@example.com" required />
            </div>
            <div className="form-group">
              <label htmlFor="password-register">Password</label>
              <input type="password" id="password-register" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <div className="form-group">
              <label htmlFor="confirm-password">Confirm Password</label>
              <input type="password" id="confirm-password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <button type="submit" className="auth-button">Create Account</button>
            <p className="auth-switch">Already have an account? <button type="button" onClick={() => { setAuthView('login'); setAuthError(null); setAuthMessage(null); }} className="link-button">Sign In</button></p>
          </form>
        )}
      </div>
    );
  };


  const NexusCoreSelector: React.FC = () => (
    <div className={`nexus-core-overlay ${isNexusCoreVisible ? 'visible' : ''}`}>
      <h2 className="nexus-core-title">Select AI Assistant</h2>
      <div className="nexus-core-grid">
        {CHATBOT_PERSONAS.map((persona, index) => (
          <div key={persona.id} className={`nexus-persona-card ${currentPersonaId === persona.id ? 'active-nexus-persona' : ''}`}
            onClick={() => handlePersonaSelect(persona.id)}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handlePersonaSelect(persona.id);}}
            tabIndex={0} role="button" aria-pressed={currentPersonaId === persona.id} aria-label={`Select ${persona.name}. ${persona.shortTagline}`}
            style={{ animationDelay: `${index * 0.06}s` }} >
            <span className="nexus-persona-icon" aria-hidden="true">{persona.icon}</span>
            <h3 className="nexus-persona-name">{persona.name}</h3>
            <p className="nexus-persona-tagline">{persona.shortTagline}</p>
          </div>
        ))}
      </div>
    </div>
  );

  const ChildBotCreatorView: React.FC = () => {
    useEffect(() => {
      setChildBotName(''); setChildBotIcon('🤖');
      if (creationType === 'template') setSelectedPrimaryRoleId(CHATBOT_PERSONAS[0].id);
      setFocusKeywordsInput(''); setAdditionalInstructions(''); setCustomSystemInstruction('');
      setGeneratedChildInstructionPreview(''); setProcessingStatus(null); setError(null);
    }, [creationType]);

    useEffect(() => {
      if (creationType === 'custom') { setGeneratedChildInstructionPreview(customSystemInstruction); } 
      else {
        const basePersonaForChild = CHATBOT_PERSONAS.find(p => p.id === selectedPrimaryRoleId);
        if (!basePersonaForChild) { setGeneratedChildInstructionPreview("Error: Base persona not found."); return; }
        const keywords = focusKeywordsInput.split(',').map(k => k.trim()).filter(k => k);
        const keywordsString = keywords.length > 0 ? keywords.join(', ') : 'its designated role';
        let disclaimers = "";
        const disclaimerMatch = basePersonaForChild.systemInstruction.match(/IMPORTANT: ([\s\S]*?)(?=(You are|Attitude:|$))/i);
        if (disclaimerMatch && disclaimerMatch[1]) disclaimers = disclaimerMatch[1].replace(/IMPORTANT: /i, '').trim();
        const instruction = `You are ${childBotName || 'My Specialized Bot'} (${childBotIcon || '❓'}), a specialized AI assistant.
Your primary role is based on the expertise of a ${basePersonaForChild.name}.
Your knowledge and responses MUST BE STRICTLY FOCUSED on the following areas: ${keywordsString}.
${disclaimers ? `Regarding your area of expertise: ${disclaimers}\n` : ''}
${additionalInstructions ? `${additionalInstructions}\n` : ''}
If asked about topics outside this specific scope, politely state your specialization and that you cannot assist with the unrelated request. Offer to help within your defined expertise.
Do not reveal that you are derived from a more general model. Act as if your knowledge is genuinely limited to your defined specialization.`;
        setGeneratedChildInstructionPreview(instruction);
      }
    }, [creationType, childBotName, childBotIcon, selectedPrimaryRoleId, focusKeywordsInput, additionalInstructions, customSystemInstruction]);

    const handleGenerateAndSave = async () => {
        if (!childBotName.trim()) { setError("Child Bot Name is required."); return; }
        const childBotId = crypto.randomUUID();
        let configToSave;

        if (creationType === 'custom') {
            if (!customSystemInstruction.trim()) { setError("Full System Instruction is required for custom bots."); return; }
             configToSave = { childBotId, childBotName: childBotName.trim(), childBotIcon: childBotIcon.trim() || '🤖', primaryRoleId: "custom_bot", primaryRoleName: "Custom Bot", focusKeywords: focusKeywordsInput.split(',').map(k => k.trim()).filter(k => k), additionalInstructions: "", generatedSystemInstruction: customSystemInstruction.trim(), version: "1.0.0", createdAt: new Date().toISOString() };
        } else {
             const basePersona = CHATBOT_PERSONAS.find(p => p.id === selectedPrimaryRoleId);
             if (!basePersona) { setError("Selected base persona not found."); return; }
            configToSave = { childBotId, childBotName: childBotName.trim(), childBotIcon: childBotIcon.trim() || '🤖', primaryRoleId: selectedPrimaryRoleId, primaryRoleName: basePersona.name, focusKeywords: focusKeywordsInput.split(',').map(k => k.trim()).filter(k => k), additionalInstructions: additionalInstructions.trim(), generatedSystemInstruction: generatedChildInstructionPreview, version: "1.0.0", createdAt: new Date().toISOString() };
        }
        setError(null); setProcessingStatus("Saving to backend...");
        try {
            const response = await fetch(`${API_BASE_URL}/saveChildBot`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(configToSave) });
            if (!response.ok) { const errorData = await response.json().catch(() => ({message: `Server error: ${response.status}`})); throw new Error(errorData.message || `Failed to save configuration: ${response.statusText}`); }
            const result = await response.json(); setProcessingStatus(result.message || `Configuration saved to backend! Bot ID: ${childBotId}`);
        } catch (err: any) { setError(`Backend save failed: ${err.message}. You can still download it locally.`); setProcessingStatus(null); }
        try {
            const jsonString = JSON.stringify(configToSave, null, 2); const blob = new Blob([jsonString], { type: "application/json" }); const url = URL.createObjectURL(blob);
            const a = document.createElement("a"); a.href = url; a.download = `${configToSave.childBotName.replace(/\s+/g, '_')}_${childBotId.substring(0,8)}_config.json`; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
            if (processingStatus && processingStatus.includes("Saving to backend...") && !error) setProcessingStatus(`Saved to backend & downloaded locally! Bot ID: ${childBotId}`);
            else setProcessingStatus(`${configToSave.childBotName} config downloaded locally! Bot ID: ${childBotId}`);
            setTimeout(() => setProcessingStatus(null), 6000);
        } catch (downloadError: any) { setError(prev => prev ? `${prev} Also, local download failed: ${downloadError.message}` : `Local download failed: ${downloadError.message}`); }
    };
    const isSaving = processingStatus && processingStatus.toLowerCase().includes("saving");
    return (
      <div className="creator-view" key="creator-view">
        <h2 className="creator-title">Create Specialized Child Bot</h2>
        <div className="form-group full-width">
            <label className="creator-section-label">Creation Type:</label>
            <div className="radio-group">
                <label><input type="radio" value="template" checked={creationType === 'template'} onChange={() => setCreationType('template')} disabled={isSaving} /> From Template</label>
                <label><input type="radio" value="custom" checked={creationType === 'custom'} onChange={() => setCreationType('custom')} disabled={isSaving} /> From Scratch (Custom)</label>
            </div>
        </div>
        {creationType === 'template' && (
          <div className="form-group full-width template-selector-section">
            <label className="creator-section-label">Select Base Persona Template:</label>
            <div className="creator-template-grid">
              {CHATBOT_PERSONAS.map((persona, index) => (
                <div key={persona.id} className={`creator-template-card ${selectedPrimaryRoleId === persona.id ? 'active-template' : ''}`}
                  onClick={() => !isSaving && setSelectedPrimaryRoleId(persona.id)}
                  onKeyDown={(e) => { if (!isSaving && (e.key === 'Enter' || e.key === ' ')) setSelectedPrimaryRoleId(persona.id);}}
                  tabIndex={isSaving ? -1 : 0} role="button" aria-pressed={selectedPrimaryRoleId === persona.id} aria-label={`Select ${persona.name} as template`}
                  style={{ animationDelay: `${index * 0.05}s` }} >
                  <span className="creator-template-icon" aria-hidden="true">{persona.icon}</span>
                  <h4 className="creator-template-name">{persona.name}</h4>
                  <p className="creator-template-tagline">{persona.shortTagline}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="creator-form-grid">
          <div className="form-group"><label htmlFor="childBotName">Child Bot Name:</label><input type="text" id="childBotName" value={childBotName} onChange={e => setChildBotName(e.target.value)} placeholder="e.g., My Poetry Helper" disabled={isSaving}/></div>
          <div className="form-group"><label htmlFor="childBotIcon">Child Bot Icon (Emoji):</label><input type="text" id="childBotIcon" value={childBotIcon} onChange={e => setChildBotIcon(e.target.value)} placeholder="e.g., ✍️" maxLength={2} disabled={isSaving}/></div>
          {creationType === 'template' && ( <>
              <div className="form-group full-width"><label htmlFor="focusKeywordsInput">Focus Area / Specialization Keywords (comma-separated):</label><textarea id="focusKeywordsInput" value={focusKeywordsInput} onChange={e => setFocusKeywordsInput(e.target.value)} placeholder="e.g., sonnets, haikus, free verse" rows={3} disabled={isSaving}/></div>
              <div className="form-group full-width"><label htmlFor="additionalInstructions">Optional: Additional Instructions/Tone:</label><textarea id="additionalInstructions" value={additionalInstructions} onChange={e => setAdditionalInstructions(e.target.value)} placeholder="e.g., Be very encouraging. Use simple language." rows={2} disabled={isSaving}/></div>
          </>)}
          {creationType === 'custom' && ( <>
              <div className="form-group full-width"><label htmlFor="focusKeywordsInputCustom">Core Functionality Keywords (for tagging, comma-separated):</label><textarea id="focusKeywordsInputCustom" value={focusKeywordsInput} onChange={e => setFocusKeywordsInput(e.target.value)} placeholder="e.g., medical diagnosis, legal contract analysis" rows={2} disabled={isSaving}/></div>
              <div className="form-group full-width"><label htmlFor="customSystemInstruction">Full System Instruction:</label><textarea id="customSystemInstruction" value={customSystemInstruction} onChange={e => setCustomSystemInstruction(e.target.value)} placeholder="Enter the complete system instruction for your custom bot..." rows={10} className="custom-instruction-input" disabled={isSaving}/></div>
          </>)}
        </div>
        <div className="form-group full-width"><label className="creator-section-label">Generated System Instruction Preview:</label><textarea className="instruction-preview" value={generatedChildInstructionPreview} readOnly rows={8} /></div>
        <button className="creator-action-button" onClick={handleGenerateAndSave} disabled={!childBotName.trim() || (creationType === 'template' && !selectedPrimaryRoleId) || (creationType === 'custom' && !customSystemInstruction.trim()) || isSaving }> {isSaving ? (<>Saving... <span className="button-spinner"></span></>) : "Save to Backend & Download"} </button>
        {processingStatus && !isSaving && <div className="status-message">{processingStatus}</div>}
      </div>
    );
  };

  const AdminPanelPage: React.FC = () => (
    <div className="admin-panel-view" key="admin-view">
        <h2 className="admin-panel-title">Admin Control Panel</h2>
        <div className="admin-placeholder-content">
            <span className="admin-placeholder-icon">🛠️</span>
            <p>User Rights Management Interface</p>
            <p className="admin-placeholder-detail">
                This is where an administrator would manage user accounts, assign roles (e.g., User, Limited Access, Full Control),
                and configure permissions for different parts of the application.
            </p>
            <p className="admin-placeholder-detail">
                (This functionality requires backend implementation and database integration, which is not part of this frontend simulation.)
            </p>
        </div>
    </div>
  );


  const renderActiveView = () => {
    switch (activeTab) {
      case 'chat': return (
          <> {isNexusCoreVisible && <NexusCoreSelector />}
            <div className={`chat-interface-wrapper ${isNexusCoreVisible ? 'flown-away' : 'flown-in'}`}>
              <div className="chat-messages" aria-live="polite" key="chat-view">
                {messages.map((msg) => (
                  <div key={msg.id} className={`message-container ${msg.sender}`}>
                    <div className="message-sender"><span className="sender-icon" aria-hidden="true">{msg.sender === 'user' ? '👤' : currentActivePersona.icon}</span>{msg.sender === 'user' ? 'YOU:' : `${currentActivePersona.name.toUpperCase()}:`}</div>
                    <div className={`message-bubble ${msg.sender}`}>{msg.text}{msg.isStreaming && <span className="streaming-indicator">▍</span>}</div>
                  </div>
                ))}
                {isLoading && messages[messages.length-1]?.sender !== 'ai' && (<div className="loading-indicator"><div className="cyber-pulse-loader"></div></div>)}
                <div ref={messagesEndRef} />
              </div>
              {error && !messages.some(m => m.text.includes(error)) && <div className={`error-message`}>{error}</div>}
              <form className="chat-input" onSubmit={handleSendMessage}>
                <button type="button" className={`mic-button ${isListening ? 'listening' : ''}`} onClick={handleListen} disabled={!recognition || isLoading || isNexusCoreVisible } aria-label={isListening ? "Stop listening" : "Start listening"}>🎤</button>
                <input ref={inputRef} type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder={isLoading ? 'AI is thinking...' : `Ask ${currentActivePersona.name}...`} disabled={isLoading || isNexusCoreVisible } aria-label="Chat input"/>
                <button type="submit" disabled={isLoading || !input.trim() || isNexusCoreVisible } aria-label="Send message">Send</button>
              </form>
            </div>
          </>);
      case 'upload':
        const isUploadingFile = processingStatus && selectedFile; const isProcessingUrl = processingStatus && youtubeUrl;
        return (
          <div className="upload-content-view" key="upload-view">
            <h2 className="upload-title">Upload Learning Materials</h2>
            <div className="upload-section">
              <h3 className="upload-section-title">Upload Files (PDF, Audio, Video)</h3>
              <input type="file" id="file-upload" className="file-input" onChange={handleFileChange} aria-label="Choose file to upload" disabled={!!processingStatus}/>
              <label htmlFor="file-upload" className={`file-input-label ${!!processingStatus ? 'disabled' : ''}`}>Choose File</label>
              {selectedFile && <p className="selected-file-info">Selected: {selectedFile.name}</p>}
              <button className="process-button" onClick={handleProcessFile} disabled={!selectedFile || !!processingStatus} aria-label="Process uploaded file"> {isUploadingFile ? (<>Sending... <span className="button-spinner"></span></>) : "Upload to Backend"} </button>
            </div>
            <div className="upload-section">
              <h3 className="upload-section-title">Link YouTube Video</h3>
              <input type="text" className="url-input" value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} placeholder="Enter YouTube video URL" aria-label="YouTube video URL" disabled={!!processingStatus}/>
              <button className="process-button" onClick={handleProcessUrl} disabled={!youtubeUrl.trim() || !!processingStatus} aria-label="Process YouTube URL"> {isProcessingUrl ? (<>Processing... <span className="button-spinner"></span></>) : "Process URL via Backend"} </button>
            </div>
            {processingStatus && !isUploadingFile && !isProcessingUrl && <div className="status-message">{processingStatus}</div>}
            {error && <div className="error-message">{error}</div>}
          </div>);
      case 'creator': return <ChildBotCreatorView />;
      case 'admin': return <AdminPanelPage />;
      default: return <div>Select a tab</div>;
    }
  };

  if (!isAuthenticated) return <AuthContainer />;

  const isHomeScreen = activeTab === 'chat' && !isNexusCoreVisible;

  return (
    <div className="chat-app">
      <header className="chat-header">
        {!isHomeScreen && ( <button className="back-button" onClick={handleGoBack} aria-label="Go back">‹ Back</button> )}
        <div className="header-title" onClick={handleGoHome} role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleGoHome(); }} aria-label="Synapse-OD Home">
            <AppLogo />
        </div>
        <div className="header-controls">
            <button type="button" className={`tts-toggle ${isTTSEnabled ? 'active' : ''}`} onClick={toggleTTS} aria-pressed={isTTSEnabled} aria-label={isTTSEnabled ? "Disable text to speech" : "Enable text to speech"}>
                {isTTSEnabled ? 'TTS: ON 🔊' : 'TTS: OFF 🔇'}
            </button>
            {currentUser && (
                <div className="user-menu-container" ref={userDropdownRef}>
                    <button className="user-menu-button" onClick={() => setShowUserDropdown(prev => !prev)} aria-haspopup="true" aria-expanded={showUserDropdown} aria-label="User menu">
                        👤 <span className="user-name-display">{currentUser.name.split(' ')[0]}</span>
                    </button>
                    {showUserDropdown && (
                        <div className="user-dropdown">
                            <div className="user-dropdown-email">{currentUser.email}</div>
                            <div className="user-dropdown-role">Role: {currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}</div>
                            <button onClick={handleLogout} className="logout-button">Logout</button>
                        </div>
                    )}
                </div>
            )}
        </div>
      </header>
      {sttError && <div className="error-message stt-error-message">{sttError}</div>}
      {renderActiveView()}
      <nav className="chat-tabs" aria-label="Main navigation">
        {TABS.map(tab => (
          <button key={tab.id}
            className={`tab-item ${activeTab === tab.id ? 'active' : ''} ${tab.disabled ? 'disabled' : ''} ${tab.adminOnly && currentUser?.role !== 'admin' ? 'hidden-tab' : ''}`}
            onClick={() => {
              if (tab.disabled || (tab.adminOnly && currentUser?.role !== 'admin')) return;
              setError(null); setProcessingStatus(null);
              if (tab.id === 'chat') handleNexusToggle();
              else { if (isNexusCoreVisible) setIsNexusCoreVisible(false); setActiveTab(tab.id); }
            }}
            disabled={tab.disabled || (tab.adminOnly && currentUser?.role !== 'admin')} role="tab" aria-selected={activeTab === tab.id}
            aria-haspopup={tab.id === 'chat' ? 'true' : undefined} aria-expanded={tab.id === 'chat' ? isNexusCoreVisible : undefined} >
            <span className="tab-icon" aria-hidden="true">{tab.id === 'chat' ? (currentActivePersona.icon + ' 🔼') : tab.icon}</span>
            <span className="tab-label">{tab.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

document.addEventListener('DOMContentLoaded', () => {
  const rootElement = document.getElementById('root');
  if (!rootElement) { console.error("CRITICAL: React root element with ID 'root' was not found."); return; }
  const reactRoot = ReactDOM.createRoot(rootElement);
  reactRoot.render(<React.StrictMode><ChatApp /></React.StrictMode>);
});
