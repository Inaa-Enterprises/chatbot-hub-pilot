# Bot Personas for Synapse-OD

This directory contains comprehensive bot personas for the template bots in the Synapse-OD application. Each persona is defined in a JSON file with the following structure:

```json
{
  "id": "unique-bot-id",
  "name": "Bot Name",
  "icon": "🤖",
  "description": "Detailed description of the bot's purpose and capabilities.",
  "shortTagline": "Brief tagline",
  "systemInstruction": "Detailed system instruction including attitude, nature, communication style, and disclaimers."
}
```

## Available Bot Personas

1. **Content Creator Bot** (`content-creator-persona.json`): Specializes in generating various forms of textual content with adaptable writing style, tone, and format.

2. **Cook Bot** (`cook-persona.json`): Provides recipes, cooking techniques, meal planning, and ingredient substitutions.

3. **Financial Consultant Bot** (`financial-consultant-persona.json`): Offers information on personal finance, budgeting, investing concepts, and financial planning.

4. **Legal Consultant Bot** (`legal-consultant-persona.json`): Provides general legal information, document understanding, and explanations of legal concepts.

5. **Media Creator Bot** (`media-creator-persona.json`): Assists with visual content planning, script development, storyboarding concepts, and creative direction.

6. **Medical Consultant Bot** (`medical-consultant-persona.json`): Provides general health information, medical terminology explanations, and wellness concepts.

7. **Personal Assistant Bot** (`personal-assistant-persona.json`): Helps with task management, scheduling, reminders, information retrieval, and productivity support.

8. **Personal Secretary Bot** (`personal-secretary-persona.json`): Assists with professional correspondence, calendar management, meeting preparation, and administrative support.

9. **Prompt Creator Bot** (`prompt-creator-persona.json`): Specializes in crafting effective prompts for various AI models and use cases.

10. **SEO Writer Bot** (`seo-writer-persona.json`): Creates search engine optimized content, meta descriptions, and keyword strategies.

11. **Tutor Bot** (`tutor-persona.json`): Explains concepts, answers questions, and provides learning support across various subjects.

## Integration with HTML Templates

Each bot persona is designed to be integrated with its corresponding HTML template in this directory. The HTML templates provide the user interface for interacting with the bots, while the persona JSON files define the bot's personality, capabilities, and system instructions.

To integrate a bot persona with its HTML template:

1. Load the persona JSON file
2. Extract the system instruction and other relevant information
3. Use the system instruction when making API calls to the LLM
4. Display the bot's name, icon, and description in the UI

## Important Notes

- All bot personas include appropriate disclaimers for their respective domains
- The system instructions define the bot's attitude, nature, and communication style
- These personas are designed to work with the Synapse-OD application and may need adjustments for other contexts