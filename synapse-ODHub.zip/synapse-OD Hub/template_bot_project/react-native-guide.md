# Native Mobile App (React Native) Guide

To build a native mobile app with React Native, you'll need a development environment set up.

## Prerequisites

* Node.js and npm/yarn
* Expo CLI or React Native CLI
* Xcode (for iOS development on macOS)
* Android Studio (for Android development)

## Steps to Run

1.  **Create a new React Native project:**
    ```bash
    npx create-expo-app MyBotApp --template blank
    # or if using React Native CLI
    # npx react-native init MyBotApp
    ```

2.  **Navigate into your project directory:**
    ```bash
    cd MyBotApp
    ```

3.  **Replace `App.js` with the following code:**

    ```javascript
    import React, { useState } from 'react';
    import {
      SafeAreaView,
      StyleSheet,
      View,
      Text,
      TextInput,
      TouchableOpacity,
      ScrollView,
      KeyboardAvoidingView,
      Platform,
    } from 'react-native';

    const App = () => {
      const [messages, setMessages] = useState([
        { id: '1', sender: 'bot', text: 'Hello! How can I assist you today?' },
      ]);
      const [inputText, setInputText] = useState('');

      const handleSendMessage = () => {
        if (inputText.trim()) {
          const newUserMessage = { id: String(messages.length + 1), sender: 'user', text: inputText.trim() };
          setMessages((prevMessages) => [...prevMessages, newUserMessage]);
          setInputText('');

          // Simulate bot response
          setTimeout(() => {
            const botResponseText = `I received "${newUserMessage.text}". How else can I help?`;
            const newBotMessage = { id: String(messages.length + 2), sender: 'bot', text: botResponseText };
            setMessages((prevMessages) => [...prevMessages, newBotMessage]);
          }, 1000);
        }
      };

      return (
        <SafeAreaView style={styles.container}>
          <KeyboardAvoidingView
            style={styles.keyboardAvoidingView}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20} // Adjust offset as needed
          >
            <Text style={styles.header}>Your Bot's Native App</Text>

            <ScrollView style={styles.chatArea} contentContainerStyle={styles.chatContent}>
              {messages.map((message) => (
                <View
                  key={message.id}
                  style={[
                    styles.messageBubble,
                    message.sender === 'user' ? styles.userMessage : styles.botMessage,
                  ]}
                >
                  <Text style={message.sender === 'user' ? styles.userText : styles.botText}>
                    {message.sender === 'user' ? 'You: ' : 'Bot: '}
                    {message.text}
                  </Text>
                </View>
              ))}
            </ScrollView>

            <View style={styles.inputContainer}>
              <TextInput
                style={styles.textInput}
                placeholder="Type your message..."
                placeholderTextColor="#9ca3af"
                value={inputText}
                onChangeText={setInputText}
                onSubmitEditing={handleSendMessage} // Send on Enter key
                returnKeyType="send"
              />
              <TouchableOpacity style={styles.sendButton} onPress={handleSendMessage}>
                <Text style={styles.sendButtonText}>Send</Text>
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        </SafeAreaView>
      );
    };

    const styles = StyleSheet.create({
      container: {
        flex: 1,
        backgroundColor: '#f3f4f6', // gray-100
      },
      keyboardAvoidingView: {
        flex: 1,
        justifyContent: 'space-between',
      },
      header: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#1f2937', // gray-800
        textAlign: 'center',
        paddingVertical: 16,
        backgroundColor: '#ffffff',
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb', // gray-200
      },
      chatArea: {
        flex: 1,
        paddingHorizontal: 16,
        paddingVertical: 10,
      },
      chatContent: {
        justifyContent: 'flex-end', // Keep messages at the bottom
      },
      messageBubble: {
        maxWidth: '80%',
        padding: 10,
        borderRadius: 10,
        marginBottom: 8,
      },
      userMessage: {
        alignSelf: 'flex-end',
        backgroundColor: '#3b82f6', // blue-500
      },
      botMessage: {
        alignSelf: 'flex-start',
        backgroundColor: '#e0f2fe', // blue-100
      },
      userText: {
        color: '#ffffff',
      },
      botText: {
        color: '#1e3a8a', // blue-900
      },
      inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        backgroundColor: '#ffffff',
        borderTopWidth: 1,
        borderTopColor: '#e5e7eb', // gray-200
      },
      textInput: {
        flex: 1,
        height: 40,
        borderColor: '#d1d5db', // gray-300
        borderWidth: 1,
        borderRadius: 20,
        paddingHorizontal: 15,
        marginRight: 10,
        fontSize: 16,
        color: '#1f2937', // gray-800
      },
      sendButton: {
        backgroundColor: '#2563eb', // blue-600
        paddingVertical: 10,
        paddingHorizontal: 15,
        borderRadius: 20,
      },
      sendButtonText: {
        color: '#ffffff',
        fontWeight: 'bold',
        fontSize: 16,
      },
    });

    export default App;
    ```

4.  **Run your app:**
    ```bash
    npx expo start
    # or
    # npx react-native run-ios
    # npx react-native run-android
    ```

    Follow the instructions in your terminal to open the app on an emulator or your physical device.

This setup provides a native mobile experience for your bot.
