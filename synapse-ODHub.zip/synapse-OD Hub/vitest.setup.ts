import '@testing-library/jest-dom';

// Mock the SpeechRecognition API
Object.defineProperty(window, 'SpeechRecognition', {
  writable: true,
  value: jest.fn().mockImplementation(() => ({
    continuous: false,
    lang: '',
    interimResults: false,
    start: jest.fn(),
    stop: jest.fn(),
    abort: jest.fn(),
    onstart: null,
    onresult: null,
    onerror: null,
    onend: null,
  })),
});

// Mock the SpeechSynthesis API
Object.defineProperty(window, 'speechSynthesis', {
  writable: true,
  value: {
    speak: jest.fn(),
    cancel: jest.fn(),
  },
});

// Mock the SpeechSynthesisUtterance API
Object.defineProperty(window, 'SpeechSynthesisUtterance', {
  writable: true,
  value: jest.fn().mockImplementation((text) => ({
    text,
    voice: null,
    rate: 1,
    pitch: 1,
    volume: 1,
  })),
});

// Mock the crypto API for UUID generation
Object.defineProperty(window, 'crypto', {
  writable: true,
  value: {
    ...window.crypto,
    randomUUID: jest.fn().mockReturnValue('test-uuid'),
  },
});

// Suppress console errors during tests
const originalConsoleError = console.error;
console.error = (...args) => {
  if (
    typeof args[0] === 'string' &&
    (args[0].includes('React does not recognize the') ||
      args[0].includes('Warning: ') ||
      args[0].includes('Invalid DOM property'))
  ) {
    return;
  }
  originalConsoleError(...args);
};