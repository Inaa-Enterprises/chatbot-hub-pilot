# Main FastAPI application

import os
import logging
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from app.models import ChatRequest
from app.services import AIService
from app.personas import get_system_instruction

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Synapse-OD Simple Backend",
    description="Minimal backend for Synapse-OD frontend chat functionality using Gemini.",
    version="0.1.0"
)

# --- CORS Middleware --- > Allows frontend (e.g., running on localhost:5173) to call the backend
origins = [
    "http://localhost",
    "http://localhost:5173", # Default Vite dev server port
    "http://127.0.0.1",
    "http://127.0.0.1:5173",
    # Add any other origins if needed (e.g., deployed frontend URL)
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"], # Allows all methods
    allow_headers=["*"], # Allows all headers
)

# --- Initialize AI Service --- > Needs GCP_PROJECT_ID env var
ai_service = None
try:
    ai_service = AIService()
except ValueError as e:
    logger.error(f"Failed to initialize AIService: {e}. Ensure GCP_PROJECT_ID is set.")
    # Allow app to start but endpoint will fail
except Exception as e:
    logger.error(f"Unexpected error initializing AIService: {e}")
    # Allow app to start but endpoint will fail

# --- API Endpoints ---

@app.get("/")
def read_root():
    """Root endpoint for health check."""
    return {"status": "Synapse-OD Simple Backend is running"}

@app.post("/api/chat")
async def handle_chat(request: ChatRequest):
    """Handles incoming chat messages and streams responses from Gemini."""
    if not ai_service:
        logger.error("AIService not initialized. Cannot process chat request.")
        raise HTTPException(status_code=503, detail="AI Service is unavailable. Check backend configuration.")

    try:
        logger.info(f"Received chat request for persona: {request.personaId}")
        system_instruction = get_system_instruction(request.personaId)
        logger.info(f"Using system instruction: {system_instruction[:100]}...")

        # Define the streaming generator function
        async def stream_generator():
            try:
                response_stream = await ai_service.generate_streaming_response(
                    system_instruction=system_instruction,
                    message=request.message
                )
                async for chunk in response_stream:
                    # Process chunk - assuming chunk has a 'text' attribute or similar
                    # Adjust based on actual Gemini SDK stream object structure
                    if hasattr(chunk, 'text'):
                        yield chunk.text
                    else:
                        # Fallback or handle different chunk structures if necessary
                        logger.warning(f"Received unexpected chunk format: {type(chunk)}")
                        # Attempt to convert to string or skip
                        try:
                            yield str(chunk)
                        except Exception:
                            logger.error("Could not convert chunk to string.")

                logger.info("Finished streaming response from Gemini.")
            except Exception as e:
                logger.error(f"Error during Gemini streaming: {e}")
                # Yield an error message to the client if possible, or handle appropriately
                # Note: Cannot raise HTTPException within the generator
                yield f"\n\n[Error communicating with AI: {str(e)}]"

        # Return the streaming response
        return StreamingResponse(stream_generator(), media_type="text/plain")

    except Exception as e:
        logger.error(f"Error handling chat request: {e}")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

# --- Uvicorn Runner (for local development) ---
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000)) # Default to 8000 if PORT not set
    logger.info(f"Starting Uvicorn server on port {port}")
    # Listen on 0.0.0.0 to be accessible externally if needed (e.g., within Docker)
    uvicorn.run(app, host="0.0.0.0", port=port)

