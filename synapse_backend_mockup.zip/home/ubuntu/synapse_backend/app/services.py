# Service for interacting with Google Gemini via Vertex AI

import os
import vertexai
from vertexai.generative_models import GenerativeModel, ChatSession, Part, GenerationConfig
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables from .env file if it exists
load_dotenv()

class AIService:
    def __init__(self):
        self.project_id = os.getenv("GCP_PROJECT_ID")
        self.location = os.getenv("GCP_LOCATION", "us-central1")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-flash-001") # Use flash for speed/cost

        if not self.project_id:
            logger.error("GCP_PROJECT_ID environment variable not set.")
            raise ValueError("GCP_PROJECT_ID must be set")

        try:
            # Initialize Vertex AI
            vertexai.init(project=self.project_id, location=self.location)
            # Initialize the Gemini model
            self.model = GenerativeModel(self.model_name)
            logger.info(f"Vertex AI initialized successfully for project {self.project_id} in {self.location} with model {self.model_name}")
        except Exception as e:
            logger.error(f"Failed to initialize Vertex AI: {e}")
            raise

    async def generate_streaming_response(self, system_instruction: str, message: str):
        """Generates a streaming response from Gemini based on system instruction and message."""
        try:
            # Start a chat session *without* context/system prompt initially
            # We will prepend the system instruction to the user message
            # This is a workaround as ChatSession context isn't directly supported for streaming in the same way
            # chat = self.model.start_chat()

            # Combine system instruction and message (simple approach)
            # Note: For more complex history/context management, a different approach might be needed.
            # full_prompt = f"{system_instruction}\n\nUser: {message}\nAI:"

            # Use generate_content with streaming=True for better control with system prompts
            # Define generation config for streaming
            generation_config = GenerationConfig(
                temperature=0.7, # Adjust as needed
                top_p=0.95,
                top_k=40,
                max_output_tokens=2048,
            )

            # Construct the prompt including the system instruction
            # Note: The exact format might need tuning depending on the model version
            prompt_parts = []
            if system_instruction:
                 # Add system instruction as a separate part if supported, or prepend
                 # For now, prepend to the user message for simplicity
                 # prompt_parts.append(Part.from_text(f"System Instruction: {system_instruction}\n---\n"))
                 # logger.info(f"Using system instruction: {system_instruction}")
                 pass # System instruction handled by model params if available or prepended below

            # Prepend system instruction to the first user message for this turn
            # This is a common way to handle system prompts with generate_content
            effective_message = f"{system_instruction}\n\n{message}"
            prompt_parts.append(Part.from_text(effective_message))

            logger.info(f"Sending prompt to Gemini (Model: {self.model_name}): {effective_message[:200]}...")

            # Generate content with streaming enabled
            response_stream = self.model.generate_content(
                prompt_parts,
                generation_config=generation_config,
                stream=True,
                # Pass system_instruction if the model/API version supports it directly
                # system_instruction=system_instruction # Check SDK docs for current support
            )

            logger.info("Started receiving stream from Gemini...")
            return response_stream

        except Exception as e:
            logger.error(f"Error generating streaming response from Gemini: {e}")
            # Re-raise the exception so the endpoint can handle it
            raise

